import React from 'react';
import { DownloadIcon, UploadIcon, PlusIcon, ScanIcon } from './icons/ActionIcons';

interface HeaderProps {
  currentPath: string;
  onNew: () => void;
  onUpload: () => void;
  onDownload: () => void;
  onScan: () => void;
}

const HeaderButton: React.FC<{onClick: () => void, children: React.ReactNode, className?: string}> = ({ onClick, children, className = '' }) => (
    <button 
      onClick={onClick} 
      className={`group relative flex items-center gap-2 bg-black/30 text-white font-semibold py-2 px-4 rounded-md text-sm transition-all duration-300 border border-transparent hover:border-cyan-400 hover:shadow-[0_0_10px_rgba(0,255,255,0.5)] ${className}`}
    >
        {children}
    </button>
);

const Header: React.FC<HeaderProps> = ({ currentPath, onNew, onUpload, onDownload, onScan }) => {
  const pathParts = currentPath.split('/').filter(p => p);

  return (
    <header className="bg-black/30 backdrop-blur-sm border-b border-slate-700/50 p-3 flex items-center justify-between flex-shrink-0 shadow-[0_5px_15px_rgba(0,0,0,0.3)]">
      <div className="flex items-center gap-2 text-xl">
        <span className="font-bold text-cyan-400 filter drop-shadow-[0_0_4px_#00ffff]">C0dexAI</span>
      </div>
      
      <div className="flex-1 mx-8">
        <div className="text-sm text-slate-400 bg-black/50 rounded-full px-4 py-1 border border-slate-700">
          <span className="cursor-pointer hover:underline hover:text-pink-400">root</span>
          {pathParts.map((part, index) => (
            <React.Fragment key={index}>
              <span className="mx-1 text-slate-600">/</span>
              <span className="cursor-pointer hover:underline hover:text-cyan-400">{part}</span>
            </React.Fragment>
          ))}
        </div>
      </div>

      <div className="flex items-center gap-2">
        <HeaderButton onClick={onNew}><PlusIcon /> New</HeaderButton>
        <HeaderButton onClick={onUpload}><UploadIcon /> Upload</HeaderButton>
        <HeaderButton onClick={onDownload}><DownloadIcon /> Download</HeaderButton>
        <HeaderButton onClick={onScan}><ScanIcon /> Scan</HeaderButton>
      </div>
    </header>
  );
};

export default Header;
