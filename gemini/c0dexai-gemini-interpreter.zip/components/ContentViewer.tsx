import React, { useState, useEffect } from 'react';
import Editor from '@monaco-editor/react';
import { FolderIcon, FileTextIcon, PythonIcon, JsonIcon, MarkdownIcon, JsIcon, CsvIcon } from './icons/FileIcons';
import { SelectedFile, FileSystemNode } from '../types';

// Editor Component defined within the same file to adhere to file constraints
interface MonacoEditorProps {
    file: SelectedFile;
    onSave: (path: string, newContent: string) => Promise<void>;
}

const languageMapping: { [key: string]: string } = {
    js: 'javascript',
    ts: 'typescript',
    tsx: 'typescript',
    py: 'python',
    json: 'json',
    md: 'markdown',
    html: 'html',
    css: 'css',
    yml: 'yaml',
    yaml: 'yaml',
};

const getLanguage = (path: string) => {
    const extension = path.split('.').pop()?.toLowerCase() || '';
    return languageMapping[extension] || 'plaintext';
};


const MonacoEditor: React.FC<MonacoEditorProps> = ({ file, onSave }) => {
    const [content, setContent] = useState(file.content);
    const [isDirty, setIsDirty] = useState(false);
    const [isSaving, setIsSaving] = useState(false);
    
    useEffect(() => {
        setContent(file.content);
        setIsDirty(false);
    }, [file]);

    const handleEditorChange = (value: string | undefined) => {
        const newValue = value || '';
        setContent(newValue);
        setIsDirty(newValue !== file.content);
    };

    const handleSave = async () => {
        if (!file || !isDirty || isSaving) return;
        setIsSaving(true);
        try {
            await onSave(file.path, content);
            setIsDirty(false); 
        } catch (error) {
            alert(`Failed to save file: ${error instanceof Error ? error.message : 'Unknown error'}`);
        } finally {
            setIsSaving(false);
        }
    };

    return (
        <div className="h-full w-full flex flex-col bg-slate-900">
            <div className="flex-grow relative">
                <Editor
                    path={file.path}
                    language={getLanguage(file.path)}
                    value={content}
                    onChange={handleEditorChange}
                    theme="vs-dark"
                    options={{ minimap: { enabled: false }, wordWrap: 'on', automaticLayout: true }}
                />
            </div>
            <div className="flex-shrink-0 p-2 flex items-center gap-4 bg-black/50 border-t border-slate-700/50">
                <button
                    onClick={handleSave}
                    disabled={!isDirty || isSaving}
                    className="bg-green-600 hover:bg-green-500 text-black font-bold py-2 px-4 rounded-md transition-colors disabled:bg-slate-600 disabled:text-slate-400 disabled:cursor-not-allowed disabled:shadow-none hover:shadow-[0_0_15px_rgba(0,255,0,0.6)]"
                >
                    {isSaving ? 'Saving...' : 'Save Changes'}
                </button>
                 <span className={`text-sm ${isDirty ? 'text-yellow-400' : 'text-green-400'}`}>
                    {isSaving ? '...' : (isDirty ? 'Unsaved changes' : 'Saved')}
                </span>
            </div>
        </div>
    );
};


// Main ContentViewer Component
interface ContentViewerProps {
  selectedFile: SelectedFile | null;
  selectedPath: string;
  directoryChildren: FileSystemNode[] | null;
  onSaveFile: (path: string, newContent: string) => Promise<void>;
}

const getFileIcon = (fileName: string): React.ReactNode => {
    if (fileName.endsWith('.py')) return <PythonIcon />;
    if (fileName.endsWith('.json')) return <JsonIcon />;
    if (fileName.endsWith('.md')) return <MarkdownIcon />;
    if (fileName.endsWith('.js') || fileName.endsWith('.tsx')) return <JsIcon />;
    if (fileName.endsWith('.csv')) return <CsvIcon />;
    return <FileTextIcon />;
};

const ContentViewer: React.FC<ContentViewerProps> = ({ selectedFile, selectedPath, directoryChildren, onSaveFile }) => {
  
  if (selectedFile) {
    return <MonacoEditor file={selectedFile} onSave={onSaveFile} />
  }
  
  if (directoryChildren) {
     const sortedChildren = [...directoryChildren].sort((a, b) => {
        if (a.type === 'directory' && b.type === 'file') return -1;
        if (a.type === 'file' && b.type === 'directory') return 1;
        return a.name.localeCompare(b.name);
     });

    return (
      <div className="p-4 flex-grow overflow-y-auto">
        <h2 className="text-xl font-bold text-pink-400 mb-4 border-b border-pink-500/30 pb-2 flex items-center gap-2 filter drop-shadow-[0_0_4px_#ff00ff]">
            <FolderIcon isOpen={true} />
            <span>Directory: /{selectedPath}</span>
        </h2>
        <ul>
          {sortedChildren.map(child => (
            <li key={child.path} className="flex items-center gap-3 p-2 hover:bg-pink-500/20 rounded-md transition-colors">
              {child.type === 'directory' ? <FolderIcon isOpen={false} /> : getFileIcon(child.path)}
              <span>{child.name}</span>
            </li>
          ))}
        </ul>
      </div>
    );
  }

  return (
      <div className="p-8 text-center text-slate-500 h-full flex items-center justify-center">
        <div>
            <h2 className="text-2xl text-pink-400 filter drop-shadow-[0_0_4px_#ff00ff]">Nothing Selected</h2>
            <p className="mt-2">Select a file or folder to view its content.</p>
        </div>
      </div>
    );
};

export default ContentViewer;
