
import React, { useState, useCallback, useMemo, useRef, useEffect } from 'react';
import JSZip from 'jszip';
import { ChatMessage, ChatMessageSender, SelectedFile, DirectoryNode, FileSystemNode, FileNode } from './types';
import Header from './components/Header';
import FileExplorer from './components/FileExplorer';
import ContentViewer from './components/ContentViewer';
import ChatAssistant from './components/ChatAssistant';
import Resizer from './components/Resizer';
import FloatingOrbMenu from './components/FloatingOrbMenu';
import { CollapseIcon, ExpandIcon } from './components/icons/SideBarIcons';
import { runCodeInterpreter } from './services/geminiService';
import { initialFileSystem } from './utils/fileSystem';

const findNodeByPath = (root: DirectoryNode, path: string): FileSystemNode | null => {
    if (path === '' || path === '/') return root;
    const parts = path.split('/').filter(p => p);
    let currentNode: FileSystemNode = root;
    for (const part of parts) {
        if (currentNode.type === 'directory' && currentNode.children[part]) {
            currentNode = currentNode.children[part];
        } else {
            return null;
        }
    }
    return currentNode;
};

const App: React.FC = () => {
  const [fileSystem, setFileSystem] = useState<DirectoryNode>(initialFileSystem);
  const [selectedFile, setSelectedFile] = useState<SelectedFile | null>(null);
  const [currentPath, setCurrentPath] = useState<string>('');
  
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([
    { id: '1', sender: ChatMessageSender.System, text: "Welcome to C0dexAI. A local file system has been initialized for you." }
  ]);
  const [isAiLoading, setIsAiLoading] = useState(false);
  
  const [panelSizes, setPanelSizes] = useState([20, 45, 35]);
  const lastExplorerSize = useRef(panelSizes[0]);
  const mainContainerRef = useRef<HTMLElement>(null);
  const activeHandleIndex = useRef<number | null>(null);

  const handleResizeStart = useCallback((index: number, event: React.MouseEvent<HTMLDivElement>) => {
    event.preventDefault();
    activeHandleIndex.current = index;
    document.body.style.cursor = 'col-resize';
  }, []);

  const handleResizeMove = useCallback((event: MouseEvent) => {
    if (activeHandleIndex.current === null || !mainContainerRef.current) return;
    const mainRect = mainContainerRef.current.getBoundingClientRect();
    const totalWidth = mainRect.width;
    setPanelSizes(prevSizes => {
        const newSizes = [...prevSizes];
        const index = activeHandleIndex.current!;
        const MIN_PERCENT = 10;
        const totalTwoPanelSize = newSizes[index] + newSizes[index+1];
        let newLeftSize = ((event.clientX - mainRect.left) / totalWidth * 100) - (newSizes.slice(0,index).reduce((a,b)=> a+b, 0));
        if (newLeftSize < MIN_PERCENT) newLeftSize = MIN_PERCENT;
        if (newLeftSize > totalTwoPanelSize - MIN_PERCENT) newLeftSize = totalTwoPanelSize - MIN_PERCENT;
        const newRightSize = totalTwoPanelSize - newLeftSize;
        newSizes[index] = newLeftSize;
        newSizes[index+1] = newRightSize;
        if (index === 0 && newSizes[0] > 0) {
            lastExplorerSize.current = newSizes[0];
        }
        return newSizes;
    });
  }, []);

  const handleResizeEnd = useCallback(() => {
    activeHandleIndex.current = null;
    document.body.style.cursor = 'default';
  }, []);

  useEffect(() => {
    const handleMove = (e: MouseEvent) => handleResizeMove(e);
    const handleUp = () => handleResizeEnd();
    if (activeHandleIndex.current !== null) {
        window.addEventListener('mousemove', handleMove);
        window.addEventListener('mouseup', handleUp);
    }
    return () => {
        window.removeEventListener('mousemove', handleMove);
        window.removeEventListener('mouseup', handleUp);
    };
  }, [handleResizeMove, handleResizeEnd]);

  const toggleExplorer = useCallback(() => {
    setPanelSizes(currentSizes => {
        const isCurrentlyVisible = currentSizes[0] > 0;
        if (isCurrentlyVisible) { // collapsing
            if (currentSizes[0] > 0) lastExplorerSize.current = currentSizes[0];
            const spaceToDistribute = currentSizes[0];
            const otherPanelsTotal = currentSizes[1] + currentSizes[2];
            const ratio1 = otherPanelsTotal > 0 ? currentSizes[1] / otherPanelsTotal : 0.5;
            return [0, currentSizes[1] + spaceToDistribute * ratio1, currentSizes[2] + spaceToDistribute * (1 - ratio1)];
        } else { // expanding
            const widthToRestore = lastExplorerSize.current > 10 ? lastExplorerSize.current : 20;
            const otherPanelsTotal = currentSizes[1] + currentSizes[2];
            const ratio1 = otherPanelsTotal > 0 ? currentSizes[1] / otherPanelsTotal : 0.5;
            return [widthToRestore, (otherPanelsTotal - widthToRestore) * ratio1, (otherPanelsTotal - widthToRestore) * (1 - ratio1)];
        }
    });
  }, []);


  const handleSelectNode = useCallback(async (path: string, type: 'tree' | 'blob') => {
    setCurrentPath(path);
    const node = findNodeByPath(fileSystem, path);
    if (type === 'blob' && node && node.type === 'file') {
        setSelectedFile({ path, content: node.content });
    } else {
        setSelectedFile(null);
    }
  }, [fileSystem]);

  const addSystemMessage = (text: string) => {
    const message: ChatMessage = { id: Date.now().toString(), sender: ChatMessageSender.System, text };
    setChatHistory(prev => [...prev, message]);
  };

  const updateFileSystem = (updater: (fs: DirectoryNode) => DirectoryNode) => {
    setFileSystem(prevFs => {
        const newFs = JSON.parse(JSON.stringify(prevFs));
        return updater(newFs);
    });
  };

  const handleAiPrompt = useCallback(async (prompt: string) => {
    setIsAiLoading(true);
    const userMessage: ChatMessage = { id: Date.now().toString(), sender: ChatMessageSender.User, text: prompt };
    setChatHistory(prev => [...prev, userMessage]);

    try {
      let aiResponseText = await runCodeInterpreter(prompt, currentPath);
      const fileCreationRegex = /```file:(\S+)\n([\s\S]+?)```/g;
      const matches = [...aiResponseText.matchAll(fileCreationRegex)];

      if (matches.length > 0) {
        updateFileSystem(fs => {
          for (const match of matches) {
            const path = match[1];
            const content = match[2].trim();
            const parts = path.split('/').filter(p => p);
            const fileName = parts.pop();
            if (!fileName) continue;

            let parent = fs;
            let currentPathParts: string[] = [];
            for (const part of parts) {
                currentPathParts.push(part);
                if (!parent.children[part]) {
                    parent.children[part] = { type: 'directory', name: part, path: currentPathParts.join('/'), children: {} };
                }
                const nextNode = parent.children[part];
                if (nextNode.type === 'directory') {
                    parent = nextNode;
                } else {
                    aiResponseText = aiResponseText.replace(match[0], `(System: Error creating file '${path}': Path invalid, '${part}' is a file.)`);
                    continue;
                }
            }
            parent.children[fileName] = { type: 'file', name: fileName, path, content };
            aiResponseText = aiResponseText.replace(match[0], `(System: File '${path}' created successfully.)`);
          }
          return fs;
        });
      }

      const aiMessage: ChatMessage = { id: (Date.now() + 1).toString(), sender: ChatMessageSender.AI, text: aiResponseText };
      setChatHistory(prev => [...prev, aiMessage]);

    } catch (error) {
      console.error(error);
      const errorMessage: ChatMessage = { id: (Date.now() + 1).toString(), sender: ChatMessageSender.System, text: 'Apologies, a glitch in the mainframe occurred.' };
      setChatHistory(prev => [...prev, errorMessage]);
    } finally {
      setIsAiLoading(false);
    }
  }, [currentPath]);

  const handleSaveFile = useCallback(async (path: string, newContent: string) => {
    updateFileSystem(fs => {
        const node = findNodeByPath(fs, path);
        if (node && node.type === 'file') {
            node.content = newContent;
            addSystemMessage(`Successfully saved changes to ${path}`);
            setSelectedFile(prev => prev ? { ...prev, content: newContent } : null);
        } else {
             addSystemMessage(`Error: Could not find file at ${path} to save.`);
        }
        return fs;
    });
  }, []);


  const handleNew = async () => {
     const path = prompt("Enter full path for new file:");
     if (!path) return;
     updateFileSystem(fs => {
        const parts = path.split('/').filter(p => p);
        const fileName = parts.pop();
        if (!fileName) return fs;

        let parent = fs;
        let currentPathParts: string[] = [];
        for (const part of parts) {
            currentPathParts.push(part);
            if (!parent.children[part]) {
                parent.children[part] = { type: 'directory', name: part, path: currentPathParts.join('/'), children: {} };
            }
            const nextNode = parent.children[part];
            if (nextNode.type === 'directory') {
                parent = nextNode;
            } else {
                addSystemMessage(`Error: Invalid path. '${part}' is a file.`);
                return fs;
            }
        }

        if (parent.children[fileName]) {
            addSystemMessage(`Error: File or directory already exists at '${path}'.`);
        } else {
            parent.children[fileName] = { type: 'file', name: fileName, path, content: '' };
            addSystemMessage(`File '${path}' created.`);
        }
        return fs;
     });
  };

  const handleDownloadZip = async () => {
    addSystemMessage('Archiving file system to a ZIP datastream...');
    const zip = new JSZip();

    const addNodeToZip = (node: FileSystemNode, currentZip: JSZip) => {
        if (node.type === 'file') {
            currentZip.file(node.name, node.content);
        } else { // directory
            const dirZip = currentZip.folder(node.name);
            if(dirZip) {
                for (const child of Object.values(node.children)) {
                    addNodeToZip(child, dirZip);
                }
            }
        }
    };
    
    for (const child of Object.values(fileSystem.children)) {
        addNodeToZip(child, zip);
    }

    zip.generateAsync({type:"blob"}).then(function(content) {
        const link = document.createElement('a');
        link.href = URL.createObjectURL(content);
        link.download = 'codexai-project.zip';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        addSystemMessage('Download initialized.');
    });
  };
  
  const handleScanRepo = useCallback(() => {
    const buildTreeString = (node: DirectoryNode, prefix = ''): string => {
        let result = '';
        const children = Object.values(node.children).sort((a,b) => {
            if (a.type !== b.type) return a.type === 'directory' ? -1 : 1;
            return a.name.localeCompare(b.name);
        });
        children.forEach((child, index) => {
            const isLast = index === children.length - 1;
            result += `${prefix}${isLast ? '└── ' : '├── '}${child.name}\n`;
            if (child.type === 'directory') {
                result += buildTreeString(child, `${prefix}${isLast ? '    ' : '│   '}`);
            }
        });
        return result;
    }
    const treeContent = `# Repository Structure\n\n\`\`\`\n${buildTreeString(fileSystem)}\`\`\``;
    const path = 'repo_tree.md';
    
    updateFileSystem(fs => {
        const existingNode = findNodeByPath(fs, path) as FileNode | null;
        if (existingNode && existingNode.type === 'file') {
            existingNode.content = treeContent;
        } else {
            fs.children[path] = { type: 'file', name: path, path, content: treeContent };
        }
        addSystemMessage(`File '${path}' created/updated with repository structure.`);
        return fs;
    });
  }, [fileSystem]);

  const isExplorerVisible = panelSizes[0] > 0;
  
  const contentViewerDirectoryChildren = useMemo(() => {
    const node = findNodeByPath(fileSystem, currentPath);
    if (node && node.type === 'directory') {
        return Object.values(node.children);
    }
    return null;
  }, [fileSystem, currentPath]);

  return (
    <div className="h-screen w-screen bg-[#0d0d0d] text-slate-300 flex flex-col font-sans overflow-hidden">
      <Header
        currentPath={currentPath}
        onNew={handleNew}
        onUpload={() => addSystemMessage("Upload functionality is deprecated. Please create files and paste content.")}
        onDownload={handleDownloadZip}
        onScan={handleScanRepo}
      />
      <main ref={mainContainerRef} className="flex-grow flex overflow-hidden p-2 gap-2">
        <div 
            className="bg-black/30 backdrop-blur-sm rounded-lg overflow-hidden transition-all duration-300 shadow-[0_0_15px_rgba(0,255,255,0.2)]"
            style={{ 
                flexBasis: `${panelSizes[0]}%`,
                display: panelSizes[0] === 0 ? 'none' : 'flex'
            }}
        >
          <div className="overflow-y-auto h-full w-full">
             <FileExplorer nodes={fileSystem.children} onSelectNode={handleSelectNode} />
          </div>
        </div>
        
        <div className="relative flex-shrink-0 flex items-center -ml-2">
            <button 
                onClick={toggleExplorer}
                className="z-20 bg-slate-800 hover:bg-cyan-400 text-white rounded-full p-1 shadow-[0_0_10px_rgba(0,255,255,0.5)] transition-all"
                aria-label={isExplorerVisible ? "Collapse sidebar" : "Expand sidebar"}
            >
                {isExplorerVisible ? <CollapseIcon /> : <ExpandIcon />}
            </button>
            {isExplorerVisible && <Resizer onMouseDown={(e) => handleResizeStart(0, e)} />}
        </div>
        
        <div className="flex-grow flex flex-col overflow-hidden bg-black/30 backdrop-blur-sm rounded-lg shadow-[0_0_15px_rgba(255,0,255,0.2)]" style={{ flexBasis: `${panelSizes[1]}%` }}>
          <ContentViewer 
            selectedFile={selectedFile} 
            selectedPath={currentPath} 
            directoryChildren={contentViewerDirectoryChildren}
            onSaveFile={handleSaveFile}
           />
        </div>

        <Resizer onMouseDown={(e) => handleResizeStart(1, e)} />

        <div className="bg-black/30 backdrop-blur-sm rounded-lg flex flex-col shadow-[0_0_15px_rgba(0,255,0,0.2)]" style={{ flexBasis: `${panelSizes[2]}%` }}>
          <ChatAssistant
            messages={chatHistory}
            onSendMessage={handleAiPrompt}
            isLoading={isAiLoading}
          />
        </div>
      </main>
      <FloatingOrbMenu onScan={handleScanRepo} onDownload={handleDownloadZip} />
    </div>
  );
};

export default App;
