import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

// Ensure API_KEY is available in the environment.
if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const runCodeInterpreter = async (prompt: string, currentPath: string): Promise<string> => {
    
    const systemInstruction = `
You are 'C0dexAI', a powerful AI assistant with Code Interpreter capabilities integrated into a simulated file system environment.
Your purpose is to help users with tasks related to coding, data analysis, and file manipulation.
You can read files (by having the user open them), and create new files.

The user is currently at path: '/${currentPath}'.

When a user asks you to perform a task:
1.  Acknowledge the user's request.
2.  Think step-by-step about how to solve the problem.
3.  If the task involves creating a file (e.g., a plot, a CSV, a script), generate the content for that file.
    To create a file, use a special format which the application will parse:
    \`\`\`file:path/to/FILENAME.EXT
    FILE_CONTENT_HERE
    \`\`\`
    Replace FILENAME.EXT with the desired filename and FILE_CONTENT_HERE with the file's content. Do not use markdown formatting inside this block. The path should be relative to the file system root.
4. For file modifications, ask the user to open the file first. The user can then use the integrated editor to make changes.
`;

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                systemInstruction: systemInstruction,
                temperature: 0.5,
            }
        });

        return response.text;
    } catch (error) {
        console.error("Error calling Gemini API:", error);
        return `An error occurred while communicating with the AI. Please check the console for details. Make sure your API key is configured correctly.`;
    }
};
