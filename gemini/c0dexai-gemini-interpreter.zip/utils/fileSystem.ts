import { DirectoryNode } from '../types';

export const initialFileSystem: DirectoryNode = {
    type: 'directory',
    name: 'root',
    path: '',
    children: {
        'README.md': {
            type: 'file',
            name: 'README.md',
            path: 'README.md',
            content: '# C0dexAI Project\n\nWelcome to your local C0dexAI environment. You can create, edit, and run files with the help of the AI assistant.'
        },
        'src': {
            type: 'directory',
            name: 'src',
            path: 'src',
            children: {
                'main.py': {
                    type: 'file',
                    name: 'main.py',
                    path: 'src/main.py',
                    content: 'def hello():\n    print("Hello from Python!")\n\nhello()'
                },
                'data.json': {
                    type: 'file',
                    name: 'data.json',
                    path: 'src/data.json',
                    content: '{ "message": "This is a sample JSON file." }'
                }
            }
        },
        'package.json': {
            type: 'file',
            name: 'package.json',
            path: 'package.json',
            content: JSON.stringify({
                name: 'codex-ai-project',
                version: '1.0.0',
                description: 'A project managed by C0dexAI',
            }, null, 2)
        }
    }
};
