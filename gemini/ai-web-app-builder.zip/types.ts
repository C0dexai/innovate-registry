export interface FileNode {
  type: 'file';
  name: string;
}

export interface DirectoryNode {
  type: 'directory';
  name: string;
  children: FileSystemNode[];
}

export type FileSystemNode = FileNode | DirectoryNode;

export interface FileContentMap {
  [path: string]: string;
}

export interface AiChange {
  filePath: string;
  content: string;
}
