import { DirectoryNode, FileContentMap } from '../types';

export const defaultFileSystem: DirectoryNode = {
  type: 'directory',
  name: 'root',
  children: [
    {
      type: 'file',
      name: 'index.html',
    },
    {
      type: 'file',
      name: 'index.tsx',
    },
     {
      type: 'file',
      name: 'metadata.json',
    },
  ],
};

export const defaultFileContents: FileContentMap = {
  'index.html': `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>My App</title>
    <style>
      body {
        font-family: sans-serif;
        background-color: #222;
        color: white;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
      }
    </style>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/index.tsx"></script>
  </body>
</html>`,
  'index.tsx': `import React from 'react';
import ReactDOM from 'react-dom/client';

const App = () => {
  return <h1>Hello, AI Builder!</h1>;
};

const root = document.getElementById('root');
if (root) {
  ReactDOM.createRoot(root).render(<App />);
}
`,
  'metadata.json': `{
  "name": "My New App",
  "description": "A web app created with the AI Web App Builder."
}`
};
