import React from 'react';
import FileExplorer from './FileExplorer';
import SettingsPanel from './SettingsPanel';
import { DirectoryNode } from '../types';

interface SideBarProps {
  fileSystem: DirectoryNode;
  selectedFile: string;
  onSelectFile: (path: string) => void;
}

const SideBar: React.FC<SideBarProps> = ({ fileSystem, selectedFile, onSelectFile }) => {
  return (
    <div className="h-full bg-gray-800 text-white flex flex-col">
      <div className="p-2 border-b border-gray-700">
        <h2 className="text-lg font-semibold">Explorer</h2>
      </div>
      <div className="flex-grow overflow-y-auto">
        <FileExplorer
          fileSystem={fileSystem}
          selectedFile={selectedFile}
          onSelectFile={onSelectFile}
        />
      </div>
      <SettingsPanel />
    </div>
  );
};

export default SideBar;
