import React from 'react';

interface HorizontalResizeHandleProps {
  onMouseDown: (event: React.MouseEvent<HTMLDivElement>) => void;
}

const HorizontalResizeHandle: React.FC<HorizontalResizeHandleProps> = ({ onMouseDown }) => {
  return (
    <div
      className="w-full h-2 cursor-row-resize bg-gray-700 hover:bg-blue-500 transition-colors duration-200"
      onMouseDown={onMouseDown}
    />
  );
};

export default HorizontalResizeHandle;
