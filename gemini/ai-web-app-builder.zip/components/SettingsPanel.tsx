import React from 'react';

const SettingsPanel: React.FC = () => {
  return (
    <div className="border-t border-gray-700 p-2">
      {/* Settings content can go here in the future */}
    </div>
  );
};

export default SettingsPanel;
