import React, { useState } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { AiChange, FileContentMap } from '../types';

interface AILogPanelProps {
    onAiUpdate: (changes: AiChange[]) => void;
    files: FileContentMap;
    selectedFile: string;
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const AILogPanel: React.FC<AILogPanelProps> = ({ onAiUpdate, files, selectedFile }) => {
    const [prompt, setPrompt] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [history, setHistory] = useState<{ type: 'user' | 'ai' | 'error', content: string }[]>([]);

    const handleGenerate = async () => {
        if (!prompt) return;

        setIsLoading(true);
        setHistory(prev => [...prev, { type: 'user', content: prompt }]);

        const systemInstruction = `You are a senior frontend engineer. Your task is to help a user modify their web application based on their request.
The user's files are provided in a JSON object. The currently active file is "${selectedFile}".
Analyze the user's request and the provided file contents.
You MUST respond with a JSON object that strictly adheres to the provided schema.
The JSON object should contain an array of "changes", where each change object specifies the "filePath" and the complete new "content" for that file.
Only include files that need to be changed. If no files need to change, return an empty array.
Do not add any explanations or markdown formatting to your response.`;

        const fullPrompt = `User request: "${prompt}"

Current files:
${JSON.stringify(files, null, 2)}
`;
        try {
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: fullPrompt,
                config: {
                    systemInstruction,
                    responseMimeType: "application/json",
                    responseSchema: {
                        type: Type.OBJECT,
                        properties: {
                            changes: {
                                type: Type.ARRAY,
                                items: {
                                    type: Type.OBJECT,
                                    properties: {
                                        filePath: { type: Type.STRING },
                                        content: { type: Type.STRING },
                                    },
                                    required: ["filePath", "content"],
                                },
                            },
                        },
                    },
                },
            });
            
            const aiResponseText = response.text;
            setHistory(prev => [...prev, { type: 'ai', content: `AI proposed changes:\n${aiResponseText}` }]);
            const parsed = JSON.parse(aiResponseText);
            
            if (parsed.changes && Array.isArray(parsed.changes)) {
                onAiUpdate(parsed.changes);
            }

        } catch (e) {
            console.error(e);
            const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
            setHistory(prev => [...prev, { type: 'error', content: `Error: ${errorMessage}` }]);
        } finally {
            setIsLoading(false);
            setPrompt('');
        }
    };

    return (
        <div className="h-full flex flex-col bg-gray-800 p-2 text-sm">
            <div className="flex-grow overflow-y-auto mb-2 pr-2">
                {history.map((entry, index) => (
                    <div key={index} className={`whitespace-pre-wrap p-2 rounded mb-2 ${
                        entry.type === 'user' ? 'bg-blue-500/10' :
                        entry.type === 'ai' ? 'bg-green-500/10' : 'bg-red-500/20 text-red-300'
                    }`}>
                        <strong>{entry.type.toUpperCase()}:</strong> {entry.content}
                    </div>
                ))}
            </div>
            <div className="flex gap-2">
                <input
                    type="text"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && !isLoading && handleGenerate()}
                    placeholder="e.g., Change the h1 text to 'Welcome'"
                    className="flex-grow bg-gray-900 border border-gray-600 rounded px-2 py-1 outline-none focus:ring-2 focus:ring-blue-500"
                    disabled={isLoading}
                />
                <button
                    onClick={handleGenerate}
                    disabled={isLoading || !prompt}
                    className="bg-blue-600 hover:bg-blue-500 text-white font-semibold px-4 py-1 rounded disabled:bg-blue-800/50 disabled:cursor-not-allowed"
                >
                    {isLoading ? 'Thinking...' : 'Send'}
                </button>
            </div>
        </div>
    );
};

export default AILogPanel;
