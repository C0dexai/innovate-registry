import React, { useMemo } from 'react';
import * as Babel from '@babel/standalone';
import { FileContentMap } from '../types';

interface PreviewProps {
  files: FileContentMap;
}

const Preview: React.FC<PreviewProps> = ({ files }) => {
  const srcDoc = useMemo(() => {
    const html = files['index.html'] || '';
    const tsx = files['index.tsx'] || '';

    if (!html) return '<html><body>No index.html found.</body></html>';

    try {
      const transformedCode = Babel.transform(tsx, {
        presets: ['react', 'typescript'],
        filename: 'index.tsx',
      }).code;

      const importMap = {
          "imports": {
            "react": "https://esm.sh/react@18.3.1",
            "react-dom/client": "https://esm.sh/react-dom@18.3.1/client",
            "react/jsx-runtime": "https://esm.sh/react@18.3.1/jsx-runtime"
          }
      };

      return html.replace(
        '<script type="module" src="/index.tsx"></script>',
        `
        <script type="importmap">${JSON.stringify(importMap)}</script>
        <script type="module">${transformedCode}</script>
        `
      );
    } catch (e) {
      console.error('Error transforming code:', e);
      return `<html><body><h1>Error</h1><pre>${e.message}</pre></body></html>`;
    }
  }, [files]);

  return (
    <iframe
      srcDoc={srcDoc}
      title="Preview"
      sandbox="allow-scripts allow-modals"
      className="w-full h-full bg-white"
    />
  );
};

export default Preview;
