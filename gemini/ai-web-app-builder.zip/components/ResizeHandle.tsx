import React from 'react';

interface ResizeHandleProps {
  onMouseDown: (event: React.MouseEvent<HTMLDivElement>) => void;
}

const ResizeHandle: React.FC<ResizeHandleProps> = ({ onMouseDown }) => {
  return (
    <div
      className="w-2 h-full cursor-col-resize bg-gray-700 hover:bg-blue-500 transition-colors duration-200"
      onMouseDown={onMouseDown}
    />
  );
};

export default ResizeHandle;
