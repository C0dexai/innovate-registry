import React, { useState, useCallback, useRef, useEffect } from 'react';
import { FileContentMap, DirectoryNode, AiChange } from './types';
import { defaultFileContents, defaultFileSystem } from './utils/file-system';
import SideBar from './components/SideBar';
import MonacoEditor from './components/MonacoEditor';
import Preview from './components/Preview';
import AILogPanel from './components/AILogPanel';
import ResizeHandle from './components/ResizeHandle';
import HorizontalResizeHandle from './components/HorizontalResizeHandle';

const App: React.FC = () => {
  const [fileSystem] = useState<DirectoryNode>(defaultFileSystem);
  const [fileContents, setFileContents] = useState<FileContentMap>(defaultFileContents);
  const [selectedFile, setSelectedFile] = useState<string>('index.tsx');

  const [sidebarWidth, setSidebarWidth] = useState(250);
  const [bottomPanelHeight, setBottomPanelHeight] = useState(200);
  
  const isResizingSidebar = useRef(false);
  const isResizingBottomPanel = useRef(false);

  const handleFileChange = useCallback((value: string | undefined) => {
    if (value === undefined) return;
    setFileContents(prev => ({ ...prev, [selectedFile]: value }));
  }, [selectedFile]);

  const handleAiUpdate = useCallback((changes: AiChange[]) => {
    setFileContents(prev => {
        const newState = {...prev};
        changes.forEach(change => {
            if (newState[change.filePath] !== undefined) {
                newState[change.filePath] = change.content;
            }
        });
        return newState;
    });
  }, []);

  const handleSidebarResize = useCallback((e: MouseEvent) => {
    if (isResizingSidebar.current) {
      // Use requestAnimationFrame to prevent ResizeObserver loop errors
      requestAnimationFrame(() => {
        const newWidth = e.clientX;
        if (newWidth > 150 && newWidth < window.innerWidth - 300) {
            setSidebarWidth(newWidth);
        }
      });
    }
  }, []);

  const handleBottomPanelResize = useCallback((e: MouseEvent) => {
    if (isResizingBottomPanel.current) {
      // Use requestAnimationFrame to prevent ResizeObserver loop errors
      requestAnimationFrame(() => {
        const newHeight = window.innerHeight - e.clientY;
        if (newHeight > 50 && newHeight < window.innerHeight - 100) {
            setBottomPanelHeight(newHeight);
        }
      });
    }
  }, []);

  const stopResizing = useCallback(() => {
    isResizingSidebar.current = false;
    isResizingBottomPanel.current = false;
    window.removeEventListener('mousemove', handleSidebarResize);
    window.removeEventListener('mousemove', handleBottomPanelResize);
    window.removeEventListener('mouseup', stopResizing);
    // Restore cursor and text selection
    document.body.style.cursor = 'default';
    document.body.style.userSelect = 'auto';
  }, [handleSidebarResize, handleBottomPanelResize]);

  useEffect(() => {
    // This effect is a safety net to clean up listeners on unmount.
    return () => {
        window.removeEventListener('mousemove', handleSidebarResize);
        window.removeEventListener('mousemove', handleBottomPanelResize);
        window.removeEventListener('mouseup', stopResizing);
    };
  }, [handleSidebarResize, handleBottomPanelResize, stopResizing]);


  const startSidebarResize = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    isResizingSidebar.current = true;
    // Set global cursor and disable text selection for smoother resizing
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';
    window.addEventListener('mousemove', handleSidebarResize);
    window.addEventListener('mouseup', stopResizing);
  }, [handleSidebarResize, stopResizing]);
  
  const startBottomPanelResize = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    isResizingBottomPanel.current = true;
    // Set global cursor and disable text selection for smoother resizing
    document.body.style.cursor = 'row-resize';
    document.body.style.userSelect = 'none';
    window.addEventListener('mousemove', handleBottomPanelResize);
    window.addEventListener('mouseup', stopResizing);
  }, [handleBottomPanelResize, stopResizing]);

  return (
    <div className="flex flex-col h-screen w-screen bg-gray-900 text-white overflow-hidden">
      <div className="flex flex-grow min-h-0">
        <div style={{ width: `${sidebarWidth}px` }} className="flex-shrink-0">
          <SideBar fileSystem={fileSystem} selectedFile={selectedFile} onSelectFile={setSelectedFile} />
        </div>
        <ResizeHandle onMouseDown={startSidebarResize} />
        <div className="flex flex-col flex-grow min-w-0">
            <div className="flex-grow flex min-h-0">
                <div className="flex-1 flex flex-col min-w-0">
                    <div className="bg-gray-800 px-3 py-1.5 border-b border-l border-gray-700 text-sm text-gray-300 flex-shrink-0">
                        {selectedFile}
                    </div>
                    <div className="flex-grow relative">
                      <div className="absolute inset-0">
                        <MonacoEditor 
                            filePath={selectedFile} 
                            value={fileContents[selectedFile] || ''} 
                            onChange={handleFileChange} 
                        />
                      </div>
                    </div>
                </div>
                <div className="flex-1 border-l border-gray-700">
                  <Preview files={fileContents} />
                </div>
            </div>
            <HorizontalResizeHandle onMouseDown={startBottomPanelResize} />
            <div style={{ height: `${bottomPanelHeight}px` }} className="flex-shrink-0">
                <AILogPanel onAiUpdate={handleAiUpdate} files={fileContents} selectedFile={selectedFile} />
            </div>
        </div>
      </div>
    </div>
  );
};

export default App;