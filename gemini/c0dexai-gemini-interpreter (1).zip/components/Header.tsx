
import React from 'react';

interface HeaderProps {
  repoName: string;
  currentPath: string;
}

const Header: React.FC<HeaderProps> = ({ repoName, currentPath }) => {
  const pathParts = currentPath.split('/').filter(p => p);

  return (
    <header className="bg-black/30 backdrop-blur-sm border-b border-slate-700/50 p-3 flex items-center justify-between flex-shrink-0 shadow-[0_5px_15px_rgba(0,0,0,0.3)]">
      <div className="flex items-center gap-2 text-xl">
        <span className="font-bold text-cyan-400 filter drop-shadow-[0_0_4px_#00ffff]">C0dexAI</span>
      </div>
      
      <div className="flex-1 mx-8">
        <div className="text-sm text-slate-400 bg-black/50 rounded-full px-4 py-1 border border-slate-700 flex items-baseline">
          <span className="font-semibold text-pink-400 flex-shrink-0">{repoName}</span>
          <span className="mx-2 text-slate-600">/</span>
          <span className="truncate">
            {pathParts.length > 0 
              ? pathParts.map((part, index) => (
                  <React.Fragment key={index}>
                    <span className="cursor-pointer hover:underline hover:text-cyan-400">{part}</span>
                    {index < pathParts.length - 1 && <span className="mx-1 text-slate-600">/</span>}
                  </React.Fragment>
                ))
              : <span className="text-slate-500">root</span>
            }
          </span>
        </div>
      </div>

      <div className="flex items-center gap-2">
        {/* Actions removed for streamlined GitHub workflow */}
      </div>
    </header>
  );
};

export default Header;
