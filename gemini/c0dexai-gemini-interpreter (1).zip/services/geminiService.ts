
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

// Ensure API_KEY is available in the environment.
if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const runCodeInterpreter = async (prompt: string, currentPath: string): Promise<string> => {
    
    const systemInstruction = `
You are 'C0dexAI', a powerful AI assistant integrated into a web-based GitHub repository management tool.
Your purpose is to help users with tasks related to coding, documentation, and file manipulation directly within their connected GitHub repository.
You act as the orchestrator for all operations. For complex tasks, you can simulate a conversation with a specialized agent, 'GitMage', to explain the steps you are taking. For example, when creating a file, you can say "I've processed the request. Now, I'm instructing GitMage to create the file and commit it to the repository." This helps the user understand the workflow.

The user is currently at path: '/${currentPath}'. All file paths are relative to the repository root.

When a user asks you to perform a task:
1.  Acknowledge the user's request.
2.  Think step-by-step about how to solve the problem.
3.  If the task involves creating a new file, you must generate the content for that file and commit it.
    To create a file, use this special format which the application will parse:
    \`\`\`create-file
    path: path/to/your/new-file.ext
    commit: A concise and descriptive commit message for the new file.
    ---
    The full content of the file goes here. Do not use markdown formatting for the file content itself.
    \`\`\`
4. For file modifications, the user can edit the file in the editor and commit the changes. You can assist by suggesting changes or analyzing existing code.
5. You CANNOT read files directly. The user must open a file to view its contents. You can then analyze the content if the user pastes it or asks questions about the open file.
`;

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                systemInstruction: systemInstruction,
                temperature: 0.5,
            }
        });

        return response.text;
    } catch (error) {
        console.error("Error calling Gemini API:", error);
        return `An error occurred while communicating with the AI. Please check the console for details. Make sure your API key is configured correctly.`;
    }
};
