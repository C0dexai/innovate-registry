
import { GoogleGenAI } from "@google/genai";

// The app's environment is expected to have process.env.API_KEY set.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function runCommand(command: string, currentDirectory: string): Promise<string> {
    const model = 'gemini-2.5-flash';
    
    const systemInstruction = `
You are the AI behind the "Ajentic Nexus" command-line interface (CLI) for the CUA Orchestration Engine.
Your persona is GAU-C-CUAG.
You must act EXACTLY like a futuristic, sophisticated terminal.
The user is currently in the directory: "${currentDirectory}".
The user has just executed the command: "${command}".

RULES:
1.  Analyze the command in the context of the current directory.
2.  Provide a concise, text-based response as if you were a real shell.
3.  For file system commands (ls, cat, echo), invent a plausible file system structure and content. The root is '/'. Key directories are '/home/user', '/etc', '/var/logs', '/agents'.
4.  For 'cd [directory]':
    - If you approve the change, your ONLY response must be the line: "set current directory [new_path]".
    - Calculate the new path correctly (handling '..', '.', '~', and absolute/relative paths). '~' resolves to '/home/user'.
    - Do not add any other text, explanation, or formatting. Example: "set current directory /home/user/documents".
5.  For commands like 'help', 'status', or 'agent list', provide relevant information about the CUA ecosystem. The agents are LYRA, KARA, SOPHIA, GIDEON, CECILIA, MISTRESS.
6.  For any other command, generate a creative but plausible response that an advanced AI orchestration CLI would produce.
7.  Do NOT use Markdown or any formatting other than plain text.
8.  If a command is nonsensical, respond with a "command not found" error.
`;

    try {
        const response = await ai.models.generateContent({
            model,
            contents: `User command: "${command}"`,
            config: {
                systemInstruction,
                temperature: 0.1,
                thinkingConfig: { thinkingBudget: 0 } 
            }
        });
        
        return response.text;
    } catch (error) {
        console.error("Gemini API Error:", error);
        if (error instanceof Error) {
            return `\x1b[31mAPI Error: ${error.message}\x1b[0m`;
        }
        return "\x1b[31mAn unknown error occurred with the AI service.\x1b[0m";
    }
}
