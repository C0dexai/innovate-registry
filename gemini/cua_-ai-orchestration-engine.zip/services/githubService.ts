
import { GitHubFile, GitHubUser } from '../types';

const GITHUB_API_BASE = 'https://api.github.com';

const getHeaders = (token: string) => ({
    'Authorization': `Bearer ${token}`,
    'Accept': 'application/vnd.github.v3+json',
    'X-GitHub-Api-Version': '2022-11-28',
});

async function handleResponse<T>(response: Response): Promise<T> {
    if (!response.ok) {
        const errorData = await response.json().catch(() => ({ message: response.statusText }));
        throw new Error(`GitHub API Error: ${errorData.message || 'Unknown error'}`);
    }
    return response.json() as Promise<T>;
}

export const githubService = {
    async getUser(token: string): Promise<GitHubUser> {
        const response = await fetch(`${GITHUB_API_BASE}/user`, {
            headers: getHeaders(token),
        });
        return handleResponse<GitHubUser>(response);
    },

    async getRepoContents(token: string, owner: string, repo: string, path: string = ''): Promise<GitHubFile[]> {
        const url = `${GITHUB_API_BASE}/repos/${owner}/${repo}/contents/${path}`;
        const response = await fetch(url, { headers: getHeaders(token) });
        const files = await handleResponse<GitHubFile[]>(response);
        return files.sort((a, b) => {
            if (a.type === 'dir' && b.type !== 'dir') return -1;
            if (a.type !== 'dir' && b.type === 'dir') return 1;
            return a.name.localeCompare(b.name);
        });
    },

    async getFileContent(token: string, owner: string, repo: string, path: string): Promise<{ content: string; sha: string }> {
        const url = `${GITHUB_API_BASE}/repos/${owner}/${repo}/contents/${path}`;
        const response = await fetch(url, { headers: getHeaders(token) });
        const fileData = await handleResponse<{ content: string, encoding: string, sha: string }>(response);
        if (fileData.encoding !== 'base64') {
            throw new Error('Unsupported file encoding received from GitHub.');
        }
        return { content: atob(fileData.content), sha: fileData.sha };
    },

    async updateFile(token: string, owner: string, repo: string, path: string, content: string, sha: string, commitMessage: string): Promise<void> {
        const url = `${GITHUB_API_BASE}/repos/${owner}/${repo}/contents/${path}`;
        const encodedContent = btoa(content); 
        
        const body = JSON.stringify({
            message: commitMessage,
            content: encodedContent,
            sha: sha,
        });

        const response = await fetch(url, {
            method: 'PUT',
            headers: {
                ...getHeaders(token),
                'Content-Type': 'application/json',
            },
            body,
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(`Failed to update file: ${errorData.message}`);
        }
    },
};
