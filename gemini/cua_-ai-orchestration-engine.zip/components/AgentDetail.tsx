
import React from 'react';
import { Agent } from '../types';

interface AgentDetailProps {
    agent: Agent;
}

const AgentDetail: React.FC<AgentDetailProps> = ({ agent }) => {
    return (
        <div className="bg-gray-800/50 backdrop-blur-lg border border-white/10 rounded-lg p-6 shadow-2xl animate-fade-in">
            <div className="flex flex-col md:flex-row gap-6 items-center">
                <div className="flex-shrink-0 text-center">
                    <div className="w-24 h-24 rounded-full bg-gray-800 flex items-center justify-center mx-auto border-2 border-blue-400">
                        <span className="text-4xl font-bold">{agent.name.charAt(0)}</span>
                    </div>
                    <h2 className="text-2xl font-bold mt-2 text-white">{agent.name}</h2>
                    <p className="text-blue-300">{agent.role}</p>
                </div>
                <div className="flex-grow w-full">
                    <p className="italic text-gray-300 border-l-4 border-blue-400 pl-4 text-lg">
                        "{agent.philosophy}"
                    </p>
                </div>
            </div>
        </div>
    );
};

export default AgentDetail;
