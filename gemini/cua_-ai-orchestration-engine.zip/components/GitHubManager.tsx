
import React, { useState, useEffect, useCallback } from 'react';
import { githubService } from '../services/githubService';
import { GitHubFile, GitHubUser } from '../types';

const FolderIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3 text-yellow-400 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" /></svg>;
const FileIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3 text-gray-400 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>;
const BackIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>;
const Spinner = () => <div className="border-2 border-gray-400 border-t-blue-400 rounded-full w-6 h-6 animate-spin"></div>;

const GitHubManager: React.FC = () => {
    const [token, setToken] = useState('');
    const [owner, setOwner] = useState('');
    const [repo, setRepo] = useState('');
    const [user, setUser] = useState<GitHubUser | null>(null);
    const [files, setFiles] = useState<GitHubFile[]>([]);
    const [currentPath, setCurrentPath] = useState('');
    const [selectedFile, setSelectedFile] = useState<{ path: string; content: string; sha: string } | null>(null);
    const [editedContent, setEditedContent] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [notification, setNotification] = useState<string | null>(null);

    useEffect(() => {
        const savedToken = localStorage.getItem('github_token');
        const savedOwner = localStorage.getItem('github_owner');
        const savedRepo = localStorage.getItem('github_repo');
        if (savedToken) setToken(savedToken);
        if (savedOwner) setOwner(savedOwner);
        if (savedRepo) setRepo(savedRepo);
    }, []);

    const showNotification = (message: string) => {
        setNotification(message);
        setTimeout(() => setNotification(null), 3000);
    };

    const handleConnect = async () => {
        if (!token || !owner || !repo) {
            setError('Token, Owner, and Repo are required.');
            return;
        }
        setIsLoading(true);
        setError(null);
        try {
            const userData = await githubService.getUser(token);
            setUser(userData);
            await fetchFiles('');
            localStorage.setItem('github_token', token);
            localStorage.setItem('github_owner', owner);
            localStorage.setItem('github_repo', repo);
        } catch (e) {
            setError(e instanceof Error ? e.message : 'Failed to connect');
            setUser(null);
        }
        setIsLoading(false);
    };

    const fetchFiles = useCallback(async (path: string) => {
        if (!token || !owner || !repo) return;
        setIsLoading(true);
        setError(null);
        try {
            const fileList = await githubService.getRepoContents(token, owner, repo, path);
            setFiles(fileList);
            setCurrentPath(path);
            setSelectedFile(null);
        } catch (e) {
            setError(e instanceof Error ? e.message : 'Could not fetch files');
        }
        setIsLoading(false);
    }, [token, owner, repo]);

    const handleFileClick = useCallback(async (file: GitHubFile) => {
        if (file.type === 'dir') {
            fetchFiles(file.path);
        } else {
            setIsLoading(true);
            setError(null);
            try {
                const { content, sha } = await githubService.getFileContent(token, owner, repo, file.path);
                setSelectedFile({ path: file.path, content, sha });
                setEditedContent(content);
            } catch (e) {
                setError(e instanceof Error ? e.message : 'Could not fetch file content');
            }
            setIsLoading(false);
        }
    }, [token, owner, repo, fetchFiles]);
    
    const handleGoBack = () => {
        if (currentPath === '') return;
        const parentPath = currentPath.substring(0, currentPath.lastIndexOf('/'));
        fetchFiles(parentPath);
    };

    const handleSave = async () => {
        if (!selectedFile) return;
        setIsLoading(true);
        setError(null);
        const commitMessage = `Update ${selectedFile.path} via CUA Orchestration Engine`;
        try {
            await githubService.updateFile(token, owner, repo, selectedFile.path, editedContent, selectedFile.sha, commitMessage);
            const { content, sha } = await githubService.getFileContent(token, owner, repo, selectedFile.path);
            setSelectedFile({ ...selectedFile, content, sha });
            setEditedContent(content);
            showNotification('File saved successfully!');
        } catch (e) {
            setError(e instanceof Error ? e.message : 'Failed to save file');
        }
        setIsLoading(false);
    };

    if (!user) {
        return (
            <div className="bg-gray-800/50 backdrop-blur-lg border border-white/10 rounded-lg p-8 max-w-lg mx-auto shadow-2xl animate-fade-in">
                <h2 className="text-2xl font-bold text-center text-white mb-6">GitHub Repository Integration</h2>
                <div className="space-y-4">
                    <input type="password" value={token} onChange={e => setToken(e.target.value)} placeholder="GitHub Personal Access Token" className="w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500" />
                    <input type="text" value={owner} onChange={e => setOwner(e.target.value)} placeholder="Repository Owner (e.g., 'google')" className="w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500" />
                    <input type="text" value={repo} onChange={e => setRepo(e.target.value)} placeholder="Repository Name (e.g., 'gemini-api')" className="w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500" />
                    <button onClick={handleConnect} disabled={isLoading} className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-800 disabled:cursor-not-allowed text-white font-bold py-2 px-4 rounded transition-colors duration-300 flex items-center justify-center">
                        {isLoading ? <Spinner /> : 'Connect to Repository'}
                    </button>
                    {error && <p className="text-red-400 text-sm text-center">{error}</p>}
                    <p className="text-xs text-gray-500 text-center pt-2">Your token is stored in browser localStorage. For read/write access, ensure your token has 'repo' scope.</p>
                </div>
            </div>
        );
    }

    return (
        <div className="animate-fade-in">
             <div className="mb-4 text-center">
                <h2 className="text-xl font-bold text-white">GitHub Nexus</h2>
                <p className="text-sm text-blue-300">Overseer: Agent GIDEON</p>
            </div>
            {notification && (
                <div className="fixed top-5 right-5 bg-green-500 text-white py-2 px-4 rounded-lg shadow-lg z-50 animate-fade-in">
                    {notification}
                </div>
            )}
            <div className="bg-gray-800/50 backdrop-blur-lg border border-white/10 p-4 rounded-lg shadow-2xl flex flex-col md:flex-row gap-4 h-[75vh]">
                <div className="w-full md:w-1/3 lg:w-1/4 bg-gray-900/50 rounded-lg p-3 overflow-y-auto">
                    <div className="flex justify-between items-center mb-3 pb-3 border-b border-gray-700">
                        <div className="flex items-center min-w-0">
                             <img src={user.avatar_url} alt={user.login} className="w-8 h-8 rounded-full mr-2 flex-shrink-0" />
                            <div className="min-w-0">
                               <p className="font-bold text-white text-sm truncate">{repo}</p>
                               <p className="text-xs text-gray-400 truncate">{owner}</p>
                            </div>
                        </div>
                         {isLoading && !selectedFile && <Spinner/>}
                    </div>
                    <div className="font-roboto-mono text-sm text-gray-400 mb-3 truncate">/{currentPath}</div>
                    <ul>
                        {currentPath && (
                            <li onClick={handleGoBack} className="flex items-center p-2 rounded-md hover:bg-gray-700 cursor-pointer text-gray-300">
                                <BackIcon /> ..
                            </li>
                        )}
                        {files.map(file => (
                            <li key={file.sha} onClick={() => handleFileClick(file)} className={`flex items-center p-2 rounded-md hover:bg-gray-700 cursor-pointer ${selectedFile?.path === file.path ? 'bg-blue-900/50' : ''}`}>
                                {file.type === 'dir' ? <FolderIcon /> : <FileIcon />}
                                <span className="truncate">{file.name}</span>
                            </li>
                        ))}
                    </ul>
                </div>
                <div className="w-full md:w-2/3 lg:w-3/4 flex flex-col">
                    {selectedFile ? (
                        <div className="flex-grow flex flex-col bg-gray-900/50 rounded-lg">
                            <div className="flex justify-between items-center p-3 bg-gray-800 rounded-t-lg border-b border-gray-700">
                                <h3 className="font-roboto-mono text-white truncate">{selectedFile.path}</h3>
                                <button onClick={handleSave} disabled={isLoading || editedContent === selectedFile.content} className="bg-green-600 hover:bg-green-700 disabled:bg-green-800 disabled:text-gray-400 disabled:cursor-not-allowed text-white font-bold py-1 px-4 text-sm rounded transition-colors duration-300 flex items-center gap-2">
                                    {isLoading ? <Spinner /> : 'Save'}
                                </button>
                            </div>
                            <textarea
                                value={editedContent}
                                onChange={e => setEditedContent(e.target.value)}
                                className="flex-grow w-full p-4 bg-[#1e1e1e] text-gray-300 font-roboto-mono text-sm resize-none rounded-b-lg focus:outline-none"
                                spellCheck="false"
                            />
                        </div>
                    ) : (
                        <div className="flex-grow flex items-center justify-center bg-gray-900/50 rounded-lg">
                            <div className="text-center text-gray-500 p-4">
                                <h3 className="text-xl font-bold">Select a file to view or edit</h3>
                                <p>Navigate the repository on the left.</p>
                                {error && <p className="text-red-400 text-sm mt-4 max-w-md mx-auto">{error}</p>}
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default GitHubManager;
