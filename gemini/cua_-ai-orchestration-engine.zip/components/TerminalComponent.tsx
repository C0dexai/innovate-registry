
import React, { useEffect, useRef, useState, useCallback } from 'react';
import { runCommand } from '../services/geminiService';

declare global {
    interface Window {
        Terminal: any;
        FitAddon: {
            FitAddon: any;
        };
    }
}

const TerminalComponent: React.FC = () => {
    const terminalRef = useRef<HTMLDivElement>(null);
    const termInstance = useRef<any>(null);

    const [currentDirectory, setCurrentDirectory] = useState('/home/user');
    const [isLoading, setIsLoading] = useState(false);
    
    const stateRef = useRef({
        currentDirectory: '/home/user',
        commandHistory: [] as string[],
        historyIndex: 0,
        currentCommand: '',
    });

    useEffect(() => {
        stateRef.current.currentDirectory = currentDirectory;
    }, [currentDirectory]);

    const writePrompt = useCallback((term: any) => {
        const dirName = stateRef.current.currentDirectory.split('/').pop() || '/';
        term?.write(`\r\n\x1b[36m${dirName}> \x1b[0m`);
    }, []);

    const handleCliCommand = useCallback(async (command: string) => {
        setIsLoading(true);
        
        let output = '';
        try {
            output = await runCommand(command, stateRef.current.currentDirectory);
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
            output = `\r\n\x1b[31mError: ${errorMessage}\x1b[0m`;
        }

        setIsLoading(false);

        const cdMatch = output.match(/^set current directory (.+?)$/im);
        if (cdMatch && cdMatch[1]) {
            setCurrentDirectory(cdMatch[1].trim());
        } else {
            const formattedOutput = output.replace(/\n/g, '\r\n');
            termInstance.current?.write('\r\n' + formattedOutput);
        }
        
        writePrompt(termInstance.current);
        termInstance.current?.scrollToBottom();
    }, [writePrompt]);

    useEffect(() => {
        if (!terminalRef.current || termInstance.current) return;
        
        const { Terminal, FitAddon } = window;
        if (!Terminal || !FitAddon || !FitAddon.FitAddon) {
            console.error("xterm.js or fit addon not loaded correctly. Ensure scripts are in index.html.");
            return;
        }

        const term = new Terminal({
            cursorBlink: true, convertEol: true, fontFamily: `'Roboto Mono', monospace`,
            theme: { background: '#000000', foreground: '#00FF00', cursor: 'rgba(0, 255, 0, 0.5)' }
        });
        const fitAddon = new FitAddon.FitAddon();
        termInstance.current = term;

        term.loadAddon(fitAddon);
        term.open(terminalRef.current);
        fitAddon.fit();
        
        term.writeln('Welcome to the Ajentic Nexus CLI. Now powered by Gemini.');
        writePrompt(term);

        const onKeyHandler = term.onKey(({ key, domEvent }: { key: string, domEvent: KeyboardEvent }) => {
            if (isLoading) return;
            const printable = !domEvent.altKey && !domEvent.ctrlKey && !domEvent.metaKey;

            const updateInput = (newCommand: string) => {
                const dirName = stateRef.current.currentDirectory.split('/').pop() || '/';
                const promptText = `\x1b[36m${dirName}> \x1b[0m`;
                term.write('\x1b[2K\r' + promptText + newCommand);
                stateRef.current.currentCommand = newCommand;
            };

            if (domEvent.key === "ArrowUp") {
                if (stateRef.current.historyIndex > 0) {
                    stateRef.current.historyIndex--;
                    updateInput(stateRef.current.commandHistory[stateRef.current.historyIndex]);
                }
            } else if (domEvent.key === "ArrowDown") {
                if (stateRef.current.historyIndex < stateRef.current.commandHistory.length - 1) {
                    stateRef.current.historyIndex++;
                    updateInput(stateRef.current.commandHistory[stateRef.current.historyIndex]);
                } else {
                    stateRef.current.historyIndex = stateRef.current.commandHistory.length;
                    updateInput('');
                }
            } else if (domEvent.keyCode === 13) {
                if (stateRef.current.currentCommand.trim()) {
                    term.writeln('');
                    const command = stateRef.current.currentCommand;
                    if (stateRef.current.commandHistory[stateRef.current.commandHistory.length -1] !== command) {
                        stateRef.current.commandHistory.push(command);
                    }
                    stateRef.current.historyIndex = stateRef.current.commandHistory.length;
                    stateRef.current.currentCommand = '';
                    handleCliCommand(command);
                } else {
                    writePrompt(term);
                }
            } else if (domEvent.keyCode === 8) {
                const dirName = stateRef.current.currentDirectory.split('/').pop() || '/';
                if (term.buffer.active.cursorX > (dirName.length + 2)) {
                    stateRef.current.currentCommand = stateRef.current.currentCommand.slice(0, -1);
                    term.write('\b \b');
                }
            } else if (printable && domEvent.key.length === 1) {
                stateRef.current.currentCommand += key;
                term.write(key);
            }
        });

        const resizeObserver = new ResizeObserver(() => { fitAddon.fit(); });
        if (terminalRef.current) {
            resizeObserver.observe(terminalRef.current);
        }

        return () => {
            onKeyHandler.dispose();
            term.dispose();
            if (terminalRef.current) {
                resizeObserver.unobserve(terminalRef.current);
            }
            termInstance.current = null;
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []); 

    return (
      <div className="bg-gray-800/50 backdrop-blur-lg border border-white/10 p-4 rounded-lg shadow-2xl relative">
        <h3 className="text-xl font-bold text-center mb-4 text-white">Agent Command Line Interface (A2A / CUAG)</h3>
        {isLoading && (
            <div className="absolute top-6 right-6 flex items-center gap-2 text-sm text-blue-300">
                <div className="border-2 border-gray-400 border-t-blue-400 rounded-full w-4 h-4 animate-spin"></div>
                <span>Executing...</span>
            </div>
        )}
        <div ref={terminalRef} className="p-2 bg-black rounded-lg h-[60vh]"></div>
      </div>
    );
};

export default TerminalComponent;
