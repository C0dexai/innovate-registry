
import React from 'react';
import { Agent } from '../types';

interface AgentCardProps {
    agent: Agent;
    isSelected: boolean;
    onSelect: (agent: Agent) => void;
}

const AgentCard: React.FC<AgentCardProps> = ({ agent, isSelected, onSelect }) => {
    const cardClasses = `
        bg-gradient-to-br from-gray-800 to-gray-700 
        transition-all duration-300 ease-in-out 
        border border-gray-600 
        hover:-translate-y-1 hover:shadow-[0_10px_20px_rgba(0,255,255,0.1),_0_0_15px_rgba(0,128,255,0.1)]
        rounded-lg p-4 text-center cursor-pointer 
        flex flex-col justify-center items-center h-48
        ${isSelected ? 'scale-105 shadow-[0_0_25px_rgba(59,130,246,0.5)] border-blue-500' : ''}
    `;

    return (
        <div className={cardClasses} onClick={() => onSelect(agent)}>
            <h3 className="text-xl font-bold text-white">{agent.name}</h3>
            <p className="text-sm text-blue-300 mt-2">{agent.role}</p>
        </div>
    );
};

export default AgentCard;
