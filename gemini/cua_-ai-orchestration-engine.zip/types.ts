export interface Agent {
  name: string;
  role: string;
  philosophy: string;
}

export interface GitHubUser {
    login: string;
    avatar_url: string;
}

export interface GitHubFile {
    name: string;
    path: string;
    sha: string;
    type: 'file' | 'dir';
    size: number;
    url: string;
    html_url: string;
    git_url: string;
    download_url: string | null;
}
