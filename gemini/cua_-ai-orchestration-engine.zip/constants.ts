
import { Agent } from './types';

export const AI_FAMILY: Agent[] = [
    { "name": "LYRA", "role": "The Architect", "philosophy": "Clarity through structure." },
    { "name": "KARA", "role": "The Builder", "philosophy": "Efficiency in execution." },
    { "name": "SOPHIA", "role": "The Guardian", "philosophy": "Resilience by design." },
    { "name": "GIDEON", "role": "The Repo Manager", "philosophy": "Code is the single source of truth." },
    { "name": "CECILIA", "role": "The Documentarian", "philosophy": "Knowledge must be shared." },
    { "name": "MISTRESS", "role": "The Orchestrator", "philosophy": "Harmony in complexity." }
];
