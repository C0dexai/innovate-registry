
import React, { useState } from 'react';
import { Agent } from './types';
import { AI_FAMILY } from './constants';
import Header from './components/Header';
import AgentCard from './components/AgentCard';
import AgentDetail from './components/AgentDetail';
import TerminalComponent from './components/TerminalComponent';

type Tab = 'agentic' | 'ajentic';

interface TabButtonProps {
    tabId: Tab;
    activeTab: Tab;
    onClick: (tabId: Tab) => void;
    children: React.ReactNode;
}

const TabButton: React.FC<TabButtonProps> = ({ tabId, activeTab, onClick, children }) => {
    const isActive = activeTab === tabId;
    const classes = `
        py-2 px-6 rounded-t-lg transition-colors duration-200
        border-b-2 font-medium
        relative
        ${isActive
            ? 'border-indigo-500 text-white'
            : 'border-transparent text-gray-400 hover:text-white hover:border-gray-500'}
    `;
    return (
        <button onClick={() => onClick(tabId)} className={classes}>
            {children}
        </button>
    );
};


const App: React.FC = () => {
    const [activeTab, setActiveTab] = useState<Tab>('agentic');
    const [selectedAgent, setSelectedAgent] = useState<Agent | null>(null);

    const handleSelectAgent = (agent: Agent) => {
        setSelectedAgent(agent);
    };

    return (
        <div className="container mx-auto p-4 md:p-8 min-h-screen flex flex-col">
            <Header />

            <div className="mb-8 border-b border-gray-700 flex justify-center flex-wrap">
                <TabButton tabId="agentic" activeTab={activeTab} onClick={setActiveTab}>AGENTIC CORE</TabButton>
                <TabButton 
                    tabId="ajentic" 
                    activeTab={activeTab} 
                    onClick={setActiveTab}
                >
                    AJENTIC NEXUS
                </TabButton>
            </div>
            
            <main className="flex-grow relative">
                 {activeTab === 'agentic' && (
                    <div className="animate-fade-in">
                        <h2 className="text-2xl font-bold text-white mb-6 text-center">AI Family Agents</h2>
                        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 md:gap-6 mb-8">
                            {AI_FAMILY.map((agent) => (
                                <AgentCard
                                    key={agent.name}
                                    agent={agent}
                                    isSelected={selectedAgent?.name === agent.name}
                                    onSelect={handleSelectAgent}
                                />
                            ))}
                        </div>
                        {selectedAgent ? (
                            <AgentDetail agent={selectedAgent} />
                        ) : (
                            <div className="bg-gray-800/50 backdrop-blur-lg border border-white/10 rounded-lg p-6 shadow-2xl text-center">
                                <h2 className="text-2xl font-bold text-white mb-2">Select an Agent</h2>
                                <p className="text-gray-300">Choose an AI Family member to view their profile.</p>
                            </div>
                        )}
                    </div>
                )}

                {activeTab === 'ajentic' && (
                     <div className="animate-fade-in">
                        <TerminalComponent />
                     </div>
                )}
            </main>

            <footer className="text-center text-xs text-gray-600 p-4 font-roboto-mono mt-8">
                GAU-C-CUAG | ECOSYSTEM PRIMER: A3 | SIMULATION NETWORK: 255.8.8.8
            </footer>
        </div>
    );
};

export default App;
