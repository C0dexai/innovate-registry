import React from 'react';
import { BrainCircuitIcon } from './icons';

const Header: React.FC = () => {
  return (
    <header className="py-4 px-4 sm:px-6 lg:px-8 bg-brand-primary/80 backdrop-blur-sm border-b border-neon-blue/20 sticky top-0 z-10">
      <div className="container mx-auto flex items-center justify-center">
        <div className="flex items-center gap-3">
          <BrainCircuitIcon />
          <h1 className="text-2xl sm:text-3xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-r from-neon-blue to-neon-pink">
            AI Persona Generator
          </h1>
        </div>
      </div>
    </header>
  );
};

export default Header;
