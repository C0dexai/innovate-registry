
import React, { useState } from 'react';
import { ChevronUpIcon, ChevronDownIcon } from './icons';

const Footer: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <footer className="w-full bg-brand-secondary/80 backdrop-blur-md sticky bottom-0 z-20 border-t border-neon-blue/20 shadow-[0_-4px_15px_rgba(0,229,255,0.1)]">
      <div className="container mx-auto text-center">
        <button 
          onClick={() => setIsOpen(!isOpen)}
          className="w-full py-1 text-brand-text-secondary hover:text-neon-blue transition-colors flex items-center justify-center gap-2"
          aria-expanded={isOpen}
          aria-controls="footer-content"
        >
          {isOpen ? <ChevronDownIcon /> : <ChevronUpIcon />}
          <span className="text-xs font-bold">{isOpen ? 'Hide Details' : 'Show Details'}</span>
        </button>
        <div
          id="footer-content"
          className={`overflow-hidden transition-all duration-300 ease-in-out ${isOpen ? 'max-h-40 opacity-100' : 'max-h-0 opacity-0'}`}
        >
          <div className="py-4 px-4 sm:px-6 lg:px-8 text-sm text-brand-text-secondary">
            <p>Powered by React, Tailwind CSS, and Google Gemini API.</p>
            <p className="text-xs mt-2">UI designed for creativity and exploration.</p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
