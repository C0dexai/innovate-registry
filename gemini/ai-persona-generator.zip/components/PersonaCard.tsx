import React, { useState, useEffect, useRef } from 'react';
import type { GeneratedContent, Persona } from '../types';
import { BookOpenIcon, DnaIcon, TargetIcon, UserIcon, DownloadIcon, SaveIcon, PhotoIcon } from './icons';
import LoadingSpinner from './LoadingSpinner';


interface PersonaCardProps {
  content: GeneratedContent;
  onSave: () => void;
  isSaved: boolean;
  onGenerateVariation: () => void;
  isGeneratingVariation: boolean;
}

const DetailSection: React.FC<{ icon: React.ReactNode; title: string; children: React.ReactNode; }> = ({ icon, title, children }) => (
    <div>
        <h3 className="text-lg font-bold text-neon-blue flex items-center gap-2 mb-2">
            {icon}
            {title}
        </h3>
        {children}
    </div>
);


const PersonaCard: React.FC<PersonaCardProps> = ({ content, onSave, isSaved, onGenerateVariation, isGeneratingVariation }) => {
  const { persona, imageUrl, imageVariations = [] } = content;
  const [activeImageUrl, setActiveImageUrl] = useState(imageUrl);
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Reset active image when the persona content changes to show the primary image first.
    setActiveImageUrl(imageUrl);
  }, [imageUrl]);

  const handleDownload = () => {
    // This function remains largely the same but will download the currently active image.
    // A simplified HTML structure is used for the download.
    const styles = `
        <style>
            body { background-color: #1C1C1E; color: #F5F5F7; font-family: 'Inter', sans-serif; padding: 2rem; }
            .card-container { background-color: rgba(42, 42, 46, 0.6); border: 1px solid rgba(208, 0, 255, 0.3); border-radius: 1rem; box-shadow: 0 0 15px rgba(208, 0, 255, 0.5); overflow: hidden; }
            .grid { display: grid; }
            .lg-grid-cols-3 { grid-template-columns: repeat(3, minmax(0, 1fr)); }
            .lg-col-span-1 { grid-column: span 1 / span 1; }
            .lg-col-span-2 { grid-column: span 2 / span 2; }
            .p-8 { padding: 2rem; } .p-6 { padding: 1.5rem; }
            .space-y-6 > * + * { margin-top: 1.5rem; }
            .font-display { font-family: 'Orbitron', sans-serif; }
            .text-4xl { font-size: 2.25rem; line-height: 2.5rem; }
            .font-bold { font-weight: 700; }
            .text-xl { font-size: 1.25rem; line-height: 1.75rem; }
            .mt-1 { margin-top: 0.25rem; }
            .text-brand-text-secondary { color: #A9B1D6; }
            .leading-relaxed { line-height: 1.625; }
            .md-grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
            .gap-6 { gap: 1.5rem; }
            ul { list-style: none; padding: 0; }
            li { display: flex; align-items: flex-start; }
            .mr-2 { margin-right: 0.5rem; } .mt-1 { margin-top: 0.25rem; }
            .text-neon-blue { color: #00E5FF; } .text-neon-pink { color: #FF007F; }
            .text-sm { font-size: 0.875rem; line-height: 1.25rem; }
            .italic { font-style: italic; }
            .bg-black-20 { background-color: rgba(0,0,0,0.2); }
            .rounded-md { border-radius: 0.375rem; }
            .p-3 { padding: 0.75rem; }
            img { border-radius: 0.5rem; width: 100%; height: auto; object-fit: cover; border: 2px solid rgba(208, 0, 255, 0.5); }
            .gradient-text { background-image: linear-gradient(to right, #00E5FF, #FF007F); -webkit-background-clip: text; background-clip: text; color: transparent; }
        </style>
    `;
    const cardHtml = `
      <div class="card-container">
        <div class="grid lg-grid-cols-3">
          <div class="lg-col-span-1 p-6"><img src="${activeImageUrl}" alt="Portrait of ${persona.name}" /></div>
          <div class="lg-col-span-2 p-6 space-y-6">
            <header>
              <h2 class="text-4xl font-display font-bold gradient-text">${persona.name}</h2>
              <p class="text-xl text-brand-text-secondary mt-1">${persona.age} - ${persona.occupation}</p>
            </header>
            <div>
              <h3 class="text-lg font-bold text-neon-blue">Backstory</h3>
              <p class="text-brand-text-secondary leading-relaxed">${persona.backstory}</p>
            </div>
            <div class="grid md-grid-cols-2 gap-6">
              <div>
                <h3 class="text-lg font-bold text-neon-blue">Personality Traits</h3>
                <ul>${persona.personalityTraits.map(trait => `<li><span class="text-neon-blue mr-2 mt-1">&#9679;</span><span class="text-brand-text-secondary">${trait}</span></li>`).join('')}</ul>
              </div>
              <div>
                <h3 class="text-lg font-bold text-neon-blue">Motivations</h3>
                <ul>${persona.motivations.map(motivation => `<li><span class="text-neon-pink mr-2 mt-1">&#9679;</span><span class="text-brand-text-secondary">${motivation}</span></li>`).join('')}</ul>
              </div>
            </div>
            <div>
              <h3 class="text-lg font-bold text-neon-blue">Image Prompt</h3>
              <p class="text-brand-text-secondary/70 text-sm italic leading-relaxed bg-black-20 p-3 rounded-md">"${persona.imageDescription}"</p>
            </div>
          </div>
        </div>
      </div>
    `;
    const fullHtml = `
      <!DOCTYPE html>
      <html lang="en">
        <head>
          <meta charset="UTF-8" />
          <link rel="preconnect" href="https://fonts.googleapis.com">
          <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
          <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700&family=Orbitron:wght@700&display=swap" rel="stylesheet">
          <title>${persona.name} - Persona</title>
          ${styles}
        </head>
        <body>${cardHtml}</body>
      </html>
    `;
    const blob = new Blob([fullHtml], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${persona.name.replace(/\s+/g, '_')}_persona.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };
  
  return (
    <div ref={cardRef} className="bg-brand-secondary/60 backdrop-blur-lg rounded-2xl shadow-neon-purple overflow-hidden border border-neon-purple/30 relative">
       <div className="persona-actions absolute top-4 right-4 flex gap-2 z-10">
            <button
                onClick={handleDownload}
                className="bg-brand-primary/50 backdrop-blur-sm p-2 rounded-full text-brand-text-secondary hover:text-white hover:bg-neon-blue transition-all"
                title="Download as HTML"
            >
                <DownloadIcon />
            </button>
            <button
                onClick={onSave}
                disabled={isSaved}
                className="bg-brand-primary/50 backdrop-blur-sm p-2 rounded-full text-brand-text-secondary hover:text-white hover:bg-neon-blue disabled:bg-neon-blue/60 disabled:text-black disabled:cursor-not-allowed transition-all"
                title={isSaved ? "Persona Saved" : "Save Persona"}
            >
                <SaveIcon filled={isSaved} />
            </button>
        </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-0">
        <div className="lg:col-span-1 p-4 sm:p-6 flex flex-col items-center justify-center gap-4">
          <div className="relative w-full">
            <img
              src={activeImageUrl}
              alt={`Portrait of ${persona.name}`}
              className="rounded-lg object-cover w-full aspect-[3/4] shadow-lg border-2 border-neon-purple/50 transition-all"
            />
            {imageVariations.length < 5 && (
              <button 
                onClick={onGenerateVariation} 
                disabled={isGeneratingVariation}
                className="absolute bottom-3 right-3 bg-brand-primary/80 backdrop-blur-md text-white font-semibold py-2 px-4 rounded-lg text-sm flex items-center gap-2 border border-neon-blue/50 hover:bg-neon-blue hover:text-black transition-all disabled:bg-neutral-600 disabled:cursor-wait"
              >
                {isGeneratingVariation ? <LoadingSpinner className="w-5 h-5"/> : <PhotoIcon />}
                <span>Generate Variation ({imageVariations.length}/5)</span>
              </button>
            )}
          </div>
          {(imageVariations.length > 0 || imageUrl) && (
            <div className="w-full">
              <h4 className="text-xs font-bold text-brand-text-secondary mb-2 text-center">Variations</h4>
              <div className="grid grid-cols-5 gap-2">
                {[imageUrl, ...imageVariations].map((url, index) => (
                  <button key={index} onClick={() => setActiveImageUrl(url)} className={`rounded-md overflow-hidden border-2 transition-all ${activeImageUrl === url ? 'border-neon-blue shadow-neon-blue' : 'border-transparent hover:border-neon-blue/50'}`}>
                    <img src={url} alt={`Variation ${index}`} className="w-full h-full object-cover aspect-square"/>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
        <div className="lg:col-span-2 p-6 sm:p-8 space-y-6">
          <header>
            <h2 className="text-4xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-r from-neon-blue to-neon-pink">
              {persona.name}
            </h2>
            <p className="text-xl text-brand-text-secondary mt-1">{persona.age} - {persona.occupation}</p>
          </header>

          <DetailSection icon={<BookOpenIcon />} title="Backstory">
            <p className="text-brand-text-secondary leading-relaxed">{persona.backstory}</p>
          </DetailSection>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <DetailSection icon={<DnaIcon />} title="Personality Traits">
                <ul className="space-y-1">
                    {persona.personalityTraits.map((trait, index) => (
                        <li key={index} className="flex items-start">
                            <span className="text-neon-blue mr-2 mt-1">&#9679;</span>
                            <span className="text-brand-text-secondary">{trait}</span>
                        </li>
                    ))}
                </ul>
            </DetailSection>

            <DetailSection icon={<TargetIcon />} title="Motivations">
                 <ul className="space-y-1">
                    {persona.motivations.map((motivation, index) => (
                        <li key={index} className="flex items-start">
                             <span className="text-neon-pink mr-2 mt-1">&#9679;</span>
                            <span className="text-brand-text-secondary">{motivation}</span>
                        </li>
                    ))}
                </ul>
            </DetailSection>
          </div>
           
           <DetailSection icon={<UserIcon />} title="Image Prompt">
            <p className="text-brand-text-secondary/70 text-sm italic leading-relaxed bg-black/20 p-3 rounded-md">"{persona.imageDescription}"</p>
          </DetailSection>
        </div>
      </div>
    </div>
  );
};

export default PersonaCard;