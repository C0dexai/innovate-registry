
import React, { useState, useCallback, useEffect } from 'react';
import { GeneratedContent, AIFamilyMember } from './types';
import { getAIPersona, getAIPersonaFromCustomPrompt, getAIPersonaFromImagesAndPrompt, generateImageVariation } from './services/geminiService';
import { initDB, getPersonas, savePersona } from './services/dbService';
import Header from './components/Header';
import Footer from './components/Footer';
import LoadingSpinner from './components/LoadingSpinner';
import PersonaCard from './components/PersonaCard';
import { aiFamily } from './aiFamilyConfig';
import { BrainCircuitIcon, WandIcon, UploadIcon, PhotoIcon, InformationCircleIcon, XIcon } from './components/icons';

interface UploadedFile {
  name: string;
  type: string;
  data: string;
  mimeType: string;
}

const App: React.FC = () => {
  const [dbReady, setDbReady] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [customPrompt, setCustomPrompt] = useState('');
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [generatedContent, setGeneratedContent] = useState<GeneratedContent | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isGeneratingVariation, setIsGeneratingVariation] = useState<boolean>(false);
  const [savedPersonas, setSavedPersonas] = useState<GeneratedContent[]>([]);

  useEffect(() => {
    const initialize = async () => {
      try {
        await initDB();
        setDbReady(true);
        const personas = await getPersonas();
        setSavedPersonas(personas);
      } catch (e: any) {
        setError(e.message || "Failed to initialize database.");
      }
    };
    initialize();
  }, []);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) {
      const files = Array.from(event.target.files);
      const filePromises = files.map(file => {
        return new Promise<UploadedFile>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = e => {
            const base64Data = (e.target?.result as string).split(',')[1];
            resolve({ name: file.name, type: file.type, data: base64Data, mimeType: file.type });
          };
          reader.onerror = reject;
          reader.readAsDataURL(file);
        });
      });

      Promise.all(filePromises)
        .then(newFiles => setUploadedFiles(prev => [...prev, ...newFiles].slice(0, 5))) // Limit to 5 files
        .catch(err => setError("Error reading files."));
    }
  };

  const removeFile = (fileName: string) => {
    setUploadedFiles(files => files.filter(file => file.name !== fileName));
  };
  
  const handleGenerate = async (promptGenerator: () => Promise<GeneratedContent>) => {
    setIsLoading(true);
    setError(null);
    setGeneratedContent(null);
    try {
      const content = await promptGenerator();
      setGeneratedContent(content);
    } catch (e: any) {
      console.error(e);
      setError(e.message || "An unexpected error occurred during generation.");
    } finally {
      setIsLoading(false);
    }
  };

  const handlePresetSelect = (familyMember: AIFamilyMember) => {
    handleGenerate(() => getAIPersona(familyMember));
  };
  
  const handleCustomPromptSubmit = () => {
    if (!customPrompt && uploadedFiles.length === 0) {
      setError("Please provide a prompt or upload an image.");
      return;
    }

    if (uploadedFiles.length > 0) {
        const imagePayload = uploadedFiles.map(f => ({ mimeType: f.mimeType, data: f.data }));
        handleGenerate(() => getAIPersonaFromImagesAndPrompt(customPrompt, imagePayload));
    } else {
        handleGenerate(() => getAIPersonaFromCustomPrompt(customPrompt));
    }
  };
  
  const handleGenerateVariation = async () => {
    if (!generatedContent) return;
    setIsGeneratingVariation(true);
    try {
      const newImageUrl = await generateImageVariation(generatedContent.persona, generatedContent.imageVariations?.length || 0);
      setGeneratedContent(prev => {
        if (!prev) return null;
        const updatedContent = {
          ...prev,
          imageVariations: [...(prev.imageVariations || []), newImageUrl]
        };
        // If this persona is already saved, update it in IndexedDB
        if (savedPersonas.some(p => p.id === prev.id)) {
            savePersona(updatedContent);
            setSavedPersonas(saved => saved.map(p => p.id === updatedContent.id ? updatedContent : p));
        }
        return updatedContent;
      });
    } catch (e: any) {
      setError(e.message || 'Failed to generate variation.');
    } finally {
      setIsGeneratingVariation(false);
    }
  };

  const handleSave = async () => {
    if (!generatedContent || !dbReady) return;
    try {
      await savePersona(generatedContent);
      if (!savedPersonas.some(p => p.id === generatedContent.id)) {
          setSavedPersonas(prev => [...prev, generatedContent]);
      }
    } catch (e: any) {
      setError(e.message || "Failed to save persona.");
    }
  };

  const isSaved = (contentId: string) => savedPersonas.some(p => p.id === contentId);

  return (
    <div className="min-h-screen bg-brand-primary flex flex-col font-sans">
      <Header />
      <main className="flex-grow container mx-auto p-4 sm:p-6 lg:p-8 flex flex-col gap-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
          <aside className="lg:col-span-1 bg-brand-secondary/50 rounded-2xl border border-neon-blue/20 p-6 shadow-lg flex flex-col gap-6 sticky top-24">
            <div>
              <h2 className="text-2xl font-display text-neon-blue mb-4">Generate Persona</h2>
              <p className="text-sm text-brand-text-secondary mb-4 flex items-start gap-2">
                <InformationCircleIcon className="w-5 h-5 mt-0.5 text-neon-blue/80 flex-shrink-0" />
                <span>Use a preset, or create your own with a custom prompt. You can also upload images as inspiration.</span>
              </p>
            </div>
            
            <div className="space-y-4">
              <textarea
                value={customPrompt}
                onChange={(e) => setCustomPrompt(e.target.value)}
                placeholder="E.g., 'A grizzled space pirate captain' or describe a character from an image..."
                className="w-full bg-brand-primary/70 border border-neon-blue/30 rounded-lg p-3 focus:ring-2 focus:ring-neon-blue focus:outline-none transition-all h-24 text-brand-text-secondary placeholder-brand-text-secondary/50"
                aria-label="Custom Persona Prompt"
              />
              <div className="flex flex-col gap-3">
                 <label className="w-full flex items-center justify-center gap-2 bg-brand-primary/70 border border-dashed border-neon-blue/30 rounded-lg p-3 hover:bg-neon-blue/10 transition-colors cursor-pointer text-brand-text-secondary">
                    <UploadIcon className="w-5 h-5"/>
                    <span>Upload Images ({uploadedFiles.length}/5)</span>
                    <input type="file" multiple accept="image/png, image/jpeg, image/webp" onChange={handleFileChange} className="hidden" />
                 </label>
                 {uploadedFiles.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                        {uploadedFiles.map(file => (
                            <div key={file.name} className="bg-brand-secondary text-xs rounded-full py-1 px-3 flex items-center gap-2">
                                <span>{file.name}</span>
                                <button onClick={() => removeFile(file.name)} className="text-brand-text-secondary hover:text-neon-pink">
                                    <XIcon className="w-3 h-3"/>
                                </button>
                            </div>
                        ))}
                    </div>
                 )}
              </div>
              <button
                onClick={handleCustomPromptSubmit}
                disabled={isLoading}
                className="w-full bg-gradient-to-r from-neon-blue to-neon-pink text-black font-bold py-3 px-4 rounded-lg flex items-center justify-center gap-2 hover:shadow-neon-blue transition-all disabled:opacity-50"
              >
                <WandIcon />
                <span>Generate Custom</span>
              </button>
            </div>
            
            <div>
                <h3 className="text-xl font-display text-neon-blue/90 my-4">...or use a preset</h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-2 gap-2">
                    {aiFamily.map((member) => (
                        <button
                            key={member.name}
                            onClick={() => handlePresetSelect(member)}
                            disabled={isLoading}
                            className="p-3 bg-brand-primary/70 rounded-lg border border-neon-blue/20 text-left hover:bg-neon-blue/10 transition-colors disabled:opacity-50"
                            title={member.persona}
                        >
                            <p className="font-bold text-sm text-brand-text">{member.name}</p>
                            <p className="text-xs text-brand-text-secondary">{member.title}</p>
                        </button>
                    ))}
                </div>
            </div>
          </aside>

          <div className="lg:col-span-2 flex flex-col gap-8">
            {isLoading && (
              <div className="flex flex-col items-center justify-center h-96 bg-brand-secondary/30 rounded-2xl gap-4">
                  <LoadingSpinner className="w-12 h-12 text-neon-blue"/>
                  <p className="text-brand-text-secondary text-lg animate-pulse">Generating your persona...</p>
              </div>
            )}
            {error && <div className="p-4 bg-red-900/50 border border-red-500 text-red-300 rounded-lg">{error}</div>}
            
            {generatedContent && (
                <div className="animate-fade-in">
                    <PersonaCard 
                        content={generatedContent} 
                        onSave={handleSave}
                        isSaved={isSaved(generatedContent.id)}
                        onGenerateVariation={handleGenerateVariation}
                        isGeneratingVariation={isGeneratingVariation}
                    />
                </div>
            )}

            {!isLoading && !generatedContent && (
                <div className="flex flex-col items-center justify-center h-96 bg-brand-secondary/30 rounded-2xl gap-4 text-center p-8 border border-dashed border-neon-blue/20">
                    <BrainCircuitIcon />
                    <h2 className="text-2xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-r from-neon-blue to-neon-pink">Your Persona Awaits</h2>
                    <p className="text-brand-text-secondary max-w-sm">Use the panel on the left to generate a new character persona. Your creations will appear here.</p>
                </div>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default App;
