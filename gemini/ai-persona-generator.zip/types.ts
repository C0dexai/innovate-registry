
export interface Persona {
  name: string;
  age: number;
  occupation: string;
  backstory: string;
  personalityTraits: string[];
  motivations: string[];
  imageDescription: string;
}

export interface GeneratedContent {
  id: string;
  prompt: string;
  persona: Persona;
  imageUrl: string;
  imageVariations?: string[];
}

export interface AIFamilyMember {
  name: string;
  title: string;
  role: string;
  persona: string;
  model: string;
  prompt: string;
}

export interface FileSystemNode {
  name: string;
  type: 'file' | 'folder';
  path: string;
  content?: string;
  children?: FileSystemNode[];
}

export interface CommitLogEntry {
  message: string;
  path: string;
  timestamp: Date;
}
