import { GeneratedContent } from '../types';

const DB_NAME = 'PersonaDB';
const DB_VERSION = 1;
const STORE_NAME = 'personas';

let db: IDBDatabase;

export const initDB = (): Promise<boolean> => {
  return new Promise((resolve, reject) => {
    // Prevent re-opening the database if it's already open
    if (db) {
      return resolve(true);
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => {
      console.error('Database error:', request.error);
      reject(`Database error: ${request.error?.message}`);
    };

    request.onsuccess = () => {
      db = request.result;
      resolve(true);
    };

    request.onupgradeneeded = (event) => {
      const dbInstance = (event.target as IDBOpenDBRequest).result;
      if (!dbInstance.objectStoreNames.contains(STORE_NAME)) {
        dbInstance.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
  });
};

const getStore = (mode: IDBTransactionMode) => {
    if (!db) {
        throw new Error("DB not initialized. Call initDB first.");
    }
    const transaction = db.transaction([STORE_NAME], mode);
    return transaction.objectStore(STORE_NAME);
}

export const savePersona = (persona: GeneratedContent): Promise<void> => {
  return new Promise((resolve, reject) => {
    const store = getStore('readwrite');
    const request = store.put(persona); // Use 'put' to allow both adding and updating
    request.onsuccess = () => resolve();
    request.onerror = () => {
        console.error('Error saving persona:', request.error);
        reject('Error saving persona');
    }
  });
};

export const getPersonas = (): Promise<GeneratedContent[]> => {
  return new Promise((resolve, reject) => {
    const store = getStore('readonly');
    const request = store.getAll();

    request.onsuccess = () => {
      resolve(request.result);
    };
    request.onerror = () => {
      console.error('Error getting personas:', request.error);
      reject('Error getting personas');
    };
  });
};

export const deletePersona = (id: string): Promise<void> => {
    return new Promise((resolve, reject) => {
        const store = getStore('readwrite');
        const request = store.delete(id);
        request.onsuccess = () => resolve();
        request.onerror = () => {
            console.error('Error deleting persona:', request.error);
            reject('Error deleting persona');
        }
    });
};

export const clearPersonas = (): Promise<void> => {
    return new Promise((resolve, reject) => {
        const store = getStore('readwrite');
        const request = store.clear();
        request.onsuccess = () => resolve();
        request.onerror = () => {
            console.error('Error clearing personas:', request.error);
            reject('Error clearing personas');
        }
    });
}