import { GoogleGenAI, Type, GenerateContentResponse, Part } from "@google/genai";
import { Persona, GeneratedContent, AIFamilyMember } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const personaSchema = {
  type: Type.OBJECT,
  properties: {
    name: { type: Type.STRING, description: "The character's full name." },
    age: { type: Type.INTEGER, description: "The character's age." },
    occupation: { type: Type.STRING, description: "The character's primary occupation or role." },
    backstory: { type: Type.STRING, description: "A detailed backstory for the character, at least 3-4 sentences long." },
    personalityTraits: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "A list of 3-5 key personality traits."
    },
    motivations: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "A list of 2-3 core motivations or goals."
    },
    imageDescription: {
      type: Type.STRING,
      description: "A detailed, descriptive prompt for an AI image generator to create a photorealistic portrait. Include details about appearance, clothing, expression, and background setting. Style: cinematic, dramatic lighting."
    }
  },
  required: ["name", "age", "occupation", "backstory", "personalityTraits", "motivations", "imageDescription"]
};

interface GenerateImagesResponse {
  generatedImages: {
    image: {
      imageBytes: string;
    };
  }[];
}

const withRetry = async <T>(fn: () => Promise<T>, retries = 3, initialDelay = 1000): Promise<T> => {
    let lastError: Error = new Error("An unknown error occurred after retries.");
    for (let i = 0; i < retries; i++) {
        try {
            return await fn();
        } catch (error: any) {
            lastError = error;
            let isRetryable = false;

            if (error?.message) {
                try {
                    const parsedError = JSON.parse(error.message);
                    const errorCode = parsedError?.error?.code;
                    // Retry on 429 (Rate Limit) or 5xx server errors
                    if (errorCode === 429 || (errorCode >= 500 && errorCode < 600)) {
                        isRetryable = true;
                    }
                } catch (e) {
                    // Not a JSON error message, not retryable in this logic.
                }
            }

            if (isRetryable) {
                if (i < retries - 1) {
                    const backoffDelay = initialDelay * Math.pow(2, i);
                    console.warn(`API rate limit or server error encountered. Retrying in ${backoffDelay}ms... (Attempt ${i + 1}/${retries})`);
                    await new Promise(res => setTimeout(res, backoffDelay));
                    continue;
                } else {
                    // Retries exhausted
                    console.error("API call failed after multiple retries.", lastError);
                    throw new Error("The server is busy or rate limits were exceeded. Please try again in a moment.");
                }
            } else {
                // Not a retryable error, throw immediately.
                throw lastError;
            }
        }
    }
    throw lastError; // Fallback, should not be reached.
};


const generatePersonaData = async (prompt: string): Promise<Persona> => {
  console.log("Generating persona data for:", prompt);
  const response: GenerateContentResponse = await withRetry(() => ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: `Create a detailed character persona based on the following theme: "${prompt}". The character should be unique and interesting. Provide a detailed backstory, personality traits, and motivations. Also, create a short, descriptive prompt for an AI image generator to create a portrait of this character.`,
    config: {
      systemInstruction: "You are a creative writer specializing in character development for novels and video games. Your task is to generate a detailed character persona based on user-provided keywords. Respond ONLY with a valid JSON object matching the provided schema.",
      responseMimeType: "application/json",
      responseSchema: personaSchema,
    },
  }));

  console.log("Raw persona response text:", response.text);
  const personaData = JSON.parse(response.text);
  return personaData as Persona;
};

const generatePersonaDataFromImages = async (prompt: string, images: {mimeType: string, data: string}[]): Promise<Persona> => {
    console.log("Generating persona data from images and prompt:", prompt);
    const imageParts: Part[] = images.map(image => ({
        inlineData: {
            mimeType: image.mimeType,
            data: image.data,
        },
    }));

    const textPart: Part = {
        text: `You are a character designer. Analyze the following images and the user's prompt. Synthesize them to create a single, cohesive character persona. Generate the persona details in the required JSON format. User's prompt: "${prompt}"`
    };

    const response: GenerateContentResponse = await withRetry(() => ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: { parts: [textPart, ...imageParts] },
        config: {
          systemInstruction: "You are a creative writer specializing in character development for novels and video games. Your task is to generate a detailed character persona based on user-provided images and keywords. Respond ONLY with a valid JSON object matching the provided schema.",
          responseMimeType: "application/json",
          responseSchema: personaSchema,
        },
    }));

    console.log("Raw persona response text from images:", response.text);
    const personaData = JSON.parse(response.text);
    return personaData as Persona;
}

const generatePersonaImage = async (imagePrompt: string): Promise<string> => {
  console.log("Generating image with prompt:", imagePrompt);
  const response = await withRetry<GenerateImagesResponse>(() => ai.models.generateImages({
    model: 'imagen-3.0-generate-002',
    prompt: imagePrompt,
    config: {
      numberOfImages: 1,
      outputMimeType: 'image/jpeg',
      aspectRatio: '3:4', // Portrait aspect ratio
    },
  }));
  
  if (!response.generatedImages || response.generatedImages.length === 0) {
      throw new Error("Image generation failed, no images returned.");
  }

  const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
  return `data:image/jpeg;base64,${base64ImageBytes}`;
};

export const getAIPersona = async (familyMember: AIFamilyMember): Promise<GeneratedContent> => {
  try {
    const persona = await generatePersonaData(familyMember.prompt);
    const imageUrl = await generatePersonaImage(persona.imageDescription);
    return {
      id: `${persona.name.replace(/\s+/g, '-')}-${Date.now()}`,
      prompt: familyMember.prompt,
      persona,
      imageUrl,
      imageVariations: [],
    };
  } catch (error) {
    console.error("Error in getAIPersona:", error);
    throw error;
  }
};

export const getAIPersonaFromCustomPrompt = async (prompt: string): Promise<GeneratedContent> => {
  try {
    const persona = await generatePersonaData(prompt);
    const imageUrl = await generatePersonaImage(persona.imageDescription);
    return {
      id: `${persona.name.replace(/\s+/g, '-')}-${Date.now()}`,
      prompt,
      persona,
      imageUrl,
      imageVariations: [],
    };
  } catch (error) {
    console.error("Error in getAIPersonaFromCustomPrompt:", error);
    throw error;
  }
};

export const getAIPersonaFromImagesAndPrompt = async (prompt: string, images: {mimeType: string, data: string}[]): Promise<GeneratedContent> => {
  try {
    const persona = await generatePersonaDataFromImages(prompt, images);
    const imageUrl = await generatePersonaImage(persona.imageDescription);
    return {
      id: `${persona.name.replace(/\s+/g, '-')}-${Date.now()}`,
      prompt,
      persona,
      imageUrl,
      imageVariations: [],
    };
  } catch (error) {
    console.error("Error in getAIPersonaFromImagesAndPrompt:", error);
    throw error;
  }
};

const generateVariationPrompt = async (originalImageDescription: string, existingVariationsCount: number): Promise<string> => {
    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: `Based on this original character description: "${originalImageDescription}", create one new, detailed image prompt for a different scene or scenario. The character's face, build, and core identity must remain consistent. This is variation number ${existingVariationsCount + 1}. Do not repeat the original scenario. Be creative and specific (e.g., "posing in a neon-lit alley at night," "reading an ancient book in a grand library," "commanding a starship bridge with a nebula visible through the viewport"). Output ONLY the new image prompt text as a single string.`,
    });
    return response.text.trim();
};

export const generateImageVariation = async (persona: Persona, existingVariationsCount: number): Promise<string> => {
    try {
        const newPrompt = await generateVariationPrompt(persona.imageDescription, existingVariationsCount);
        console.log(`Generated new variation prompt: ${newPrompt}`);
        const imageUrl = await generatePersonaImage(newPrompt);
        return imageUrl;
    } catch (error) {
        console.error("Error in generateImageVariation:", error);
        throw error;
    }
};