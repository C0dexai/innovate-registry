export type AspectRatio = "1:1" | "3:4" | "4:3" | "9:16" | "16:9";

export type ImageStyle = "cinematic" | "photographic" | "digital_art" | "anime" | "fantasy";

export type Tab = 'generate' | 'gallery' | 'assistant' | 'settings' | 'code';

export type GalleryFilter = 'all' | 'favorites' | 'bookmarked';

export interface GenerationSettings {
  style: ImageStyle;
  aspectRatio: AspectRatio;
}

export interface GeneratedImage extends GenerationSettings {
  id: string;
  prompt: string;
  imageUrl: string; 
  createdAt: string;
  seed?: string;
  isBookmarked?: boolean;
}

export interface FavoritePrompt {
  id: string;
  prompt: string;
}

export interface AppSettings {
  stylePromptMap: Record<ImageStyle, string>;
  systemPersona: string;
  promptPrefix: string;
  promptSuffix: string;
}

export type IconName = 'logo' | 'star' | 'heart' | 'dice' | 'image' | 'database' | 'cpu' | 'camera' | 'cloud' | 'code' | 'shield' | 'cog' | 'briefcase' | 'send' | 'arrow-left' | 'bot' | 'thumb-up' | 'thumb-down' | 'book-open' | 'sparkles' | 'key' | 'bookmark' | 'copy' | 'wand-2' | 'chevron-left' | 'chevron-right' | 'folder' | 'file-code';

export interface AIPersona {
  name: string;
  role: string;
  icon: IconName;
  persona: {
    description: string;
    tone: string;
  };
  superpowers: string[];
  canGenerateImages?: boolean;
}

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
  id: string;
  assistantName: string;
  createdAt: string;
  feedback?: 'up' | 'down';
  imageUrl?: string;
  imagePrompt?: string;
  imageStyle?: ImageStyle;
  isBookmarked?: boolean;
  status?: 'generating_image' | 'complete';
  // Post-generation analysis
  imageAnalysis?: string;
  suggestedPrompts?: string[]; // For continuing the story
  refinementPrompts?: string[]; // For iterating on the same image
}