import React, { useState } from 'react';
import { AIPersona, GeneratedImage, FavoritePrompt, AppSettings } from '../types';
import { AI_FAMILY } from '../constants/aiFamily';
import { Icon } from './Icon';
import ChatInterface from './ChatInterface';

const AssistantCard: React.FC<{ assistant: AIPersona, onSelect: () => void }> = ({ assistant, onSelect }) => (
    <div className="bg-zinc-900/60 backdrop-blur-md border border-zinc-800 rounded-xl shadow-lg p-6 flex flex-col items-center text-center transition-all duration-300 hover:shadow-purple-500/30 hover:scale-105 hover:border-purple-500/50">
        <div className="bg-zinc-800 rounded-full p-4 mb-4 border border-zinc-700">
            <Icon name={assistant.icon} className="w-10 h-10 text-purple-400" />
        </div>
        <h3 className="text-xl font-bold text-white mb-1">{assistant.name}</h3>
        <p className="text-zinc-400 text-sm mb-4">{assistant.role}</p>
        <button
            onClick={onSelect}
            className="mt-auto w-full py-2 px-4 bg-purple-500 hover:bg-purple-600 text-black font-bold rounded-lg transition"
        >
            Chat Now
        </button>
    </div>
);

interface AssistantViewProps {
    generatedImages: GeneratedImage[];
    favoritePrompts: FavoritePrompt[];
    toggleFavoritePrompt: (prompt: string) => Promise<void>;
    addImage: (image: GeneratedImage) => Promise<void>;
    settings: AppSettings;
}

const AssistantView: React.FC<AssistantViewProps> = ({ generatedImages, favoritePrompts, toggleFavoritePrompt, addImage, settings }) => {
    const [selectedAssistant, setSelectedAssistant] = useState<AIPersona | null>(null);

    if (selectedAssistant) {
        return (
            <ChatInterface 
                assistant={selectedAssistant} 
                onBack={() => setSelectedAssistant(null)}
                generatedImages={generatedImages}
                favoritePrompts={favoritePrompts}
                toggleFavoritePrompt={toggleFavoritePrompt}
                addImage={addImage}
                settings={settings}
            />
        );
    }

    return (
        <div className="space-y-8">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-white">Choose Your AI Assistant</h2>
                <p className="mt-2 text-zinc-400">Select a specialist to help you with your tasks.</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {AI_FAMILY.map(assistant => (
                    <AssistantCard key={assistant.name} assistant={assistant} onSelect={() => setSelectedAssistant(assistant)} />
                ))}
            </div>
        </div>
    );
};

export default AssistantView;