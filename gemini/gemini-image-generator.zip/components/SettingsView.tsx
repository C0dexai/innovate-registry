import React, { useState, useEffect } from 'react';
import { AppSettings, ImageStyle } from '../types';
import { DEFAULT_SETTINGS, IMAGE_STYLES } from '../constants';
import { Icon } from './Icon';
import { Spinner } from './Spinner';

interface SettingsViewProps {
  settings: AppSettings;
  onSave: (newSettings: AppSettings) => Promise<void>;
}

const SettingsView: React.FC<SettingsViewProps> = ({ settings, onSave }) => {
  const [localSettings, setLocalSettings] = useState<AppSettings>(settings);
  const [isSaving, setIsSaving] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  useEffect(() => {
    setLocalSettings(settings);
  }, [settings]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setLocalSettings(prev => ({ ...prev, [name]: value }));
  };

  const handleStyleChange = (style: ImageStyle, value: string) => {
    setLocalSettings(prev => ({
      ...prev,
      stylePromptMap: {
        ...prev.stylePromptMap,
        [style]: value,
      },
    }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    await onSave(localSettings);
    setIsSaving(false);
    setShowConfirm(true);
    setTimeout(() => setShowConfirm(false), 2000);
  };
  
  const handleReset = () => {
    setLocalSettings(DEFAULT_SETTINGS);
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8 text-white">
      <div className="text-center">
        <h2 className="text-3xl font-bold">Application Settings</h2>
        <p className="mt-2 text-zinc-400">Customize the global behavior of the AI and image generation.</p>
      </div>

      {/* Global Prompting Section */}
      <div className="bg-zinc-900/60 backdrop-blur-md border border-zinc-700 p-6 rounded-xl shadow-lg shadow-purple-500/10">
        <h3 className="text-xl font-semibold mb-4 border-b border-zinc-800 pb-2">Global Prompting</h3>
        <div className="space-y-4">
          <div>
            <label htmlFor="promptPrefix" className="block text-sm font-medium text-zinc-300 mb-1">Prompt Prefix</label>
            <input
              type="text"
              id="promptPrefix"
              name="promptPrefix"
              value={localSettings.promptPrefix}
              onChange={handleInputChange}
              className="w-full p-2 bg-zinc-800 border border-zinc-700 rounded-lg focus:ring-2 focus:ring-purple-500"
              placeholder="e.g., masterpiece, best quality"
            />
            <p className="text-xs text-zinc-500 mt-1">This text is added to the beginning of every image prompt.</p>
          </div>
          <div>
            <label htmlFor="promptSuffix" className="block text-sm font-medium text-zinc-300 mb-1">Prompt Suffix (Negative Prompt)</label>
            <input
              type="text"
              id="promptSuffix"
              name="promptSuffix"
              value={localSettings.promptSuffix}
              onChange={handleInputChange}
              className="w-full p-2 bg-zinc-800 border border-zinc-700 rounded-lg focus:ring-2 focus:ring-purple-500"
              placeholder="e.g., blurry, watermark, text"
            />
             <p className="text-xs text-zinc-500 mt-1">This text is added to the end of every image prompt. Useful for negative prompts.</p>
          </div>
        </div>
      </div>

      {/* System Persona Section */}
      <div className="bg-zinc-900/60 backdrop-blur-md border border-zinc-700 p-6 rounded-xl shadow-lg shadow-purple-500/10">
        <h3 className="text-xl font-semibold mb-4 border-b border-zinc-800 pb-2">System Persona</h3>
        <div>
          <label htmlFor="systemPersona" className="block text-sm font-medium text-zinc-300 mb-1">Global System Instructions</label>
          <textarea
            id="systemPersona"
            name="systemPersona"
            value={localSettings.systemPersona}
            onChange={handleInputChange}
            rows={4}
            className="w-full p-2 bg-zinc-800 border border-zinc-700 rounded-lg focus:ring-2 focus:ring-purple-500"
            placeholder="e.g., You are a witty and creative assistant..."
          />
           <p className="text-xs text-zinc-500 mt-1">This base instruction defines the personality for all AI assistants.</p>
        </div>
      </div>

      {/* Style Definitions Section */}
      <div className="bg-zinc-900/60 backdrop-blur-md border border-zinc-700 p-6 rounded-xl shadow-lg shadow-purple-500/10">
        <h3 className="text-xl font-semibold mb-4 border-b border-zinc-800 pb-2">Image Style Definitions</h3>
        <div className="space-y-4">
          {IMAGE_STYLES.map(style => (
            <div key={style}>
              <label htmlFor={`style_${style}`} className="block text-sm font-medium text-zinc-300 mb-1 capitalize">{style.replace(/_/g, ' ')}</label>
              <input
                type="text"
                id={`style_${style}`}
                value={localSettings.stylePromptMap[style] || ''}
                onChange={(e) => handleStyleChange(style, e.target.value)}
                className="w-full p-2 bg-zinc-800 border border-zinc-700 rounded-lg focus:ring-2 focus:ring-purple-500"
              />
            </div>
          ))}
        </div>
      </div>
      
      <div className="flex items-center justify-end space-x-4 pt-4">
        <button
            onClick={handleReset}
            className="px-6 py-2 bg-zinc-600 hover:bg-zinc-500 text-white font-semibold rounded-lg transition"
        >
            Reset to Defaults
        </button>
        <button
          onClick={handleSave}
          disabled={isSaving}
          className="relative px-6 py-2 bg-purple-500 hover:bg-purple-600 text-black font-bold rounded-lg transition disabled:bg-zinc-700 disabled:text-zinc-400 disabled:cursor-not-allowed"
        >
          {isSaving ? (
            <div className="flex items-center">
                <Spinner className="mr-2 w-4 h-4" /> Saving...
            </div>
          ) : 'Save Settings'}
           {showConfirm && (
            <span className="absolute -top-8 left-1/2 -translate-x-1/2 bg-green-500 text-white text-xs px-2 py-1 rounded-md">
              Saved!
            </span>
          )}
        </button>
      </div>
    </div>
  );
};

export default SettingsView;