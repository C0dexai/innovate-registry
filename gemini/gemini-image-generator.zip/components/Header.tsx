import React from 'react';
import { Tab } from '../types';
import { Icon } from './Icon';

interface TabButtonProps {
  label: string;
  isActive: boolean;
  onClick: () => void;
}

const TabButton: React.FC<TabButtonProps> = ({ label, isActive, onClick }) => (
  <button
    onClick={onClick}
    className={`px-4 py-2 text-sm md:text-base font-bold rounded-lg transition-all duration-300 ${
      isActive
        ? 'bg-cyan-400 text-black shadow-lg shadow-cyan-400/40'
        : 'text-zinc-400 hover:bg-zinc-700/50 hover:text-cyan-400'
    }`}
  >
    {label}
  </button>
);

interface HeaderProps {
    activeTab: Tab;
    setActiveTab: (tab: Tab) => void;
}

export const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab }) => {
  return (
    <header className="bg-zinc-900/60 backdrop-blur-lg shadow-lg sticky top-0 z-50 border-b border-zinc-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-3">
            <Icon name="logo" className="w-8 h-8 text-cyan-400 [filter:drop-shadow(0_0_3px_#06b6d4)]"/>
            <h1 className="text-xl md:text-2xl font-bold text-slate-100 tracking-tight">
              Gemini Image Gen
            </h1>
          </div>
          <nav className="flex space-x-2 bg-zinc-800/70 p-1 rounded-xl border border-zinc-700">
            <TabButton
              label="Generate"
              isActive={activeTab === 'generate'}
              onClick={() => setActiveTab('generate')}
            />
            <TabButton
              label="Gallery"
              isActive={activeTab === 'gallery'}
              onClick={() => setActiveTab('gallery')}
            />
             <TabButton
              label="Assistant"
              isActive={activeTab === 'assistant'}
              onClick={() => setActiveTab('assistant')}
            />
             <TabButton
              label="Settings"
              isActive={activeTab === 'settings'}
              onClick={() => setActiveTab('settings')}
            />
          </nav>
        </div>
      </div>
    </header>
  );
};