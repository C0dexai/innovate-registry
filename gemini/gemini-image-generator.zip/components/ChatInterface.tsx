import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { GoogleGenAI, Chat } from "@google/genai";
import { AIPersona, ChatMessage, GeneratedImage, FavoritePrompt, ImageStyle, AppSettings } from '../types';
import { Icon } from './Icon';
import { Spinner } from './Spinner';
import { generateImage, getPromptRefinements, getPostGenerationAnalysis } from '../services/geminiService';
import { IMAGE_STYLES } from '../constants';
import * as idb from '../services/idbService';
import PromptLibrary from './PromptLibrary';
import ImageModal from './ImageModal';

const SuggestionButton: React.FC<{prompt: string, icon: 'sparkles' | 'wand-2', onClick: () => void}> = ({prompt, icon, onClick}) => (
    <button onClick={onClick} className="text-left text-sm text-slate-300 bg-zinc-700/50 hover:bg-zinc-700/80 w-full p-2 rounded-md transition flex items-start gap-2">
        <Icon name={icon} className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
        <span>{prompt}</span>
    </button>
);

const ImageGenerationPlaceholder: React.FC<{prompt?: string}> = ({prompt}) => (
    <div className="mb-2 p-4 bg-black/30 rounded-lg animate-pulse">
        <div className="flex items-center gap-3 text-cyan-300">
            <Icon name="image" className="w-6 h-6" />
            <div className="flex-grow">
                <p className="font-semibold">Generating your image...</p>
                <p className="text-xs text-cyan-400/80 italic line-clamp-1">"{prompt}"</p>
            </div>
        </div>
    </div>
);


interface ChatInterfaceProps {
    assistant: AIPersona;
    onBack: () => void;
    generatedImages: GeneratedImage[];
    favoritePrompts: FavoritePrompt[];
    toggleFavoritePrompt: (prompt: string) => Promise<void>;
    addImage: (image: GeneratedImage) => Promise<void>;
    settings: AppSettings;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ assistant, onBack, generatedImages, favoritePrompts, addImage, settings }) => {
    const [chat, setChat] = useState<Chat | null>(null);
    const [history, setHistory] = useState<ChatMessage[]>([]);
    const [userInput, setUserInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isDBLoading, setIsDBLoading] = useState(true);
    const [isPromptLibraryOpen, setPromptLibraryOpen] = useState(false);
    const [isRefining, setIsRefining] = useState(false);
    const [refinementSuggestions, setRefinementSuggestions] = useState<string[]>([]);
    const [imageStyle, setImageStyle] = useState<ImageStyle>('photographic');
    const [copiedId, setCopiedId] = useState<string | null>(null);
    const [activeModalImageIndex, setActiveModalImageIndex] = useState<number | null>(null);

    const messagesEndRef = useRef<HTMLDivElement>(null);
    const imageMessages = useMemo(() => history.filter(msg => msg.imageUrl && msg.status === 'complete'), [history]);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [history]);
    
    useEffect(() => {
        const loadHistory = async () => {
            setIsDBLoading(true);
            const savedHistory = await idb.getChatHistory(assistant.name);
            setHistory(savedHistory);
            setIsDBLoading(false);
        };
        loadHistory();
    }, [assistant.name]);

    useEffect(() => {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
        const systemInstruction = `${settings.systemPersona} You are ${assistant.name}, a ${assistant.role}. ${assistant.persona.description}. Your tone is ${assistant.persona.tone}. Do not start your response with your name. Be helpful and answer questions related to your role.`;
        
        const newChat = ai.chats.create({
            model: 'gemini-2.5-flash',
            config: {
                systemInstruction,
            },
        });
        setChat(newChat);
    }, [assistant, settings.systemPersona]);
    
    const handleFeedback = async (messageId: string, feedback: 'up' | 'down') => {
        let updatedMessage: ChatMessage | undefined;
        setHistory(prevHistory => {
            const newHistory = prevHistory.map(msg => {
                if (msg.id === messageId) {
                    updatedMessage = { ...msg, feedback: msg.feedback === feedback ? undefined : feedback };
                    return updatedMessage;
                }
                return msg;
            });
            return newHistory;
        });
        if (updatedMessage) {
            await idb.updateChatMessage(updatedMessage);
        }
    };
    
    const updateMessageInHistory = useCallback(async (message: ChatMessage) => {
        setHistory(prev => prev.map(m => m.id === message.id ? message : m));
        await idb.updateChatMessage(message);
    }, []);

    const addMessageToHistory = useCallback(async (message: ChatMessage) => {
        setHistory(prev => [...prev, message]);
        await idb.addChatMessage(message);
    }, []);

    const handleSendMessage = async (prompt: string, isImageRequest: boolean = false, fromBookmark: boolean = false) => {
        if (!prompt || isLoading || isRefining) return;
        setRefinementSuggestions([]);

        const newUserMessage: ChatMessage = { role: 'user', content: prompt, id: crypto.randomUUID(), assistantName: assistant.name, createdAt: new Date().toISOString(), status: 'complete' };
        await addMessageToHistory(newUserMessage);
        if(userInput === prompt) setUserInput('');

        setIsLoading(true);
        const placeholderId = crypto.randomUUID();

        try {
            if (isImageRequest && assistant.canGenerateImages) {
                const placeholderMessage: ChatMessage = {
                    role: 'model',
                    content: `Generating an image for: "${prompt}"`,
                    id: placeholderId,
                    assistantName: assistant.name,
                    createdAt: new Date().toISOString(),
                    status: 'generating_image',
                    imagePrompt: prompt,
                    imageStyle: imageStyle,
                };
                await addMessageToHistory(placeholderMessage);

                const styleSuffix = settings.stylePromptMap[imageStyle] || '';
                const fullPrompt = `${settings.promptPrefix}, ${prompt}, ${styleSuffix}, ${settings.promptSuffix}`.replace(/, ,/g, ',').replace(/,$/, '').trim();
                
                const [imageUrl, analysisData] = await Promise.all([
                    generateImage(fullPrompt, '1:1'),
                    getPostGenerationAnalysis(prompt, settings.systemPersona)
                ]);

                const newImage: GeneratedImage = {
                    id: crypto.randomUUID(),
                    prompt: prompt,
                    imageUrl: imageUrl,
                    style: imageStyle,
                    aspectRatio: '1:1',
                    createdAt: new Date().toISOString(),
                    isBookmarked: fromBookmark
                };
                await addImage(newImage);

                const finalMessage: ChatMessage = { 
                    ...placeholderMessage,
                    status: 'complete',
                    content: analysisData.analysis,
                    imageUrl,
                    imageAnalysis: analysisData.analysis,
                    suggestedPrompts: analysisData.storylinePrompts,
                    refinementPrompts: analysisData.refinementPrompts,
                };
                await updateMessageInHistory(finalMessage);

            } else {
                if (!chat) throw new Error("Chat not initialized");
                const response = await chat.sendMessage({ message: prompt });
                const modelResponse: ChatMessage = { role: 'model', content: response.text, id: crypto.randomUUID(), assistantName: assistant.name, createdAt: new Date().toISOString(), status: 'complete' };
                await addMessageToHistory(modelResponse);
            }
        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : "An unknown error occurred.";
            const errorResponse: ChatMessage = {
                role: 'model',
                content: `Sorry, I encountered an error: ${errorMessage}`,
                id: crypto.randomUUID(),
                assistantName: assistant.name,
                createdAt: new Date().toISOString(),
                status: 'complete',
            }
            if (isImageRequest) {
                 await updateMessageInHistory({ ...errorResponse, id: placeholderId, content: `Sorry, I failed to generate an image: ${errorMessage}` });
            } else {
                await addMessageToHistory(errorResponse);
            }
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleBookmark = async (messageId: string) => {
        let updatedMessage: ChatMessage | undefined;
        setHistory(prevHistory => {
            const newHistory = prevHistory.map(msg => {
                if (msg.id === messageId) {
                    updatedMessage = { ...msg, isBookmarked: !msg.isBookmarked };
                    return updatedMessage;
                }
                return msg;
            });
            return newHistory;
        });

        if (updatedMessage) {
            await idb.updateChatMessage(updatedMessage);
        }
    };
    
    const handleCopy = (content: string, id: string) => {
        const codeBlock = "```\n" + content + "\n```";
        navigator.clipboard.writeText(codeBlock);
        setCopiedId(id);
        setTimeout(() => setCopiedId(null), 2000);
    };

    const handleRefinePrompt = async () => {
        if (!userInput.trim() || isRefining || isLoading) return;
        setIsRefining(true);
        setRefinementSuggestions([]);
        try {
            const suggestions = await getPromptRefinements(userInput, settings.systemPersona);
            setRefinementSuggestions(suggestions);
        } catch (error) {
            // handle error silently for now
            console.error(error);
        } finally {
            setIsRefining(false);
        }
    };
    
    if (isDBLoading) {
        return <div className="flex justify-center items-center h-[80vh]"><Spinner large /></div>
    }

    return (
        <>
            <div className="bg-zinc-900/60 backdrop-blur-md border border-zinc-700 rounded-xl shadow-2xl shadow-cyan-500/10 flex flex-col h-[80vh] max-h-[800px]">
                {/* Header */}
                <div className="flex items-center p-4 border-b border-zinc-800 flex-shrink-0">
                    <button onClick={onBack} className="p-2 mr-3 rounded-full hover:bg-zinc-700 transition">
                        <Icon name="arrow-left" className="w-6 h-6" />
                    </button>
                    <Icon name={assistant.icon} className="w-8 h-8 text-purple-400 mr-3" />
                    <div>
                        <h3 className="font-bold text-lg text-white">{assistant.name}</h3>
                        <p className="text-sm text-zinc-400">{assistant.role}</p>
                    </div>
                </div>

                {/* Messages */}
                <div className="flex-grow p-4 overflow-y-auto space-y-6">
                    {history.map((msg) => (
                        <div key={msg.id} className={`flex items-start gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                           {msg.role === 'model' && <div className="w-8 h-8 bg-zinc-800 rounded-full flex items-center justify-center flex-shrink-0 mt-1"><Icon name="bot" className="w-5 h-5 text-purple-400" /></div>}
                            <div className={`group relative p-3 rounded-xl max-w-lg lg:max-w-2xl ${msg.role === 'user' ? 'bg-gradient-to-r from-fuchsia-600 to-purple-600 text-white shadow-lg shadow-purple-600/20' : 'bg-zinc-800 text-slate-200'}`}>
                                {msg.status === 'generating_image' && <ImageGenerationPlaceholder prompt={msg.imagePrompt} />}
                                {msg.imageUrl && msg.status === 'complete' && (
                                    <div className="mb-2 cursor-pointer" onClick={() => {
                                        const index = imageMessages.findIndex(im => im.id === msg.id);
                                        if (index > -1) setActiveModalImageIndex(index);
                                    }}>
                                        <img src={msg.imageUrl} alt={msg.imagePrompt} className="rounded-lg shadow-md" />
                                         <div className="flex justify-between items-center mt-2 gap-2">
                                            <p className="text-xs text-zinc-400 italic line-clamp-1">"{msg.imagePrompt}"</p>
                                            {msg.imageStyle && (
                                                <span className="text-xs font-semibold bg-cyan-500/20 text-cyan-300 px-2 py-1 rounded-md capitalize flex-shrink-0">
                                                    {msg.imageStyle.replace(/_/g, ' ')}
                                                </span>
                                            )}
                                        </div>
                                    </div>
                                )}
                                <div className="whitespace-pre-wrap">{msg.content}</div>
                                
                                {(msg.suggestedPrompts || msg.refinementPrompts) && (
                                    <div className="mt-4 pt-3 border-t border-zinc-600/50 space-y-4">
                                        {msg.suggestedPrompts && msg.suggestedPrompts.length > 0 && (
                                            <div>
                                                <h4 className="text-sm font-semibold mb-2 text-cyan-300 flex items-center gap-2"><Icon name="sparkles" className="w-4 h-4"/>Continue the story...</h4>
                                                <div className="flex flex-col items-start gap-2">
                                                    {msg.suggestedPrompts.map((p, i) => <SuggestionButton key={`story-${i}`} prompt={p} icon="sparkles" onClick={() => setUserInput(p)}/>)}
                                                </div>
                                            </div>
                                        )}
                                        {msg.refinementPrompts && msg.refinementPrompts.length > 0 && (
                                             <div>
                                                <h4 className="text-sm font-semibold mb-2 text-cyan-300 flex items-center gap-2"><Icon name="wand-2" className="w-4 h-4"/>Refine this image...</h4>
                                                <div className="flex flex-col items-start gap-2">
                                                    {msg.refinementPrompts.map((p, i) => <SuggestionButton key={`refine-${i}`} prompt={p} icon="wand-2" onClick={() => setUserInput(p)}/>)}
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                )}

                                {msg.role === 'model' && msg.status === 'complete' && msg.content && !msg.imageUrl && (
                                    <div className="absolute -right-2 top-1/2 -translate-y-1/2 flex flex-col space-y-1 bg-zinc-900 p-1 rounded-full border border-zinc-700 shadow-lg opacity-0 group-hover:opacity-100 transition-opacity">
                                        <button onClick={() => handleBookmark(msg.id)} className="p-1 rounded-full text-zinc-400 hover:bg-zinc-700 transition-colors" title={msg.isBookmarked ? "Remove Bookmark" : "Bookmark"}>
                                            <Icon name="bookmark" className={`w-4 h-4 transition-colors ${msg.isBookmarked ? 'text-fuchsia-400 fill-current' : 'hover:text-slate-200'}`} />
                                        </button>
                                        <button onClick={() => handleCopy(msg.content, msg.id)} className="p-1 rounded-full text-zinc-400 hover:bg-zinc-700 transition-colors" title="Copy as Codeblock">
                                            <Icon name="copy" className={`w-4 h-4 transition-colors ${copiedId === msg.id ? 'text-green-400' : 'hover:text-slate-200'}`} />
                                        </button>
                                        {assistant.canGenerateImages && (
                                            <button onClick={() => handleSendMessage(msg.content, true, msg.isBookmarked)} className="p-1 rounded-full text-zinc-400 hover:bg-zinc-700 transition-colors" title="Generate Image from Text">
                                                <Icon name="image" className="w-4 h-4 hover:text-slate-200" />
                                            </button>
                                        )}
                                    </div>
                                )}
                            </div>
                             {msg.role === 'model' && msg.status === 'complete' && msg.content && !msg.imageUrl && (
                                <div className="flex items-center self-end space-x-1">
                                    <button onClick={() => handleFeedback(msg.id, 'up')} className="p-1 rounded-full text-zinc-500 hover:bg-zinc-700 transition-colors" title="Good response">
                                        <Icon name="thumb-up" className={`w-4 h-4 transition-colors ${msg.feedback === 'up' ? 'text-green-400' : 'hover:text-slate-300'}`} />
                                    </button>
                                    <button onClick={() => handleFeedback(msg.id, 'down')} className="p-1 rounded-full text-zinc-500 hover:bg-zinc-700 transition-colors" title="Bad response">
                                        <Icon name="thumb-down" className={`w-4 h-4 transition-colors ${msg.feedback === 'down' ? 'text-red-400' : 'hover:text-slate-300'}`} />
                                    </button>
                                </div>
                            )}
                        </div>
                    ))}
                    {isLoading && !history.some(m => m.status === 'generating_image') && (
                         <div className="flex items-start gap-3 justify-start">
                             <div className="w-8 h-8 bg-zinc-800 rounded-full flex items-center justify-center flex-shrink-0 mt-1"><Icon name="bot" className="w-5 h-5 text-purple-400" /></div>
                            <div className="p-3 rounded-xl bg-zinc-800">
                               <Spinner />
                            </div>
                        </div>
                    )}
                    <div ref={messagesEndRef} />
                </div>

                {/* Input Form */}
                <div className="p-4 border-t border-zinc-800 flex-shrink-0 bg-zinc-900/80 backdrop-blur-sm">
                    {assistant.canGenerateImages && (
                         <div className="mb-4 space-y-3">
                            {refinementSuggestions.length > 0 && (
                                <div className="space-y-2">
                                    <h4 className="text-xs font-semibold text-zinc-400">Choose a refinement:</h4>
                                    {refinementSuggestions.map((s, i) => (
                                        <button key={i} onClick={() => { setUserInput(s); setRefinementSuggestions([]); }} className="w-full text-left p-2 bg-zinc-700/50 hover:bg-zinc-700 rounded-md text-xs transition">
                                            {s}
                                        </button>
                                    ))}
                                </div>
                            )}
                            <div>
                                <label className="block text-xs font-medium text-zinc-400 mb-2">Image Style</label>
                                <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                                    {IMAGE_STYLES.map(s => (
                                    <button key={s} onClick={() => setImageStyle(s)} className={`p-2 text-xs rounded-md transition capitalize font-bold ${imageStyle === s ? 'bg-cyan-400 text-black' : 'bg-zinc-800 hover:bg-zinc-700 font-semibold'}`}>
                                        {s.replace(/_/g, ' ')}
                                    </button>
                                    ))}
                                </div>
                            </div>
                        </div>
                    )}
                    <div className="flex items-center space-x-3">
                         <button onClick={() => setPromptLibraryOpen(true)} className="p-2 text-zinc-400 hover:text-white hover:bg-zinc-700 rounded-lg transition" title="Prompt Library">
                            <Icon name="book-open" className="w-6 h-6"/>
                        </button>
                        <input
                            type="text"
                            value={userInput}
                            onKeyDown={(e) => { if(e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSendMessage(userInput.trim(), !!assistant.canGenerateImages); } }}
                            onChange={(e) => setUserInput(e.target.value)}
                            placeholder={assistant.canGenerateImages ? 'Describe an image or ask a question...' : `Ask ${assistant.name}...`}
                            className="w-full p-3 bg-zinc-800 border border-zinc-700 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
                            disabled={isLoading || isRefining}
                        />
                        {assistant.canGenerateImages ? (
                             <div className="flex space-x-2">
                                <button onClick={handleRefinePrompt} disabled={isLoading || isRefining || !userInput.trim()} className="bg-purple-500 hover:bg-purple-600 text-black font-bold px-4 py-2 rounded-lg transition disabled:bg-zinc-700 disabled:text-zinc-400 disabled:cursor-not-allowed text-sm flex items-center gap-2">
                                    {isRefining ? <Spinner className="w-5 h-5"/> : <Icon name="wand-2" className="w-5 h-5"/>} Refine
                                </button>
                                <button onClick={() => handleSendMessage(userInput.trim(), true)} disabled={isLoading || isRefining || !userInput.trim()} className="bg-fuchsia-500 hover:bg-fuchsia-600 text-black font-bold px-4 py-2 rounded-lg transition disabled:bg-zinc-700 disabled:text-zinc-400 disabled:cursor-not-allowed flex items-center gap-2 text-sm">
                                    <Icon name="image" className="w-5 h-5"/> Generate
                                </button>
                             </div>
                        ) : (
                             <button type="button" onClick={() => handleSendMessage(userInput.trim(), false)} disabled={isLoading || !userInput.trim()} className="bg-cyan-500 hover:bg-cyan-600 text-black font-bold p-3 rounded-lg transition disabled:bg-zinc-700 disabled:text-zinc-400 disabled:cursor-not-allowed">
                                <Icon name="send" className="w-6 h-6" />
                            </button>
                        )}
                    </div>
                </div>
            </div>
            {isPromptLibraryOpen && (
                <PromptLibrary
                    favoritePrompts={favoritePrompts}
                    images={generatedImages}
                    onClose={() => setPromptLibraryOpen(false)}
                    onSelectPrompt={(prompt) => {
                        setUserInput(prompt);
                        setPromptLibraryOpen(false);
                    }}
                />
            )}
            {activeModalImageIndex !== null && (
                <ImageModal 
                    images={imageMessages}
                    startIndex={activeModalImageIndex}
                    onClose={() => setActiveModalImageIndex(null)}
                />
            )}
        </>
    );
};

export default ChatInterface;