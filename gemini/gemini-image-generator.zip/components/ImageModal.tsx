import React, { useState, useEffect, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { ChatMessage } from '../types';
import { Icon } from './Icon';

interface ImageModalProps {
  images: ChatMessage[];
  startIndex: number;
  onClose: () => void;
}

const ImageModal: React.FC<ImageModalProps> = ({ images, startIndex, onClose }) => {
  const [currentIndex, setCurrentIndex] = useState(startIndex);

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (e.key === 'Escape') onClose();
    if (e.key === 'ArrowLeft' && currentIndex > 0) setCurrentIndex(prev => prev - 1);
    if (e.key === 'ArrowRight' && currentIndex < images.length - 1) setCurrentIndex(prev => prev + 1);
  }, [onClose, currentIndex, images.length]);

  useEffect(() => {
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  const currentImage = images[currentIndex];
  if (!currentImage) return null;

  const modalContent = (
    <div
      className="fixed inset-0 bg-black/80 backdrop-blur-xl z-[100] flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="relative bg-zinc-900/60 backdrop-blur-md border border-zinc-700 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl shadow-cyan-500/20"
        onClick={e => e.stopPropagation()}
      >
        {/* Close Button */}
        <button onClick={onClose} className="absolute -top-3 -right-3 z-10 p-2 bg-zinc-800 rounded-full text-white hover:bg-red-500 transition-colors">
          <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
        </button>

        {/* Image Display */}
        <div className="flex-grow p-4 flex items-center justify-center overflow-hidden">
            <img 
                src={currentImage.imageUrl} 
                alt={currentImage.imagePrompt}
                className="max-w-full max-h-full object-contain rounded-lg"
            />
        </div>

        {/* Summary Footer */}
        <div className="flex-shrink-0 bg-zinc-950/70 p-4 rounded-b-2xl border-t border-zinc-800">
            <p className="text-sm text-zinc-300 mb-2 italic">
                <span className="font-bold text-slate-100 not-italic">Prompt: </span>
                {currentImage.imagePrompt}
            </p>
            {currentImage.imageAnalysis && (
                 <p className="text-sm text-zinc-400">
                    <span className="font-bold text-slate-200 not-italic">AI Analysis: </span>
                    {currentImage.imageAnalysis}
                 </p>
            )}
             <div className="flex justify-between items-center mt-3">
                 <span className="text-xs font-semibold bg-cyan-500/20 text-cyan-300 px-2 py-1 rounded-md capitalize flex-shrink-0">
                    {currentImage.imageStyle?.replace(/_/g, ' ')}
                </span>
                 <p className="text-xs text-zinc-500">{new Date(currentImage.createdAt).toLocaleString()}</p>
             </div>
        </div>

        {/* Navigation */}
        {images.length > 1 && (
            <>
                <button 
                    onClick={() => setCurrentIndex(prev => prev - 1)}
                    disabled={currentIndex === 0}
                    className="absolute left-4 top-1/2 -translate-y-1/2 p-2 bg-zinc-800/50 rounded-full text-white hover:bg-zinc-800/80 disabled:opacity-30 disabled:cursor-not-allowed transition"
                    aria-label="Previous image"
                >
                    <Icon name="chevron-left" className="w-6 h-6" />
                </button>
                 <button 
                    onClick={() => setCurrentIndex(prev => prev + 1)}
                    disabled={currentIndex === images.length - 1}
                    className="absolute right-4 top-1/2 -translate-y-1/2 p-2 bg-zinc-800/50 rounded-full text-white hover:bg-zinc-800/80 disabled:opacity-30 disabled:cursor-not-allowed transition"
                    aria-label="Next image"
                >
                    <Icon name="chevron-right" className="w-6 h-6" />
                </button>
            </>
        )}
      </div>
    </div>
  );

  return createPortal(modalContent, document.body);
};

export default ImageModal;