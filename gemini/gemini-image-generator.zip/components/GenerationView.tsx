import React, { useState, useCallback } from 'react';
import { generateImage, getPromptSuggestions } from '../services/geminiService';
import { GeneratedImage, FavoritePrompt, AspectRatio, ImageStyle, AppSettings } from '../types';
import { ASPECT_RATIOS, IMAGE_STYLES } from '../constants';
import { Spinner } from './Spinner';
import { Icon } from './Icon';

interface GenerationViewProps {
  addImage: (image: GeneratedImage) => Promise<void>;
  favoritePrompts: FavoritePrompt[];
  toggleFavoritePrompt: (prompt: string) => Promise<void>;
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
  error: string | null;
  setError: (error: string | null) => void;
  settings: AppSettings;
}

const GenerationView: React.FC<GenerationViewProps> = ({
  addImage,
  favoritePrompts,
  toggleFavoritePrompt,
  isLoading,
  setIsLoading,
  error,
  setError,
  settings,
}) => {
  const [prompt, setPrompt] = useState('');
  const [topic, setTopic] = useState('');
  const [seed, setSeed] = useState('');
  const [style, setStyle] = useState<ImageStyle>('photographic');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('1:1');
  const [lastGeneratedImage, setLastGeneratedImage] = useState<GeneratedImage | null>(null);
  const [isSuggesting, setIsSuggesting] = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);

  const isPromptFavorited = favoritePrompts.some(p => p.prompt === prompt);

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      setError("Prompt cannot be empty.");
      return;
    }
    setIsLoading(true);
    setError(null);
    setSuggestions([]);
    setLastGeneratedImage(null);
    
    const styleSuffix = settings.stylePromptMap[style] || '';
    const fullPrompt = `${settings.promptPrefix}, ${prompt.trim()}, ${styleSuffix}, ${settings.promptSuffix}`.replace(/, ,/g, ',').replace(/,$/, '').trim();

    try {
      const imageUrl = await generateImage(fullPrompt, aspectRatio);
      const newImage: GeneratedImage = {
        id: crypto.randomUUID(),
        prompt: prompt,
        imageUrl: imageUrl,
        style: style,
        aspectRatio: aspectRatio,
        createdAt: new Date().toISOString(),
        seed: seed,
      };
      await addImage(newImage);
      setLastGeneratedImage(newImage);
    } catch (e) {
      if (e instanceof Error) {
        setError(e.message);
      } else {
        setError("An unknown error occurred.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleSuggestPrompts = useCallback(async () => {
    setIsSuggesting(true);
    setError(null);
    setSuggestions([]);
    try {
      const suggestedPrompts = await getPromptSuggestions(topic, seed, settings.systemPersona);
      setSuggestions(suggestedPrompts);
    } catch (e) {
      if (e instanceof Error) {
        setError(e.message);
      } else {
        setError("An unknown error occurred while fetching suggestions.");
      }
    } finally {
      setIsSuggesting(false);
    }
  }, [topic, seed, setError, settings.systemPersona]);
  
  const handleSelectSuggestion = (suggestion: string) => {
    setPrompt(suggestion);
    setSuggestions([]);
  };
  
  const generateRandomSeed = () => {
    setSeed(Math.random().toString(36).substring(2, 12));
  }


  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Control Panel */}
      <div className="lg:col-span-1 bg-zinc-900/60 backdrop-blur-md border border-purple-500/20 p-6 rounded-2xl shadow-2xl shadow-purple-500/20 flex flex-col space-y-6">
        <div>
            <label htmlFor="topic" className="block text-sm font-medium text-zinc-400 mb-2">
              Creative Topic (Optional)
            </label>
            <input
              id="topic"
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g., enchanted forest, cyberpunk city"
              className="w-full p-2 bg-zinc-800 border border-zinc-700 rounded-lg focus:ring-2 focus:ring-purple-400 focus:border-purple-400 transition"
            />
        </div>

        <div>
            <label htmlFor="seed" className="block text-sm font-medium text-zinc-400 mb-2">
                Seed ID
            </label>
            <div className="flex items-center gap-2">
                <input
                    id="seed"
                    type="text"
                    value={seed}
                    onChange={(e) => setSeed(e.target.value)}
                    placeholder="Enter a seed for reproducible ideas"
                    className="w-full p-2 bg-zinc-800 border border-zinc-700 rounded-lg focus:ring-2 focus:ring-purple-400 focus:border-purple-400 transition"
                />
                 <button
                    onClick={generateRandomSeed}
                    disabled={isLoading || isSuggesting}
                    className="p-2 bg-zinc-800 hover:bg-zinc-700 rounded-md transition text-purple-400 disabled:opacity-50 disabled:cursor-not-allowed"
                    title="Generate random seed"
                >
                    <Icon name="dice" className="w-5 h-5" />
                </button>
            </div>
        </div>

         <button
              onClick={handleSuggestPrompts}
              disabled={isLoading || isSuggesting}
              className="flex items-center justify-center w-full space-x-2 text-base px-2 py-2 bg-zinc-800 hover:bg-zinc-700 rounded-lg transition text-purple-400 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSuggesting ? <Spinner className="w-5 h-5" /> : <Icon name="sparkles" className="w-5 h-5" />}
              <span>AI Suggest Prompts</span>
            </button>
        
        {suggestions.length > 0 && (
            <div className="space-y-2">
                <h3 className="text-sm font-medium text-zinc-400">Choose a suggestion:</h3>
                {suggestions.map((s, i) => (
                    <button key={i} onClick={() => handleSelectSuggestion(s)} className="w-full text-left p-2 bg-zinc-800/50 hover:bg-zinc-700 rounded-md text-xs transition">
                        {s}
                    </button>
                ))}
            </div>
        )}

        <div>
          <label htmlFor="prompt" className="block text-sm font-medium text-zinc-400 mb-2">
              Final Prompt
          </label>
          <div className="relative">
            <textarea
              id="prompt"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Your final prompt will appear here..."
              className="w-full h-32 p-3 pr-10 bg-zinc-800 border border-zinc-700 rounded-lg focus:ring-2 focus:ring-purple-400 focus:border-purple-400 transition"
              rows={4}
            />
            <button
              onClick={() => toggleFavoritePrompt(prompt)}
              className="absolute top-2 right-2 p-1.5 text-zinc-500 hover:text-fuchsia-400 transition rounded-full hover:bg-zinc-700"
              title={isPromptFavorited ? "Unfavorite prompt" : "Favorite prompt"}
              disabled={!prompt.trim()}
            >
              <Icon name="star" className={`w-5 h-5 ${isPromptFavorited ? 'text-fuchsia-400 fill-current' : ''}`} />
            </button>
          </div>
        </div>

        <div>
            <h3 className="text-sm font-medium text-zinc-400 mb-3">Favorite Prompts</h3>
            <div className="max-h-32 overflow-y-auto space-y-2 pr-2">
                {favoritePrompts.length > 0 ? favoritePrompts.map(fp => (
                    <button key={fp.id} onClick={() => setPrompt(fp.prompt)} className="w-full text-left p-2 bg-zinc-800/50 hover:bg-zinc-700 rounded-md text-xs truncate transition">
                        {fp.prompt}
                    </button>
                )) : <p className="text-xs text-zinc-500">No favorite prompts yet.</p>}
            </div>
        </div>

        <div>
          <label htmlFor="style" className="block text-sm font-medium text-zinc-400 mb-2">Style</label>
          <select id="style" value={style} onChange={e => setStyle(e.target.value as ImageStyle)} className="w-full p-3 bg-zinc-800 border border-zinc-700 rounded-lg focus:ring-2 focus:ring-purple-400 focus:border-purple-400 transition appearance-none">
            {IMAGE_STYLES.map(s => <option key={s} value={s} className="capitalize bg-zinc-800">{s.replace(/_/g, ' ')}</option>)}
          </select>
        </div>

        <div>
          <label htmlFor="aspectRatio" className="block text-sm font-medium text-zinc-400 mb-2">Aspect Ratio</label>
          <div className="grid grid-cols-5 gap-2">
            {ASPECT_RATIOS.map(ar => (
              <button key={ar} onClick={() => setAspectRatio(ar)} className={`p-2 text-xs rounded-md transition font-semibold ${aspectRatio === ar ? 'bg-purple-500 text-black shadow-[0_0_10px_rgba(168,85,247,0.7)]' : 'bg-zinc-800 hover:bg-zinc-700'}`}>
                {ar}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={handleGenerate}
          disabled={isLoading || isSuggesting}
          className="w-full flex justify-center items-center py-3 px-4 bg-gradient-to-r from-purple-500 to-fuchsia-500 hover:from-purple-600 hover:to-fuchsia-600 text-black font-bold rounded-lg shadow-lg shadow-fuchsia-500/40 transition-all transform hover:scale-105 disabled:from-zinc-700 disabled:to-zinc-700 disabled:shadow-none disabled:text-zinc-400 disabled:cursor-not-allowed"
        >
          {isLoading ? <><Spinner className="mr-3"/> Generating...</> : 'Generate Image'}
        </button>
      </div>

      {/* Result Display */}
      <div className="lg:col-span-2 bg-zinc-900/60 backdrop-blur-md border border-green-500/20 p-6 rounded-2xl shadow-2xl shadow-green-500/20 flex items-center justify-center min-h-[400px] lg:min-h-0">
        {isLoading && (
          <div className="text-center">
            <Spinner large={true} />
            <p className="mt-4 text-lg text-zinc-400">Summoning pixels...</p>
          </div>
        )}
        {error && (
            <div className="text-center text-red-400 bg-red-500/10 border border-red-500/20 p-4 rounded-lg">
                <p className="font-bold">Operation Failed</p>
                <p className="text-sm mt-1">{error}</p>
            </div>
        )}
        {!isLoading && !error && lastGeneratedImage && (
          <div className="w-full">
            <img src={lastGeneratedImage.imageUrl} alt={lastGeneratedImage.prompt} className="max-w-full max-h-[70vh] mx-auto rounded-lg shadow-lg shadow-black/50"/>
          </div>
        )}
        {!isLoading && !error && !lastGeneratedImage && (
          <div className="text-center text-zinc-600">
            <Icon name="image" className="w-24 h-24 mx-auto" />
            <p className="mt-4">Your generated image will appear here.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default GenerationView;