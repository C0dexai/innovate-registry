import React from 'react';
import { GeneratedImage } from '../types';
import { Icon } from './Icon';

interface ImageCardProps {
  image: GeneratedImage;
  isFavorite: boolean;
  onToggleFavorite: (id: string) => Promise<void>;
}

export const ImageCard: React.FC<ImageCardProps> = ({ image, isFavorite, onToggleFavorite }) => {
  return (
    <div className="group relative overflow-hidden rounded-xl shadow-lg bg-zinc-900/70 backdrop-blur-sm border border-zinc-800 aspect-w-1 aspect-h-1 transition-all duration-300 hover:border-fuchsia-500/50 hover:shadow-xl hover:shadow-fuchsia-500/20">
      <img
        src={image.imageUrl}
        alt={image.prompt}
        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
      
      <div className="absolute top-3 left-3 flex items-center space-x-2">
         {image.isBookmarked && (
            <div className="flex items-center justify-center bg-zinc-900/60 text-cyan-300 p-1.5 rounded-full transition-opacity duration-300 opacity-0 group-hover:opacity-100" title="Bookmarked">
                <Icon name="bookmark" className="w-4 h-4 fill-current" />
            </div>
         )}
         {image.seed && (
            <div className="flex items-center space-x-1.5 bg-zinc-900/60 backdrop-blur-sm text-white/90 px-2 py-1 rounded-full text-xs transition-opacity duration-300 opacity-0 group-hover:opacity-100" title={`Seed: ${image.seed}`}>
                <Icon name="key" className="w-3 h-3" />
                <span className="font-mono">{image.seed}</span>
            </div>
        )}
      </div>

      <div className="absolute bottom-0 left-0 p-4 w-full translate-y-full group-hover:translate-y-0 transition-transform duration-300">
        <p className="text-white text-sm font-medium line-clamp-2 drop-shadow-lg">{image.prompt}</p>
      </div>

      <button
        onClick={() => onToggleFavorite(image.id)}
        className={`absolute top-3 right-3 p-2 rounded-full transition-all duration-200  ${isFavorite ? 'bg-red-500/80 text-white' : 'bg-zinc-900/60 backdrop-blur-sm text-white/70 hover:text-white hover:bg-red-500/80'}`}
        title={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
      >
        <Icon name="heart" className={`w-5 h-5 ${isFavorite ? 'fill-current' : ''}`} />
      </button>
    </div>
  );
};