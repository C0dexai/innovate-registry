import React, { useState, useMemo } from 'react';
import { GeneratedImage, GalleryFilter } from '../types';
import { GALLERY_PAGE_SIZE } from '../constants';
import { ImageCard } from './ImageCard';
import { Pagination } from './Pagination';
import { Icon } from './Icon';

interface GalleryViewProps {
  images: GeneratedImage[];
  favoriteImageIds: string[];
  toggleFavoriteImage: (imageId: string) => Promise<void>;
}

const FilterButton: React.FC<{
    label: string;
    icon: 'image' | 'heart' | 'bookmark';
    isActive: boolean;
    onClick: () => void;
}> = ({ label, icon, isActive, onClick }) => {
    const activeClasses = "bg-fuchsia-500 text-black shadow-lg shadow-fuchsia-500/50";
    const inactiveClasses = "bg-zinc-800 text-zinc-300 hover:bg-zinc-700";
    return (
        <button
            onClick={onClick}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors duration-200 text-sm font-bold ${isActive ? activeClasses : inactiveClasses}`}
        >
            <Icon name={icon} className="w-5 h-5"/>
            <span>{label}</span>
        </button>
    );
};


const GalleryView: React.FC<GalleryViewProps> = ({ images, favoriteImageIds, toggleFavoriteImage }) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [filter, setFilter] = useState<GalleryFilter>('all');

  const filteredImages = useMemo(() => {
    if (filter === 'favorites') {
        return images.filter(img => favoriteImageIds.includes(img.id));
    }
    if (filter === 'bookmarked') {
        return images.filter(img => img.isBookmarked);
    }
    return images;
  }, [images, favoriteImageIds, filter]);

  const totalPages = Math.ceil(filteredImages.length / GALLERY_PAGE_SIZE);
  const paginatedImages = filteredImages.slice(
    (currentPage - 1) * GALLERY_PAGE_SIZE,
    currentPage * GALLERY_PAGE_SIZE
  );

  const handlePageChange = (page: number) => {
    if (page > 0 && page <= totalPages) {
      setCurrentPage(page);
    }
  };
  
  const handleFilterChange = (newFilter: GalleryFilter) => {
    setFilter(newFilter);
    setCurrentPage(1);
  };

  if (images.length === 0) {
    return (
        <div className="flex flex-col items-center justify-center h-full text-center text-zinc-500 py-20">
            <Icon name="image" className="w-32 h-32 text-zinc-700" />
            <h2 className="mt-6 text-2xl font-semibold text-zinc-400">Your Gallery is Empty</h2>
            <p className="mt-2">Go to the 'Generate' tab to create your first masterpiece!</p>
        </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold text-white">Image Gallery</h2>
        <div className="flex items-center space-x-2 bg-zinc-900/60 backdrop-blur-md border border-zinc-700 p-1 rounded-xl">
            <FilterButton label="All" icon="image" isActive={filter === 'all'} onClick={() => handleFilterChange('all')} />
            <FilterButton label="Favorites" icon="heart" isActive={filter === 'favorites'} onClick={() => handleFilterChange('favorites')} />
            <FilterButton label="Bookmarked" icon="bookmark" isActive={filter === 'bookmarked'} onClick={() => handleFilterChange('bookmarked')} />
        </div>
      </div>

      {paginatedImages.length > 0 ? (
        <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {paginatedImages.map((image) => (
                <ImageCard
                key={image.id}
                image={image}
                isFavorite={favoriteImageIds.includes(image.id)}
                onToggleFavorite={toggleFavoriteImage}
                />
            ))}
            </div>
            {totalPages > 1 && (
                <Pagination
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={handlePageChange}
                />
            )}
        </>
      ) : (
        <div className="text-center py-20 text-zinc-500">
            <Icon name={filter === 'favorites' ? 'heart' : 'bookmark'} className="w-16 h-16 text-zinc-700 mx-auto" />
            <h3 className="text-xl mt-4">No {filter} images found.</h3>
            {filter === 'favorites' && <p>You haven't favorited any images yet.</p>}
            {filter === 'bookmarked' && <p>Generate images from bookmarked chat messages to see them here.</p>}
        </div>
      )}
    </div>
  );
};

export default GalleryView;