import React, { useState, useMemo } from 'react';
import { FavoritePrompt, GeneratedImage } from '../types';
import { Icon } from './Icon';
import { Pagination } from './Pagination';

interface PromptLibraryProps {
  favoritePrompts: FavoritePrompt[];
  images: GeneratedImage[];
  onClose: () => void;
  onSelectPrompt: (prompt: string) => void;
}

const PROMPTS_PER_PAGE = 6;

const PromptCard: React.FC<{ prompt: FavoritePrompt; image?: GeneratedImage; onSelect: () => void }> = ({ prompt, image, onSelect }) => {
  return (
    <div 
      className="bg-zinc-800 rounded-lg overflow-hidden cursor-pointer group flex flex-col transition-all duration-300 hover:shadow-lg hover:shadow-cyan-500/20 hover:border-cyan-500/50 border border-zinc-700/50"
      onClick={onSelect}
    >
      <div className="w-full aspect-video bg-zinc-900 flex items-center justify-center overflow-hidden">
        {image ? (
          <img src={image.imageUrl} alt={prompt.prompt} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
        ) : (
          <Icon name="image" className="w-12 h-12 text-zinc-700" />
        )}
      </div>
      <div className="p-3 flex-grow">
        <p className="text-sm text-zinc-300 line-clamp-2">{prompt.prompt}</p>
      </div>
    </div>
  );
};

const PromptLibrary: React.FC<PromptLibraryProps> = ({ favoritePrompts, images, onClose, onSelectPrompt }) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredPrompts = useMemo(() => {
    return favoritePrompts.filter(p => p.prompt.toLowerCase().includes(searchTerm.toLowerCase()));
  }, [favoritePrompts, searchTerm]);

  const totalPages = Math.ceil(filteredPrompts.length / PROMPTS_PER_PAGE);
  const paginatedPrompts = filteredPrompts.slice(
    (currentPage - 1) * PROMPTS_PER_PAGE,
    currentPage * PROMPTS_PER_PAGE
  );

  const findImageForPrompt = (prompt: string): GeneratedImage | undefined => {
    // Find the most recent image for this exact prompt
    return images.find(img => img.prompt === prompt);
  };

  return (
    <div 
      className="fixed inset-0 bg-black/70 backdrop-blur-lg z-50 flex items-center justify-center"
      onClick={onClose}
    >
      <div 
        className="bg-zinc-900/70 backdrop-blur-md rounded-2xl shadow-2xl shadow-cyan-500/20 w-full max-w-4xl h-[90vh] max-h-[800px] flex flex-col overflow-hidden border border-zinc-700"
        onClick={e => e.stopPropagation()}
      >
        <header className="p-4 border-b border-zinc-800 flex justify-between items-center flex-shrink-0">
          <h2 className="text-xl font-bold text-white flex items-center gap-3"><Icon name="book-open" className="w-6 h-6 text-cyan-400"/> Prompt Library</h2>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-zinc-700">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </header>
        
        <div className="p-4 flex-shrink-0">
            <input 
                type="text"
                placeholder="Search favorite prompts..."
                value={searchTerm}
                onChange={(e) => {
                    setSearchTerm(e.target.value);
                    setCurrentPage(1);
                }}
                className="w-full p-2 bg-zinc-800 border border-zinc-700 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
            />
        </div>

        <main className="flex-grow p-4 overflow-y-auto">
          {filteredPrompts.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {paginatedPrompts.map(prompt => (
                <PromptCard 
                  key={prompt.id} 
                  prompt={prompt} 
                  image={findImageForPrompt(prompt.prompt)}
                  onSelect={() => onSelectPrompt(prompt.prompt)}
                />
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-center text-zinc-500">
                <Icon name="star" className="w-16 h-16 text-zinc-700" />
                <h3 className="mt-4 text-xl">No Prompts Found</h3>
                <p>{searchTerm ? 'Try a different search term.' : "You haven't favorited any prompts yet."}</p>
            </div>
          )}
        </main>

        {totalPages > 1 && (
          <footer className="p-4 border-t border-zinc-800 flex-shrink-0">
            <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} />
          </footer>
        )}
      </div>
    </div>
  );
};

export default PromptLibrary;