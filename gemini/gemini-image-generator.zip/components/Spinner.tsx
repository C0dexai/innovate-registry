import React from 'react';

interface SpinnerProps {
    large?: boolean;
    className?: string;
}

export const Spinner: React.FC<SpinnerProps> = ({ large = false, className = '' }) => {
  const sizeClass = large ? 'w-10 h-10' : 'w-5 h-5';
  const borderClass = large ? 'border-4' : 'border-2';

  return (
    <div className={`${sizeClass} ${borderClass} border-t-transparent border-solid animate-spin rounded-full border-cyan-500 ${className}`}></div>
  );
};