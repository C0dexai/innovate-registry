import { GoogleGenAI, Type } from "@google/genai";
import { AspectRatio } from "../types";
import { MODEL_NAME } from "../constants";

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Helper to convert a string seed into a numeric seed for the Gemini API
const stringToSeed = (str: string): number => {
  if (!str) return Math.floor(Math.random() * 1_000_000);
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0; // Convert to 32bit integer
  }
  return Math.abs(hash);
};


export const getPromptSuggestions = async (baseTopic: string, seed: string, systemPersona?: string): Promise<string[]> => {
    try {
        const numericSeed = stringToSeed(seed);
        const systemInstruction = `${systemPersona || ''} You are an AI assistant that generates creative prompts for an image generation model. You MUST return a JSON object with a "prompts" key containing an array of 3 unique, creative, and detailed prompts based on the user's topic. Do not include any other text or markdown.`;
        
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Generate 3 prompts based on the topic: "${baseTopic || 'something beautiful and surprising'}".`,
            config: {
                systemInstruction,
                seed: numericSeed,
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        prompts: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.STRING,
                                description: "A creative prompt."
                            }
                        }
                    }
                }
            }
        });

        const jsonStr = response.text.trim();
        const result = JSON.parse(jsonStr);
        if (result.prompts && Array.isArray(result.prompts) && result.prompts.length > 0) {
            return result.prompts;
        }
        throw new Error("Invalid response format from API.");

    } catch (error) {
        console.error("Error generating prompt suggestions:", error);
        if (error instanceof Error) {
            throw new Error(`Failed to get prompt suggestions: ${error.message}`);
        }
        throw new Error("An unknown error occurred while getting prompt suggestions.");
    }
};

export const generateImage = async (
    prompt: string, 
    aspectRatio: AspectRatio
  ): Promise<string> => {
  try {
    const response = await ai.models.generateImages({
        model: MODEL_NAME,
        prompt: prompt,
        config: {
          numberOfImages: 1,
          outputMimeType: 'image/jpeg',
          aspectRatio: aspectRatio,
        },
    });

    if (response.generatedImages && response.generatedImages.length > 0) {
      const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
      return `data:image/jpeg;base64,${base64ImageBytes}`;
    } else {
      throw new Error("No image was generated. The response may have been blocked.");
    }
  } catch (error) {
    console.error("Error generating image with Gemini API:", error);
    if (error instanceof Error) {
        throw new Error(`Failed to generate image: ${error.message}`);
    }
    throw new Error("An unknown error occurred while generating the image.");
  }
};

export const getPostGenerationAnalysis = async (basePrompt: string, systemPersona?: string): Promise<{
    analysis: string,
    storylinePrompts: string[],
    refinementPrompts: string[]
}> => {
     try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `The user just generated an image with the prompt: "${basePrompt}". Provide a brief analysis of the image you would create from this prompt, and then suggest two sets of follow-up prompts.`,
            config: {
                systemInstruction: `${systemPersona || ''} You are a creative assistant for a visual storyteller. You MUST return a JSON object with three keys: "analysis", "storylinePrompts", and "refinementPrompts".
- "analysis": A short, 1-2 sentence analysis describing the image generated from the user's prompt.
- "storylinePrompts": An array of 3 creative prompts to continue a visual story.
- "refinementPrompts": An array of 3 creative prompts to refine or iterate on the current image.
The output must be only the JSON object.`,
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        analysis: { type: Type.STRING, description: "A brief analysis of the generated image." },
                        storylinePrompts: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Prompts to continue a story." },
                        refinementPrompts: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Prompts to refine the current image." }
                    }
                }
            }
        });

        const jsonStr = response.text.trim();
        const result = JSON.parse(jsonStr);
        
        return {
            analysis: result.analysis || "Here is the image you requested.",
            storylinePrompts: result.storylinePrompts || [],
            refinementPrompts: result.refinementPrompts || [],
        };

    } catch (error) {
        console.error("Error generating post-generation analysis:", error);
        return { // return empty object on error
            analysis: "I've generated your image, but I had trouble coming up with suggestions.",
            storylinePrompts: [],
            refinementPrompts: [],
        };
    }
};


export const getPromptRefinements = async (basePrompt: string, systemPersona?: string): Promise<string[]> => {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Based on the user's rough idea: "${basePrompt}", generate 3 more descriptive and artistic versions of this prompt.`,
            config: {
                systemInstruction: `${systemPersona || ''} You are a prompt engineering assistant. You MUST return a JSON object with a "prompts" key, containing an array of 3 improved versions of the user's prompt. The output must be only the JSON object.`,
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        prompts: {
                            type: Type.ARRAY,
                            items: { type: Type.STRING, description: "An improved prompt." }
                        }
                    }
                }
            }
        });
        const jsonStr = response.text.trim();
        const result = JSON.parse(jsonStr);
        return result.prompts || [];

    } catch (error) {
        console.error("Error generating prompt refinements:", error);
        return [];
    }
};