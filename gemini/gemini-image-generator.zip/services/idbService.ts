import { openDB, DBSchema, IDBPDatabase } from 'idb';
import { GeneratedImage, FavoritePrompt, ChatMessage, AppSettings } from '../types';

interface AppDB extends DBSchema {
  generatedImages: {
    key: string;
    value: GeneratedImage;
    indexes: { 'by-date': string };
  };
  favoritePrompts: {
    key: string;
    value: FavoritePrompt;
  };
  favoriteImageIds: {
    key: string;
    value: { id: string };
  };
  chatMessages: {
    key: string;
    value: ChatMessage;
    indexes: { 'by-assistant-date': [string, string] };
  };
  settings: {
    key: string;
    value: AppSettings & { id: string };
  };
}

let dbPromise: Promise<IDBPDatabase<AppDB>>;

const DB_NAME = 'GeminiImageDB';
const DB_VERSION = 2;

const initDB = () => {
  if (!dbPromise) {
    dbPromise = openDB<AppDB>(DB_NAME, DB_VERSION, {
      upgrade(db, oldVersion) {
        if (oldVersion < 1) {
            if (!db.objectStoreNames.contains('generatedImages')) {
              const imageStore = db.createObjectStore('generatedImages', { keyPath: 'id' });
              imageStore.createIndex('by-date', 'createdAt');
            }
            if (!db.objectStoreNames.contains('favoritePrompts')) {
              db.createObjectStore('favoritePrompts', { keyPath: 'id' });
            }
            if (!db.objectStoreNames.contains('favoriteImageIds')) {
              db.createObjectStore('favoriteImageIds', { keyPath: 'id' });
            }
        }
        if (oldVersion < 2) {
            if (!db.objectStoreNames.contains('chatMessages')) {
                const chatStore = db.createObjectStore('chatMessages', { keyPath: 'id' });
                chatStore.createIndex('by-assistant-date', ['assistantName', 'createdAt']);
            }
            if (!db.objectStoreNames.contains('settings')) {
                db.createObjectStore('settings', { keyPath: 'id' });
            }
        }
      },
    });
  }
  return dbPromise;
};

// --- Images ---
export const getImages = async (): Promise<GeneratedImage[]> => {
  const db = await initDB();
  const images = await db.getAllFromIndex('generatedImages', 'by-date');
  return images.reverse();
};

export const addImage = async (image: GeneratedImage): Promise<void> => {
  const db = await initDB();
  await db.put('generatedImages', image);
};

// --- Favorite Prompts ---
export const getFavoritePrompts = async (): Promise<FavoritePrompt[]> => {
  const db = await initDB();
  return (await db.getAll('favoritePrompts')).reverse();
};

export const addFavoritePrompt = async (prompt: FavoritePrompt): Promise<void> => {
  const db = await initDB();
  await db.put('favoritePrompts', prompt);
};

export const removeFavoritePrompt = async (id: string): Promise<void> => {
  const db = await initDB();
  await db.delete('favoritePrompts', id);
};

// --- Favorite Images ---
export const getFavoriteImageIds = async (): Promise<string[]> => {
  const db = await initDB();
  const records = await db.getAll('favoriteImageIds');
  return records.map(r => r.id);
};

export const addFavoriteImageId = async (id: string): Promise<void> => {
  const db = await initDB();
  await db.put('favoriteImageIds', { id });
};

export const removeFavoriteImageId = async (id: string): Promise<void> => {
  const db = await initDB();
  await db.delete('favoriteImageIds', id);
};

// --- Chat Messages ---
export const getChatHistory = async (assistantName: string): Promise<ChatMessage[]> => {
    const db = await initDB();
    const messages = await db.getAllFromIndex('chatMessages', 'by-assistant-date', IDBKeyRange.bound([assistantName, ''], [assistantName, new Date().toISOString()]));
    return messages;
};

export const addChatMessage = async (message: ChatMessage): Promise<void> => {
    const db = await initDB();
    await db.put('chatMessages', message);
};

export const updateChatMessage = async (message: ChatMessage): Promise<void> => {
    const db = await initDB();
    await db.put('chatMessages', message);
};

// --- App Settings ---
export const getSettings = async (): Promise<AppSettings | null> => {
    const db = await initDB();
    const result = await db.get('settings', 'default');
    if (result) {
        const { id, ...settings } = result;
        return settings;
    }
    return null;
};

export const saveSettings = async (settings: AppSettings): Promise<void> => {
    const db = await initDB();
    await db.put('settings', { ...settings, id: 'default' });
};
