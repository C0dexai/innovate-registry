
import { AspectRatio, ImageStyle, AppSettings } from "./types";

export const MODEL_NAME = 'imagen-3.0-generate-002';
export const GALLERY_PAGE_SIZE = 9;

export const ASPECT_RATIOS: AspectRatio[] = ["1:1", "16:9", "9:16", "4:3", "3:4"];
export const IMAGE_STYLES: ImageStyle[] = ["photographic", "cinematic", "digital_art", "anime", "fantasy"];

export const DEFAULT_STYLE_PROMPT_MAP: Record<ImageStyle, string> = {
  photographic: ", professional photorealistic, 8k, sharp focus, high detail",
  cinematic: ", cinematic still, dramatic lighting, epic composition, movie-like",
  digital_art: ", digital painting, concept art, vibrant colors, detailed illustration",
  anime: ", anime style, key visual, beautiful and detailed illustration",
  fantasy: ", fantasy art, epic, detailed, magical, D&D",
};

export const DEFAULT_SETTINGS: AppSettings = {
    stylePromptMap: DEFAULT_STYLE_PROMPT_MAP,
    systemPersona: "You are a helpful and creative AI assistant, an expert in your field. Provide insightful and clear responses.",
    promptPrefix: "masterpiece, best quality, high resolution",
    promptSuffix: "worst quality, low quality, blurry, watermark, text, signature",
};
