import React, { useState, useEffect, useCallback } from 'react';
import { GeneratedImage, FavoritePrompt, Tab, AppSettings } from './types';
import GenerationView from './components/GenerationView';
import GalleryView from './components/GalleryView';
import { Header } from './components/Header';
import * as idb from './services/idbService';
import { Spinner } from './components/Spinner';
import AssistantView from './components/AssistantView';
import SettingsView from './components/SettingsView';
import { DEFAULT_SETTINGS } from './constants';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>('generate');
  
  const [generatedImages, setGeneratedImages] = useState<GeneratedImage[]>([]);
  const [favoritePrompts, setFavoritePrompts] = useState<FavoritePrompt[]>([]);
  const [favoriteImageIds, setFavoriteImageIds] = useState<string[]>([]);
  
  const [isLoading, setIsLoading] = useState(false);
  const [isDBLoading, setIsDBLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [settings, setSettings] = useState<AppSettings | null>(null);

  useEffect(() => {
    const loadData = async () => {
      try {
        setIsDBLoading(true);
        const [images, prompts, favIds, savedSettings] = await Promise.all([
          idb.getImages(),
          idb.getFavoritePrompts(),
          idb.getFavoriteImageIds(),
          idb.getSettings(),
        ]);
        setGeneratedImages(images);
        setFavoritePrompts(prompts);
        setFavoriteImageIds(favIds);
        setSettings(savedSettings || DEFAULT_SETTINGS);

      } catch (err) {
        console.error("Failed to load data from IndexedDB", err);
        setError("Could not load saved data. Please refresh the page.");
      } finally {
        setIsDBLoading(false);
      }
    };
    loadData();
  }, []);
  
  const handleSaveSettings = useCallback(async (newSettings: AppSettings) => {
    setSettings(newSettings);
    await idb.saveSettings(newSettings);
  }, []);

  const addImage = useCallback(async (image: GeneratedImage) => {
    await idb.addImage(image);
    setGeneratedImages(prev => [image, ...prev]);
  }, []);

  const toggleFavoritePrompt = useCallback(async (prompt: string) => {
    const existing = favoritePrompts.find(p => p.prompt === prompt);
    if (existing) {
      await idb.removeFavoritePrompt(existing.id);
      setFavoritePrompts(prev => prev.filter(p => p.id !== existing.id));
    } else {
      const newFavPrompt = { id: crypto.randomUUID(), prompt };
      await idb.addFavoritePrompt(newFavPrompt);
      setFavoritePrompts(prev => [newFavPrompt, ...prev]);
    }
  }, [favoritePrompts]);

  const toggleFavoriteImage = useCallback(async (imageId: string) => {
    const isFavorite = favoriteImageIds.includes(imageId);
    if (isFavorite) {
      await idb.removeFavoriteImageId(imageId);
      setFavoriteImageIds(prev => prev.filter(id => id !== imageId));
    } else {
      await idb.addFavoriteImageId(imageId);
      setFavoriteImageIds(prev => [...prev, imageId]);
    }
  }, [favoriteImageIds]);

  if (isDBLoading || !settings) {
    return (
      <div className="min-h-screen bg-zinc-900 flex flex-col items-center justify-center text-slate-200">
        <Spinner large={true} />
        <p className="mt-4 text-lg">Loading your creative space...</p>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-zinc-900 text-slate-200 font-sans flex flex-col">
      <Header activeTab={activeTab} setActiveTab={setActiveTab} />
      <main className="flex-grow container mx-auto p-4 md:p-8">
        {activeTab === 'generate' && (
          <GenerationView
            addImage={addImage}
            favoritePrompts={favoritePrompts}
            toggleFavoritePrompt={toggleFavoritePrompt}
            isLoading={isLoading}
            setIsLoading={setIsLoading}
            error={error}
            setError={setError}
            settings={settings}
          />
        )}
        {activeTab === 'gallery' && (
          <GalleryView
            images={generatedImages}
            favoriteImageIds={favoriteImageIds}
            toggleFavoriteImage={toggleFavoriteImage}
          />
        )}
        {activeTab === 'assistant' && (
          <AssistantView
            generatedImages={generatedImages}
            favoritePrompts={favoritePrompts}
            toggleFavoritePrompt={toggleFavoritePrompt}
            addImage={addImage}
            settings={settings}
          />
        )}
        {activeTab === 'settings' && (
            <SettingsView 
                settings={settings} 
                onSave={handleSaveSettings}
            />
        )}
      </main>
      <footer className="text-center p-4 text-zinc-500 text-sm border-t border-zinc-800/50">
        <p>Powered by <span className="font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-fuchsia-500" style={{ textShadow: '0 0 8px rgba(6, 182, 212, 0.5), 0 0 12px rgba(217, 70, 239, 0.5)' }}>Gemini API</span>. Created with passion by a Senior Frontend React Engineer.</p>
      </footer>
    </div>
  );
};

export default App;