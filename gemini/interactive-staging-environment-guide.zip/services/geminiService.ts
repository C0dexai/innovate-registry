import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import { fullContextForAI, ICONS } from '../constants';
import type { SimplePersona, AIPersona, NextStepSuggestion, ChatMessage } from '../types';

if (!process.env.API_KEY) {
    console.warn("API_KEY environment variable not set. AI features will be disabled.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

const ensureApiKey = (): boolean => {
    if (!process.env.API_KEY) {
        return false;
    }
    return true;
};

export const getExplanation = async (question: string, persona: SimplePersona): Promise<string> => {
    if (!ensureApiKey()) {
        return "The AI assistant is currently unavailable because the API key is not configured.";
    }

    const systemInstruction = `${persona.persona.description} Your tone must be ${persona.persona.tone}. You explain complex deployment and staging concepts simply, based on the provided context.`;

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Answer the user's question based on the provided context about application staging. Keep the answer concise and easy to understand.
---
CONTEXT:
${fullContextForAI}
---
USER QUESTION: ${question}
`,
            config: {
                systemInstruction,
                temperature: 0.5,
                topP: 1,
                topK: 32
            },
        });
        
        return response.text;
    } catch (error) {
        console.error("Error calling Gemini API:", error);
        if (error instanceof Error) {
            return `Sorry, I encountered an error: ${error.message}`;
        }
        return "An unknown error occurred while contacting the AI assistant.";
    }
};

const itemSchema = {
    type: Type.OBJECT,
    properties: {
        section: {
            type: Type.STRING,
            description: "The target section for the new item. Must be one of: 'architecture' or 'testing'.",
            enum: ["architecture", "testing"],
        },
        item: {
            type: Type.OBJECT,
            description: "The content of the new item. Populate fields based on the section.",
            properties: {
                id: { type: Type.STRING, description: "A unique, URL-friendly ID in kebab-case, based on the title." },
                title: { type: Type.STRING, description: "The title of the new item." },
                description: { type: Type.STRING, description: "Required for 'testing' section. A paragraph explaining the concept." },
                icon: { type: Type.STRING, description: "Required for 'architecture' section. A relevant icon name." },
                purpose: { type: Type.STRING, description: "Required for 'architecture' section. What is the component's purpose?" },
                configuration: { type: Type.STRING, description: "Required for 'architecture' section. How should it be configured in staging?" },
            },
            required: ["id", "title"]
        }
    },
    required: ["section", "item"]
};


export const generateGuideItem = async (prompt: string, persona: SimplePersona): Promise<any> => {
    if (!ensureApiKey()) {
        throw new Error("The AI assistant is currently unavailable because the API key is not configured.");
    }
    
    const systemInstruction = `${persona.persona.description} Your tone must be ${persona.persona.tone}. As an expert content designer for a technical guide about software deployment, your task is to add new sections to the guide based on user requests. You must generate content that is accurate, concise, and fits the structure of the guide. You must output your response in the specified JSON format.`;
    const fullPrompt = `The user wants to add a new item to an interactive guide.
User Request: "${prompt}"

Based on this request, determine which section the new item belongs to. It should be either 'architecture' (for infrastructure components) or 'testing' (for testing methodologies). Then, generate the content for it.

- For the 'architecture' section, you must provide: id, title, icon, purpose, and configuration. The 'icon' must be a relevant choice from: ${Object.keys(ICONS).join(', ')}.
- For a 'testing' item, you must provide: id, title, and description.

Generate a unique 'id' in kebab-case based on the title. The title should be well-written and informative for a software developer audience.`;

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: fullPrompt,
            config: {
                systemInstruction,
                responseMimeType: "application/json",
                responseSchema: itemSchema,
            },
        });
        
        const jsonText = response.text.trim();
        return JSON.parse(jsonText);

    } catch (error) {
        console.error("Error calling Gemini API for item generation:", error);
        if (error instanceof Error) {
            throw new Error(`Sorry, I encountered an error while generating content: ${error.message}`);
        }
        throw new Error("An unknown error occurred while contacting the AI assistant.");
    }
};

export const getHint = async (prompt: string, persona: AIPersona): Promise<string> => {
    if (!ensureApiKey()) throw new Error("AI is disabled. API key not set.");
    const systemInstruction = `${persona.persona.description} Your tone must be ${persona.persona.tone}. You provide helpful, specific hints for a software development task.`;
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Based on the following task, provide a concise, actionable hint for a developer.\n\nTASK:\n${prompt}`,
            config: { systemInstruction }
        });
        return response.text;
    } catch (error) {
        console.error("Error in getHint:", error);
        throw new Error("Failed to get hint from AI.");
    }
};

export const refineHint = async (prompt: string, originalHint: string, persona: AIPersona): Promise<string> => {
    if (!ensureApiKey()) throw new Error("AI is disabled. API key not set.");
    const systemInstruction = `${persona.persona.description} Your tone must be ${persona.persona.tone}. You refine and expand upon existing hints to make them more useful.`;
     try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `A developer is working on this task:\nTASK: ${prompt}\n\nThey received this initial hint:\nHINT: ${originalHint}\n\nRefine this hint. Make it more detailed, add a code example if applicable, or explain the concept more clearly. Do not repeat the original hint verbatim; provide new value.`,
            config: { systemInstruction }
        });
        return response.text;
    } catch (error) {
        console.error("Error in refineHint:", error);
        throw new Error("Failed to refine hint with AI.");
    }
};

const nextStepSuggestionSchema = {
    type: Type.ARRAY,
    items: {
        type: Type.OBJECT,
        properties: {
            serviceName: { type: Type.STRING, description: 'Name of the suggested service or tool.' },
            description: { type: Type.STRING, description: 'A brief description of the service.' },
            integrationRationale: { type: Type.STRING, description: 'Why this service is a good fit for the current task.' },
            actionPrompt: { type: Type.STRING, description: 'A detailed prompt for the AI to generate an implementation plan for this service.' },
        },
        required: ["serviceName", "description", "integrationRationale", "actionPrompt"]
    }
};

export const suggestNextSteps = async (prompt: string, context: string, persona: AIPersona): Promise<NextStepSuggestion[]> => {
    if (!ensureApiKey()) throw new Error("AI is disabled. API key not set.");
    const systemInstruction = `${persona.persona.description} Your tone must be ${persona.persona.tone}. You are an AI Concierge that suggests relevant tools and services.`;
    const fullPrompt = `A developer is working on a task described as: "${prompt}".
They have the following context/hint: "${context}".

Based on this, suggest 1-2 relevant tools, services, or libraries that could help them. For each suggestion, provide a rationale for why it's a good fit and create a detailed "action prompt" that could be used to ask another AI to generate an implementation plan.`;
    
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: fullPrompt,
            config: {
                systemInstruction,
                responseMimeType: "application/json",
                responseSchema: nextStepSuggestionSchema,
            }
        });
        
        return JSON.parse(response.text.trim());
    } catch (error) {
        console.error("Error in suggestNextSteps:", error);
        throw new Error("Failed to get next step suggestions from AI.");
    }
};

export const getImplementationPlan = async (prompt: string, persona: AIPersona): Promise<string> => {
    if (!ensureApiKey()) throw new Error("AI is disabled. API key not set.");
    const systemInstruction = `${persona.persona.description} Your tone must be ${persona.persona.tone}. You create clear, step-by-step implementation plans for developers. Format your response with markdown, including code blocks.`;
    
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Create a detailed, step-by-step implementation plan based on the following request. Use markdown for formatting, including headers, lists, and code blocks for any code examples.\n\nREQUEST:\n${prompt}`,
            config: { systemInstruction }
        });
        return response.text;
    } catch (error) {
        console.error("Error in getImplementationPlan:", error);
        throw new Error("Failed to get implementation plan from AI.");
    }
};

export const getChatResponse = async (history: ChatMessage[], persona: AIPersona): Promise<string> => {
    if (!ensureApiKey()) throw new Error("AI is disabled. API key not set.");
    const systemInstruction = `${persona.persona.description} Your tone must be ${persona.persona.tone}. You are a helpful AI assistant in a chat. The user is trying to implement a step in a development plan. Provide code, explanations, and guidance. The conversation history includes an initial system-generated plan.`;

    const formattedHistory = history.map(msg => `${msg.role}:\n${msg.content}`).join('\n\n---\n\n');

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `This is a conversation about implementing a development task. Continue the conversation naturally.\n\nCONTEXT:\n${formattedHistory}\n\nAI:`,
            config: { systemInstruction, temperature: 0.7 }
        });

        return response.text;
    } catch (error) {
        console.error("Error in getChatResponse:", error);
        throw new Error("Failed to get chat response from AI.");
    }
};
