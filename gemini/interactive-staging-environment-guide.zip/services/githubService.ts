import type { GitHubFile, GitHubContent } from '../types';

const GITHUB_API_BASE = 'https://api.github.com';

async function githubApiFetch(url: string, token: string, options: RequestInit = {}): Promise<Response> {
    const headers = {
        ...options.headers,
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/vnd.github.v3+json',
        'X-GitHub-Api-Version': '2022-11-28',
    };

    const response = await fetch(url, { ...options, headers });

    if (!response.ok) {
        const errorData = await response.json().catch(() => ({ message: 'Failed to parse error response.' }));
        const errorMessage = `GitHub API Error: ${response.status} ${response.statusText}. ${errorData.message || ''}`;
        throw new Error(errorMessage.trim());
    }

    return response;
}

export const getRepoContents = async (owner: string, repo: string, path: string = '', token: string): Promise<GitHubFile[]> => {
    const url = `${GITHUB_API_BASE}/repos/${owner}/${repo}/contents/${path}`;
    const response = await githubApiFetch(url, token);
    const data: GitHubFile[] = await response.json();
    // Sort with directories first
    return data.sort((a, b) => {
        if (a.type === b.type) {
            return a.name.localeCompare(b.name);
        }
        return a.type === 'dir' ? -1 : 1;
    });
};

export const getFileContent = async (owner: string, repo: string, path: string, token: string): Promise<string> => {
    const url = `${GITHUB_API_BASE}/repos/${owner}/${repo}/contents/${path}`;
    const response = await githubApiFetch(url, token);
    const data: GitHubContent = await response.json();
    
    if (data.encoding !== 'base64') {
        throw new Error(`Unsupported file encoding: ${data.encoding}`);
    }
    
    // Decode base64 content
    try {
        return atob(data.content);
    } catch (e) {
        console.error("Base64 decoding failed:", e);
        throw new Error("Failed to decode file content from base64.");
    }
};

export const getRepoDetails = async (owner: string, repo: string, token: string): Promise<any> => {
     const url = `${GITHUB_API_BASE}/repos/${owner}/${repo}`;
     const response = await githubApiFetch(url, token);
     return response.json();
};
