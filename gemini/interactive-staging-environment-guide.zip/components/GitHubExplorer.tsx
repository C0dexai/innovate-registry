import React, { useState, useCallback, useEffect } from 'react';
import { getRepoContents, getFileContent, getRepoDetails } from '../services/githubService';
import type { GitHubFile } from '../types';
import FileTree from './FileTree';

const GitHubExplorer: React.FC = () => {
    const [token, setToken] = useState<string>('');
    const [owner, setOwner] = useState<string>('');
    const [repo, setRepo] = useState<string>('');

    const [isConnected, setIsConnected] = useState<boolean>(false);
    const [repoDetails, setRepoDetails] = useState<any>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    const [currentPath, setCurrentPath] = useState<string>('');
    const [files, setFiles] = useState<GitHubFile[]>([]);
    const [selectedFile, setSelectedFile] = useState<{ path: string; content: string } | null>(null);

    const fetchFiles = useCallback(async (path: string) => {
        if (!token || !owner || !repo) return;
        setIsLoading(true);
        setError(null);
        setSelectedFile(null); // Deselect file when navigating
        try {
            const contents = await getRepoContents(owner, repo, path, token);
            setFiles(contents);
            setCurrentPath(path);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred while fetching files.');
        } finally {
            setIsLoading(false);
        }
    }, [owner, repo, token]);

    const handleConnect = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!token || !owner || !repo) {
            setError('Please fill in all fields.');
            return;
        }
        setIsLoading(true);
        setError(null);
        try {
            const details = await getRepoDetails(owner, repo, token);
            setRepoDetails(details);
            setIsConnected(true);
            await fetchFiles('');
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Failed to connect. Check credentials and repo details.');
            setIsConnected(false);
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleFileSelect = async (path: string) => {
        setIsLoading(true);
        setError(null);
        try {
            const content = await getFileContent(owner, repo, path, token);
            setSelectedFile({ path, content });
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Failed to fetch file content.');
        } finally {
            setIsLoading(false);
        }
    };

    const handleDirSelect = (path: string) => {
        fetchFiles(path);
    };
    
    const handleNavigateUp = () => {
        if (!currentPath) return;
        const pathParts = currentPath.split('/').slice(0, -1);
        fetchFiles(pathParts.join('/'));
    };
    
    const handleDisconnect = () => {
        // Keep owner and repo for easier reconnection
        setToken('');
        setIsConnected(false);
        setRepoDetails(null);
        setFiles([]);
        setCurrentPath('');
        setSelectedFile(null);
        setError(null);
    };

    return (
        <div className="bg-base-200/50 backdrop-blur-sm rounded-xl border border-base-300 p-4 md:p-8 space-y-6">
            {!isConnected ? (
                <div>
                    <h3 className="text-2xl font-bold text-content mb-2">Connect to GitHub Repository</h3>
                    <p className="text-content/80 mb-4">Enter a personal access token and repository details to browse files.</p>
                    <form onSubmit={handleConnect} className="space-y-4">
                         <div>
                            <label htmlFor="token" className="block text-sm font-medium text-content/90 mb-1">GitHub Personal Access Token (PAT)</label>
                            <input
                                id="token"
                                type="password"
                                value={token}
                                onChange={e => setToken(e.target.value)}
                                placeholder="ghp_..."
                                className="w-full bg-base-300 border border-base-300 text-content rounded-lg p-3 focus:ring-2 focus:ring-brand-primary focus:outline-none transition"
                            />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                             <div>
                                <label htmlFor="owner" className="block text-sm font-medium text-content/90 mb-1">Repository Owner</label>
                                <input id="owner" type="text" value={owner} onChange={e => setOwner(e.target.value)} placeholder="e.g., facebook" className="w-full bg-base-300 border border-base-300 text-content rounded-lg p-3 focus:ring-2 focus:ring-brand-primary focus:outline-none transition" />
                            </div>
                            <div>
                                <label htmlFor="repo" className="block text-sm font-medium text-content/90 mb-1">Repository Name</label>
                                <input id="repo" type="text" value={repo} onChange={e => setRepo(e.target.value)} placeholder="e.g., react" className="w-full bg-base-300 border border-base-300 text-content rounded-lg p-3 focus:ring-2 focus:ring-brand-primary focus:outline-none transition" />
                            </div>
                        </div>
                        <button type="submit" disabled={isLoading} className="bg-brand-secondary text-text-on-neon font-bold py-3 px-6 rounded-lg hover:bg-neon-pink/80 transition-all duration-300 disabled:bg-base-300 disabled:text-content/50 disabled:cursor-not-allowed">
                            {isLoading ? 'Connecting...' : 'Connect'}
                        </button>
                    </form>
                    {error && <p className="mt-4 text-neon-pink/80 bg-neon-pink/10 p-3 rounded-lg border border-neon-pink/20">{error}</p>}
                </div>
            ) : (
                <div>
                     <div className="flex justify-between items-start mb-4 gap-4 flex-wrap">
                        <div>
                            <h3 className="text-2xl font-bold text-content">Repository: {repoDetails?.full_name}</h3>
                            <p className="text-content/80 max-w-2xl">{repoDetails?.description}</p>
                        </div>
                        <button onClick={handleDisconnect} className="bg-base-300 hover:bg-neon-pink/80 hover:text-text-on-neon text-content font-bold py-2 px-4 rounded-lg transition-colors flex-shrink-0">Disconnect</button>
                     </div>

                    <div className="grid grid-cols-1 md:grid-cols-12 gap-4 h-[70vh] min-h-[500px]">
                        <div className="md:col-span-4 lg:col-span-3">
                            <FileTree 
                                files={files}
                                currentPath={currentPath}
                                onFileSelect={handleFileSelect}
                                onDirSelect={handleDirSelect}
                                onNavigateUp={handleNavigateUp}
                                selectedFile={selectedFile?.path || null}
                            />
                        </div>
                        <div className="md:col-span-8 lg:col-span-9 bg-base-100 rounded-lg flex flex-col">
                            {(isLoading || error || selectedFile) ? (
                                <>
                                {isLoading && (
                                    <div className="flex items-center justify-center h-full text-content/80">
                                        <svg className="animate-spin h-8 w-8 text-brand-primary mr-3" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                                        Loading...
                                    </div>
                                )}
                                {error && <div className="flex items-center justify-center h-full text-neon-pink p-4">{error}</div>}
                                
                                {selectedFile && (
                                    <div className="h-full flex flex-col">
                                        <div className="flex-shrink-0 p-3 bg-base-200 rounded-t-lg">
                                            <p className="font-mono text-sm text-neon-green truncate" title={selectedFile.path}>{selectedFile.path}</p>
                                        </div>
                                        <div className="flex-grow overflow-auto bg-base-100 rounded-b-lg">
                                            <pre className="p-4 text-sm text-content/90 whitespace-pre-wrap break-all h-full">
                                                <code>
                                                    {selectedFile.content}
                                                </code>
                                            </pre>
                                        </div>
                                    </div>
                                )}
                                </>
                            ) : (
                                <div className="flex items-center justify-center h-full text-content/70">
                                    <p>Select a file to view its content.</p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default GitHubExplorer;
