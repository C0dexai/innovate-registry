
import React, { useState, useEffect, useRef } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { addChatMessage, getChatHistoryForStep } from '../db';
import { getChatResponse } from '../services/geminiService';
import type { AIPersona, DevelopmentStep, ChatMessage } from '../types';

interface ImplementationWorkspaceProps {
  step: DevelopmentStep;
  persona: AIPersona;
  onClose: () => void;
  isApiKeySet: boolean;
}

const ImplementationWorkspace: React.FC<ImplementationWorkspaceProps> = ({ step, persona, onClose, isApiKeySet }) => {
  const [userInput, setUserInput] = useState('');
  const [isAiThinking, setIsAiThinking] = useState(false);
  const chatHistory = useLiveQuery(() => getChatHistoryForStep(step.id), [step.id]);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    // Auto-scroll to bottom of chat
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [chatHistory]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userInput.trim() || isAiThinking || !isApiKeySet) return;

    const userMessage: Omit<ChatMessage, 'id' | 'timestamp'> = {
      stepId: step.id,
      role: 'USER',
      content: userInput,
    };
    
    await addChatMessage(userMessage);
    setUserInput('');
    setIsAiThinking(true);

    try {
      const fullHistory = [...(chatHistory || []), { ...userMessage, timestamp: new Date(), id: Date.now() }];
      // @ts-ignore - type mismatch on role
      const aiResponse = await getChatResponse(fullHistory, persona);
      
      const aiMessage: Omit<ChatMessage, 'id' | 'timestamp'> = {
        stepId: step.id,
        role: 'AI',
        content: aiResponse,
      };
      await addChatMessage(aiMessage);
    } catch (error) {
      console.error("Failed to get AI response:", error);
      const errorMessage: Omit<ChatMessage, 'id' | 'timestamp'> = {
        stepId: step.id,
        role: 'SYSTEM',
        content: 'Error fetching AI response. Please try again.',
      };
      await addChatMessage(errorMessage);
    } finally {
      setIsAiThinking(false);
    }
  };

  const planHistory = chatHistory?.filter(m => m.role === 'SYSTEM') || [];
  const chatMessages = chatHistory?.filter(m => m.role !== 'SYSTEM') || [];

  return (
    <div className="fixed inset-0 bg-base-100/80 backdrop-blur-md z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-base-200 border border-base-300 rounded-2xl w-full h-full max-w-6xl flex flex-col" onClick={e => e.stopPropagation()}>
        <header className="p-4 border-b border-base-300 flex justify-between items-center shrink-0">
          <div>
            <h2 className="text-xl font-bold text-content">Implementation Workspace</h2>
            <p className="text-sm text-content/80">{step.title}</p>
          </div>
          <button onClick={onClose} className="text-2xl p-2 rounded-full hover:bg-base-300 w-10 h-10 flex items-center justify-center text-content/70 hover:text-content">&times;</button>
        </header>
        
        <div className="flex-grow grid grid-cols-1 md:grid-cols-2 gap-px bg-base-300 overflow-hidden">
          {/* Left Panel: History/Plan */}
          <div className="bg-base-200 flex flex-col p-4 overflow-y-auto">
            <h3 className="text-lg font-semibold text-content mb-3">Implementation Plan & History</h3>
            <div className="space-y-4">
              {planHistory.map((msg) => (
                <div key={msg.id} className="p-3 bg-base-300 rounded-lg text-sm text-content/90">
                  <p className="font-semibold text-neon-green mb-2">Initial Plan ({msg.timestamp.toLocaleTimeString()})</p>
                  <div className="whitespace-pre-wrap prose prose-sm prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: msg.content.replace(/```(\w*)\n([\s\S]*?)\n```/g, '<pre class="bg-base-100 p-3 rounded-md my-2 overflow-x-auto border-l-4 border-neon-purple"><code>$2</code></pre>') }} />
                </div>
              ))}
            </div>
          </div>

          {/* Right Panel: Chat Agent */}
          <div className="bg-base-200 flex flex-col">
            <div ref={chatContainerRef} className="flex-grow p-4 overflow-y-auto space-y-4">
                {chatMessages.map((msg) => (
                    <div key={msg.id} className={`flex items-start gap-3 ${msg.role === 'USER' ? 'justify-end' : 'justify-start'}`}>
                         {msg.role === 'AI' && <div className="w-8 h-8 rounded-full bg-brand-secondary flex-shrink-0 text-text-on-neon text-xs flex items-center justify-center font-bold">{persona.name.charAt(0)}</div>}
                         <div className={`max-w-md p-3 rounded-xl ${msg.role === 'USER' ? 'bg-brand-primary text-text-on-neon' : 'bg-base-300 text-content'}`}>
                           <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                         </div>
                    </div>
                ))}
                {isAiThinking && (
                    <div className="flex items-start gap-3 justify-start">
                        <div className="w-8 h-8 rounded-full bg-brand-secondary flex-shrink-0 text-text-on-neon text-xs flex items-center justify-center font-bold animate-pulse">{persona.name.charAt(0)}</div>
                        <div className="max-w-md p-3 rounded-xl bg-base-300 text-content/80 animate-pulse">Thinking...</div>
                    </div>
                )}
            </div>
            <form onSubmit={handleSendMessage} className="p-4 border-t border-base-300 shrink-0">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={userInput}
                  onChange={(e) => setUserInput(e.target.value)}
                  placeholder={isApiKeySet ? `Ask ${persona.name} for help...` : "AI is disabled"}
                  disabled={!isApiKeySet || isAiThinking}
                  className="flex-grow bg-base-300 border border-base-300 text-content rounded-lg p-3 focus:ring-2 focus:ring-brand-secondary focus:outline-none transition"
                />
                <button type="submit" disabled={!isApiKeySet || isAiThinking || !userInput.trim()} className="bg-brand-secondary text-text-on-neon font-bold py-3 px-6 rounded-lg hover:bg-neon-pink/80 transition-colors disabled:bg-base-300 disabled:text-content/50">Send</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImplementationWorkspace;