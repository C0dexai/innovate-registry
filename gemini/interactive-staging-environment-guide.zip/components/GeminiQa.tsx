import React, { useState, useCallback } from 'react';
import { getExplanation, generateGuideItem } from '../services/geminiService';
import type { SimplePersona } from '../types';

interface InteractiveAssistantProps {
    onAddItem: (section: string, item: any) => void;
    selectedPersona: SimplePersona;
}

const InteractiveAssistant: React.FC<InteractiveAssistantProps> = ({ onAddItem, selectedPersona }) => {
    const [question, setQuestion] = useState<string>('');
    const [answer, setAnswer] = useState<string>('');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string>('');
    const [mode, setMode] = useState<'question' | 'customize'>('question');
    
    const isApiKeySet = !!process.env.API_KEY;

    const handleSubmit = useCallback(async (e: React.FormEvent) => {
        e.preventDefault();
        if (!question.trim() || !isApiKeySet) return;

        setIsLoading(true);
        setAnswer('');
        setError('');

        try {
            if (mode === 'question') {
                const result = await getExplanation(question, selectedPersona);
                setAnswer(result);
            } else { // mode === 'customize'
                const result = await generateGuideItem(question, selectedPersona);
                if (result && result.section && result.item) {
                    onAddItem(result.section, result.item);
                    setAnswer(`Successfully added "${result.item.title}" to the guide!`);
                    setQuestion('');
                } else {
                     throw new Error('The AI did not return a valid item structure. Please try rephrasing your request.');
                }
            }
        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
            setError(errorMessage);
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    }, [question, isApiKeySet, mode, onAddItem, selectedPersona]);

    const handleModeChange = (newMode: 'question' | 'customize') => {
        setMode(newMode);
        setAnswer('');
        setError('');
        setQuestion('');
    };

    return (
        <div className="bg-base-200/50 p-6 md:p-8 rounded-2xl border border-base-300">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4">
                 <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-neon-purple to-neon-blue rounded-full flex items-center justify-center shrink-0">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                    </div>
                    <div>
                        <h3 className="text-2xl font-bold text-content">Interactive Assistant</h3>
                        <p className="text-sm text-content/80">Powered by {selectedPersona.name}</p>
                    </div>
                </div>
            </div>

            <div className="flex bg-base-300/60 rounded-lg p-1 mb-6">
                <button onClick={() => handleModeChange('question')} className={`w-1/2 p-2 rounded-md font-bold transition-colors ${mode === 'question' ? 'bg-brand-secondary text-text-on-neon' : 'text-content/80 hover:bg-base-200/50'}`}>Ask a Question</button>
                <button onClick={() => handleModeChange('customize')} className={`w-1/2 p-2 rounded-md font-bold transition-colors ${mode === 'customize' ? 'bg-brand-secondary text-text-on-neon' : 'text-content/80 hover:bg-base-200/50'}`}>Customize Guide</button>
            </div>
            
            <p className="text-content/80 mb-6 min-h-[40px]">
                {mode === 'question' ? 'Have a question about the content on this page? Ask away!' : 'Request a new topic to add to the Architecture or Testing sections.'}
            </p>

            <form onSubmit={handleSubmit}>
                <div className="flex flex-col sm:flex-row gap-2">
                    <input
                        type="text"
                        value={question}
                        onChange={(e) => setQuestion(e.target.value)}
                        placeholder={isApiKeySet ? (mode === 'question' ? "e.g., What is cache busting?" : "e.g., Add a section on Canary Deployments") : "AI assistant is disabled (no API key)"}
                        className="flex-grow bg-base-300 border border-base-300 text-content rounded-lg p-3 focus:ring-2 focus:ring-brand-primary focus:outline-none transition"
                        disabled={isLoading || !isApiKeySet}
                    />
                    <button
                        type="submit"
                        disabled={isLoading || !question.trim() || !isApiKeySet}
                        className="bg-brand-secondary text-text-on-neon font-bold py-3 px-6 rounded-lg hover:bg-neon-pink/80 transition-all duration-300 disabled:bg-base-300 disabled:text-content/50 disabled:cursor-not-allowed flex items-center justify-center"
                    >
                        {isLoading ? (
                           <svg className="animate-spin h-5 w-5 text-text-on-neon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                        ) : (mode === 'question' ? 'Ask AI' : 'Add Content')}
                    </button>
                </div>
            </form>
            
            {!isApiKeySet && (
                <div className="mt-4 text-sm text-neon-green/80 bg-neon-green/10 p-3 rounded-lg border border-neon-green/20">
                    <strong>Note:</strong> The AI features are disabled. To enable them, an administrator must set the `API_KEY` environment variable.
                </div>
            )}

            {error && <p className="mt-4 text-neon-pink/80 bg-neon-pink/10 p-3 rounded-lg border border-neon-pink/20">{error}</p>}

            {(isLoading || answer) && (
                <div className="mt-6 p-4 bg-base-300/70 rounded-lg border border-base-300/50">
                    {isLoading && <p className="text-content/80 animate-pulse">The AI is thinking...</p>}
                    {answer && <p className="text-content whitespace-pre-wrap">{answer}</p>}
                </div>
            )}
        </div>
    );
};

export default InteractiveAssistant;