
import React from 'react';
import type { AIPersona } from '../types';

interface PersonaCardProps {
  persona: AIPersona;
  isSelected: boolean;
  onSelect: (name: string) => void;
}

const PersonaCard: React.FC<PersonaCardProps> = ({ persona, isSelected, onSelect }) => {
  return (
    <button
      onClick={() => onSelect(persona.name)}
      className={`w-full h-full p-6 rounded-2xl text-left transition-all duration-300 border-2 flex flex-col ${
        isSelected
          ? 'bg-base-200/80 border-brand-secondary ring-2 ring-brand-secondary ring-offset-2 ring-offset-base-100 shadow-glow-pink'
          : 'bg-base-200/50 border-base-300 hover:border-brand-primary hover:shadow-glow-blue'
      }`}
      aria-pressed={isSelected}
    >
      <h3 className="text-2xl font-bold text-content">{persona.name}</h3>
      <p className="text-brand-secondary font-semibold mb-3">{persona.role}</p>
      <p className="text-sm text-content/80 mb-4 flex-grow">{persona.persona.description}</p>
      <ul className="space-y-1">
        {persona.superpowers.map((power, index) => (
          <li key={index} className="flex items-start gap-2 text-xs text-content/90">
            <svg className="w-4 h-4 text-neon-green shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
            </svg>
            <span>{power}</span>
          </li>
        ))}
      </ul>
    </button>
  );
};

export default PersonaCard;