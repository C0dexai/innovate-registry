
import React, { useState, useCallback } from 'react';
import type { DevelopmentPhase, DevelopmentStep, AIPersona, NextStepSuggestion } from '../types';
import { getHint, refineHint, suggestNextSteps, getImplementationPlan } from '../services/geminiService';
import { addChatMessage } from '../db';
import ImplementationWorkspace from './ImplementationWorkspace';

interface HintState {
    [stepId: string]: {
        loading: boolean;
        error: string | null;
        content: string | null;

        isRefined: boolean;

        suggestionsLoading: boolean;
        suggestionsError: string | null;
        suggestions: NextStepSuggestion[] | null;

        implementationLoading: boolean;
        implementationError: string | null;
        
        workspaceActive: boolean;
    };
}

const DevelopmentPlan: React.FC<{ plan: DevelopmentPhase[], persona: AIPersona, onStepToggle: (stepId: string) => void, isApiKeySet: boolean }> = ({ plan, persona, onStepToggle, isApiKeySet }) => {
    const [hints, setHints] = useState<HintState>({});
    const [copyStatus, setCopyStatus] = useState<{[key: string]: boolean}>({});

    const getStepState = (stepId: string) => hints[stepId] || {
        loading: false, error: null, content: null, isRefined: false,
        suggestionsLoading: false, suggestionsError: null, suggestions: null,
        implementationLoading: false, implementationError: null, workspaceActive: false,
    };

    const handleGetHint = useCallback(async (step: DevelopmentStep) => {
        setHints(prev => ({ ...prev, [step.id]: { ...getStepState(step.id), loading: true, error: null } }));
        try {
            const hintContent = await getHint(step.hintPrompt, persona);
            setHints(prev => ({ ...prev, [step.id]: { ...getStepState(step.id), loading: false, content: hintContent } }));
        } catch (err) {
            const error = err instanceof Error ? err.message : "An unknown error occurred.";
            setHints(prev => ({ ...prev, [step.id]: { ...getStepState(step.id), loading: false, error } }));
        }
    }, [persona]);

    const handleRefineHint = useCallback(async (step: DevelopmentStep) => {
        const currentHint = getStepState(step.id).content;
        if (!currentHint) return;

        setHints(prev => ({ ...prev, [step.id]: { ...getStepState(step.id), loading: true, error: null } }));
        try {
            const refinedContent = await refineHint(step.hintPrompt, currentHint, persona);
            setHints(prev => ({ ...prev, [step.id]: { ...getStepState(step.id), loading: false, content: refinedContent, isRefined: true } }));
        } catch (err) {
            const error = err instanceof Error ? err.message : "An unknown error occurred.";
            setHints(prev => ({ ...prev, [step.id]: { ...getStepState(step.id), loading: false, error } }));
        }
    }, [persona, hints]);

    const handleSuggestNextSteps = useCallback(async (step: DevelopmentStep) => {
        const currentHint = getStepState(step.id).content;
        if (!currentHint) return;

        setHints(prev => ({ ...prev, [step.id]: { ...getStepState(step.id), suggestionsLoading: true, suggestionsError: null, suggestions: null } }));
        try {
            const suggestions = await suggestNextSteps(step.hintPrompt, currentHint, persona);
            setHints(prev => ({ ...prev, [step.id]: { ...getStepState(step.id), suggestionsLoading: false, suggestions } }));
        } catch (err) {
            const error = err instanceof Error ? err.message : "An unknown error occurred.";
            setHints(prev => ({ ...prev, [step.id]: { ...getStepState(step.id), suggestionsLoading: false, suggestionsError: error } }));
        }
    }, [persona, hints]);
    
    const handleGetImplementation = useCallback(async (step: DevelopmentStep, suggestion: NextStepSuggestion) => {
        const stepId = step.id;
        setHints(prev => ({
            ...prev,
            [stepId]: {
                ...getStepState(stepId),
                implementationLoading: true,
                implementationError: null,
            }
        }));
        try {
            const planText = await getImplementationPlan(suggestion.actionPrompt, persona);
            // Save the plan to IndexedDB as a system message
            await addChatMessage({
                stepId,
                role: 'SYSTEM',
                content: planText
            });

            // Update state to open the workspace
            setHints(prev => ({ 
                ...prev, 
                [stepId]: { 
                    ...getStepState(stepId), 
                    implementationLoading: false, 
                    workspaceActive: true 
                } 
            }));
        } catch (err) {
            const error = err instanceof Error ? err.message : "An unknown error occurred.";
            setHints(prev => ({ ...prev, [stepId]: { ...getStepState(stepId), implementationLoading: false, implementationError: error } }));
        }
    }, [persona, hints]);

    const handleCloseWorkspace = (stepId: string) => {
        setHints(prev => ({
            ...prev,
            [stepId]: { ...getStepState(stepId), workspaceActive: false }
        }));
    };

    const handleCopy = (key: string, textToCopy: string | null) => {
        if (!textToCopy) return;
        navigator.clipboard.writeText(textToCopy);
        setCopyStatus(prev => ({ ...prev, [key]: true }));
        setTimeout(() => setCopyStatus(prev => ({ ...prev, [key]: false })), 2000);
    };

    return (
        <div className="space-y-8">
            {plan.map((phase, phaseIndex) => (
                <div key={phase.title} className="relative pl-8">
                    <div className="absolute left-0 flex items-center">
                        <div className="h-8 w-8 rounded-full bg-brand-secondary flex items-center justify-center text-text-on-neon font-bold">{phaseIndex + 1}</div>
                    </div>
                    <h3 className="text-2xl font-bold text-content mb-4 ml-4">{phase.title}</h3>
                    <div className="border-l-2 border-base-300 ml-4">
                        {phase.steps.map((step) => {
                            const state = getStepState(step.id);

                            // Conditionally render the workspace as a modal overlay
                            if (state.workspaceActive) {
                                return (
                                    <ImplementationWorkspace 
                                        key={`${step.id}-workspace`}
                                        step={step}
                                        persona={persona}
                                        onClose={() => handleCloseWorkspace(step.id)}
                                        isApiKeySet={isApiKeySet}
                                    />
                                );
                            }
                            
                            return (
                                <div key={step.id} className="mb-6 pl-10 relative">
                                    <div className="absolute -left-[9px] top-1 h-4 w-4 rounded-full bg-base-300 border-2 border-base-100"></div>
                                    <div className="bg-base-200/50 p-4 rounded-lg border border-base-300">
                                        <label htmlFor={step.id} className="flex items-start gap-3 cursor-pointer">
                                            <input type="checkbox" id={step.id} checked={step.completed} onChange={() => onStepToggle(step.id)} className="mt-1 h-5 w-5 rounded border-gray-500 text-brand-primary focus:ring-brand-primary shrink-0" />
                                            <div>
                                                <span className={`font-semibold text-lg ${step.completed ? 'line-through text-content/40' : 'text-content'}`}>{step.title}</span>
                                                <p className={`text-content/80 mt-1 ${step.completed ? 'text-content/50' : ''}`}>{step.description}</p>
                                            </div>
                                        </label>
                                        <div className="mt-3 pl-8">
                                            {!state.content && <button onClick={() => handleGetHint(step)} disabled={!isApiKeySet || state.loading} className="text-sm font-semibold text-neon-blue hover:text-neon-blue/80 disabled:text-content/50 disabled:cursor-not-allowed flex items-center gap-1">{state.loading ? 'Thinking...' : 'AI Hint'}</button>}
                                            {state.error && <p className="mt-2 text-neon-pink bg-neon-pink/10 p-2 rounded-md text-sm">{state.error}</p>}
                                            
                                            {state.loading && !state.content && <div className="mt-3 p-3 bg-base-300/70 rounded-lg border border-base-300/50 text-content/80 text-sm animate-pulse">The AI is generating a hint...</div>}
                                            
                                            {state.content && (
                                                <div className="mt-3 p-3 bg-base-300/70 rounded-lg border border-base-300/50 text-content/90 whitespace-pre-wrap text-sm relative">
                                                    {state.loading && <div className="absolute inset-0 bg-base-300/80 flex items-center justify-center rounded-lg z-10"><span className="flex items-center gap-2 text-content">Refining...</span></div>}
                                                    {state.content}
                                                    <div className="flex items-center gap-4 mt-3 pt-3 border-t border-base-300 flex-wrap">
                                                        <button onClick={() => handleCopy(step.id, state.content)} className="flex items-center gap-1.5 text-xs font-medium text-content/70 hover:text-content transition-colors">{copyStatus[step.id] ? 'Copied!' : 'Copy'}</button>
                                                        <button onClick={() => handleRefineHint(step)} disabled={!isApiKeySet || state.loading} className="flex items-center gap-1.5 text-xs font-medium text-neon-blue hover:text-neon-blue/80 disabled:text-content/50 disabled:cursor-not-allowed transition-colors">Refine with Context</button>
                                                        {state.isRefined && !state.suggestions && <button onClick={() => handleSuggestNextSteps(step)} disabled={!isApiKeySet || state.suggestionsLoading} className="flex items-center gap-1.5 text-xs font-medium text-neon-green hover:text-neon-green/80 disabled:text-content/50 transition-colors">{state.suggestionsLoading ? 'Thinking...' : 'Suggest Next Steps'}</button>}
                                                    </div>
                                                </div>
                                            )}

                                            {state.suggestionsLoading && <div className="mt-3 p-3 text-sm text-content/80 animate-pulse">The AI Concierge is finding relevant services...</div>}
                                            {state.suggestionsError && <p className="mt-2 text-neon-pink bg-neon-pink/10 p-2 rounded-md text-sm">{state.suggestionsError}</p>}
                                            
                                            {state.suggestions && (
                                                <div className="mt-4 space-y-3">
                                                    <p className="text-sm font-semibold text-neon-green">Concierge Suggestions:</p>
                                                    {state.suggestions.map(suggestion => (
                                                        <div key={suggestion.serviceName} className="bg-base-300/50 p-3 rounded-lg border border-base-300/80">
                                                            <h5 className="font-bold text-content">{suggestion.serviceName}</h5>
                                                            <p className="text-xs text-content/70 mb-2">{suggestion.description}</p>
                                                            <p className="text-sm text-content/90 mb-3">{suggestion.integrationRationale}</p>
                                                            <button onClick={() => handleGetImplementation(step, suggestion)} disabled={!isApiKeySet || state.implementationLoading} className="w-full text-center text-xs font-bold bg-brand-secondary/90 hover:bg-brand-secondary text-text-on-neon rounded p-2 transition-colors disabled:bg-base-300 disabled:text-content/50">
                                                                {state.implementationLoading ? 'Generating...' : 'Open Implementation Workspace'}
                                                            </button>
                                                            {state.implementationError && <p className="mt-2 text-neon-pink bg-neon-pink/10 p-2 rounded-md text-sm">{state.implementationError}</p>}
                                                        </div>
                                                    ))}
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            ))}
        </div>
    );
};

export default DevelopmentPlan;