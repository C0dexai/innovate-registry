import React from 'react';
import type { GitHubFile } from '../types';

interface FileTreeProps {
  files: GitHubFile[];
  onFileSelect: (path: string) => void;
  onDirSelect: (path: string) => void;
  onNavigateUp: () => void;
  currentPath: string;
  selectedFile: string | null;
}

const FileTree: React.FC<FileTreeProps> = ({ files, onFileSelect, onDirSelect, onNavigateUp, currentPath, selectedFile }) => {
    
    const FileIcon: React.FC<{ type: 'file' | 'dir' }> = ({ type }) => {
        const icon = type === 'dir' ? '📁' : '📄';
        return <span className="w-6 text-center">{icon}</span>;
    };

    return (
        <div className="bg-base-300/50 p-3 rounded-lg h-full flex flex-col">
            <div className="flex-shrink-0 mb-2 border-b border-base-300 pb-2">
                 <p className="text-sm font-bold text-content/80 px-2 truncate" title={currentPath || 'Root'}>
                    Current: /{currentPath}
                 </p>
            </div>
            <div className="flex-grow overflow-y-auto pr-1">
                <div className="space-y-1">
                    {currentPath && (
                        <button 
                            onClick={onNavigateUp}
                            className="w-full text-left flex items-center gap-2 p-2 rounded-md text-sm hover:bg-base-200/50 text-content/90"
                        >
                           <span className="w-6 text-center">↩️</span>
                           <span>..</span>
                        </button>
                    )}
                    {files.map(file => (
                        <button
                            key={file.sha}
                            onClick={() => (file.type === 'dir' ? onDirSelect(file.path) : onFileSelect(file.path))}
                            title={file.name}
                            className={`w-full text-left flex items-center gap-2 p-2 rounded-md text-sm transition-colors ${selectedFile === file.path ? 'bg-brand-primary text-text-on-neon' : 'text-content/90 hover:bg-base-200'}`}
                        >
                           <FileIcon type={file.type} />
                           <span className="truncate">{file.name}</span>
                        </button>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default FileTree;
