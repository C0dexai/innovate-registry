import React, { useState, useRef, useCallback, useEffect } from 'react';

interface GuideItem {
  id: string;
  title: string | React.ReactNode;
}

interface TwoColumnGuideProps<T extends GuideItem> {
  items: T[];
  renderContent: (item: T) => React.ReactNode;
}

const TwoColumnGuide = <T extends GuideItem>({ items, renderContent }: TwoColumnGuideProps<T>) => {
  const [selectedItemId, setSelectedItemId] = useState<string | null>(items.length > 0 ? items[0].id : null);
  const [panelWidth, setPanelWidth] = useState(320); // Initial width for the left panel
  const containerRef = useRef<HTMLDivElement>(null);
  const isResizing = useRef(false);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    isResizing.current = true;
    e.preventDefault();
  }, []);

  const handleMouseUp = useCallback(() => {
    isResizing.current = false;
  }, []);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (isResizing.current && containerRef.current) {
      const containerRect = containerRef.current.getBoundingClientRect();
      const newWidth = e.clientX - containerRect.left;
      // Set constraints for the panel width
      if (newWidth > 200 && newWidth < containerRect.width - 200) {
        setPanelWidth(newWidth);
      }
    }
  }, []);

  useEffect(() => {
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [handleMouseMove, handleMouseUp]);

  const selectedItem = items.find(item => item.id === selectedItemId);

  return (
    <div
      ref={containerRef}
      className="bg-base-200/50 backdrop-blur-sm rounded-xl border border-base-300 flex overflow-hidden min-h-[60vh]"
    >
      {/* Left Panel: Navigation */}
      <div
        className="flex-shrink-0 p-4 border-r border-base-300 flex flex-col gap-2 overflow-y-auto"
        style={{ width: `${panelWidth}px` }}
      >
        {items.map(item => (
          <button
            key={item.id}
            onClick={() => setSelectedItemId(item.id)}
            className={`w-full text-left p-3 rounded-lg transition-all duration-200 text-lg font-semibold ${
              selectedItemId === item.id
                ? 'bg-brand-secondary text-text-on-neon shadow-glow-pink'
                : 'text-content hover:bg-base-300/70'
            }`}
          >
            {item.title}
          </button>
        ))}
      </div>

      {/* Resize Handlebar */}
      <div
        className="w-2.5 flex-shrink-0 cursor-col-resize group"
        onMouseDown={handleMouseDown}
      >
        <div className="w-full h-full bg-neon-yellow/30 group-hover:bg-neon-yellow/80 transition-colors duration-200 relative">
             <div className="absolute inset-0 bg-neon-yellow shadow-glow-yellow opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        </div>
      </div>

      {/* Right Panel: Content */}
      <div className="flex-grow p-6 md:p-8 overflow-y-auto">
        {selectedItem ? renderContent(selectedItem) : (
            <div className="flex items-center justify-center h-full">
                <p className="text-content/70">Select an item from the left to view its details.</p>
            </div>
        )}
      </div>
    </div>
  );
};

export default TwoColumnGuide;
