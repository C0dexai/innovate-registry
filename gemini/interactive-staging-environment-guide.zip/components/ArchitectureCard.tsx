
import React from 'react';
import type { ArchitectureComponent } from '../types';
import { ICONS } from '../constants';

interface ArchitectureCardProps {
  component: ArchitectureComponent;
}

const ArchitectureCard: React.FC<ArchitectureCardProps> = ({ component }) => {
  return (
    <div className="bg-base-200/80 backdrop-blur-sm p-6 rounded-xl border border-base-300 flex flex-col gap-4 hover:border-neon-purple/50 hover:shadow-glow-purple transition-all duration-300 h-full">
      <div className="flex items-center gap-4">
        {ICONS[component.icon]}
        <h3 className="text-xl font-bold text-content">{component.title}</h3>
      </div>
      <div>
        <p className="font-semibold text-neon-blue mb-1">Purpose:</p>
        <p className="text-content/90">{component.purpose}</p>
      </div>
      <div>
        <p className="font-semibold text-neon-green mb-1">Configuration:</p>
        <p className="text-content/90">{component.configuration}</p>
      </div>
    </div>
  );
};

export default ArchitectureCard;
