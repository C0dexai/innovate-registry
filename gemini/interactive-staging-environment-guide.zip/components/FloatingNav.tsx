import React, { useState } from 'react';

const navLinks = [
  { name: 'AI Assistant', href: '#ai-qa' },
  { name: 'Architecture', href: '#architecture' },
  { name: 'SPA Instructions', href: '#spa-instructions' },
  { name: 'Testing Strategy', href: '#testing' },
];

const FloatingNav: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleNav = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <div className="relative flex flex-col items-center">
        {/* Navigation Menu */}
        <div
          className={`transition-all duration-300 ease-in-out ${
            isOpen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'
          }`}
        >
          <div className="bg-base-300/80 backdrop-blur-md border border-neon-purple/50 rounded-lg p-2 mb-4 w-48 shadow-lg shadow-neon-purple/20">
            <ul className="flex flex-col gap-1">
              {navLinks.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    onClick={() => setIsOpen(false)}
                    className="block w-full text-left p-2 rounded-md font-semibold text-content/90 hover:bg-brand-secondary hover:text-text-on-neon transition-colors duration-200"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Floating Action Button */}
        <button
          onClick={toggleNav}
          className="w-16 h-16 rounded-full bg-brand-secondary flex items-center justify-center text-text-on-neon shadow-glow-pink hover:shadow-lg hover:shadow-brand-secondary/50 focus:outline-none focus:ring-4 focus:ring-brand-secondary/50 transition-all duration-300"
          aria-label="Toggle Navigation Menu"
          aria-expanded={isOpen}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className={`h-7 w-7 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth={3}
          >
            <path strokeLinecap="round" strokeLinejoin="round" d="M5 15l7-7 7 7" />
          </svg>
        </button>
      </div>
    </div>
  );
};

export default FloatingNav;