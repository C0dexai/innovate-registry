import Dexie, { type Table } from 'dexie';
import type { ChatMessage } from './types';

// Define an interface for the database that extends Dexie.
// This gives us type-safety for our tables.
export interface StagingGuideDB extends Dexie {
  chatHistory: Table<ChatMessage>;
}

// 1. Create the Dexie instance.
const dbInstance = new Dexie('stagingGuideDB');

// 2. Declare the schema for the database.
dbInstance.version(1).stores({
  // Primary key is auto-incrementing 'id'. 'stepId' is an index for fast lookups.
  chatHistory: '++id, stepId, timestamp', 
});

// 3. Cast the instance to our type-safe interface and export it.
export const db = dbInstance as StagingGuideDB;

// Functions to interact with the DB
export const addChatMessage = async (message: Omit<ChatMessage, 'id' | 'timestamp'>) => {
  try {
    await db.chatHistory.add({
      ...message,
      timestamp: new Date(),
    });
  } catch (error) {
    console.error("Failed to add chat message to DB:", error);
  }
};

export const getChatHistoryForStep = (stepId: string) => {
    return db.chatHistory.where('stepId').equals(stepId).sortBy('timestamp');
}