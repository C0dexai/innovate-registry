export interface ArchitectureComponent {
  id: string;
  title: string;
  icon: string;
  purpose: string;
  configuration: string;
}

export interface InstructionDetail {
    title: string;
    details: string[];
}

export interface SpaInstruction {
    id:string;
    title:string;
    description: string;
    instructions: InstructionDetail[];
}

export interface TestItem {
    id: string;
    title: string;
    description: string;
    newlyAdded?: boolean;
}

export interface SimplePersona {
    name: string;
    role: string;
    persona: {
      description: string;
      tone: string;
    };
}

export interface AIPersona {
  name: string;
  role: string;
  persona: {
    description: string;
    tone: string;
  };
  superpowers: string[];
}

export interface DevelopmentStep {
  id: string;
  title: string;
  description: string;
  hintPrompt: string;
  completed: boolean;
}

export interface DevelopmentPhase {
  title: string;
  steps: DevelopmentStep[];
}

export interface NextStepSuggestion {
    serviceName: string;
    description: string;
    integrationRationale: string;
    actionPrompt: string;
}

export interface ChatMessage {
  id: number;
  stepId: string;
  role: 'USER' | 'AI' | 'SYSTEM';
  content: string;
  timestamp: Date;
}

export interface GitHubFile {
  name: string;
  path: string;
  sha: string;
  size: number;
  url: string;
  html_url: string;
  git_url: string;
  download_url: string | null;
  type: 'file' | 'dir';
  _links: {
    self: string;
    git: string;
    html: string;
  };
}

export interface GitHubContent {
    name: string;
    path: string;
    sha: string;
    size: number;
    url: string;
    html_url: string;
    git_url: string;
    download_url: string | null;
    type: 'file';
    content: string; // base64 encoded
    encoding: 'base64';
}
