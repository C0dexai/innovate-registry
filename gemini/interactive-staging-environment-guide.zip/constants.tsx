
import React from 'react';
import type { ArchitectureComponent, SpaInstruction, TestItem } from './types';

export const ICONS: { [key: string]: React.ReactNode } = {
  loadBalancer: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-neon-blue" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h8m-4 10V7M3 12h18" /></svg>,
  appServer: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-neon-green" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01" /></svg>,
  database: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-neon-purple" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4M4 7v5c0 2.21 3.582 4 8 4s8-1.79 8-4V7" /></svg>,
  cache: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-neon-green" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>,
  messageQueue: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-neon-pink" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>,
  cdn: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-neon-blue" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2h10a2 2 0 002-2v-1a2 2 0 012-2h1.945M7.707 4.293l.964-.964A1 1 0 0110.093 3h3.814a1 1 0 01.707.293l.964.964M12 11v6m-3-3h6" /></svg>,
  monitoring: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-neon-pink" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>,
  network: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-neon-purple" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12s-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.368a3 3 0 105.367 2.684 3 3 0 00-5.367 2.684z" /></svg>
};

export const initialArchitectureData: ArchitectureComponent[] = [
  { id: 'lb', title: 'Load Balancer (LB)', icon: 'loadBalancer', purpose: 'Distributes traffic across multiple application servers to ensure high availability and performance. In staging, it helps simulate realistic traffic patterns.', configuration: 'Mirror the production LB configuration, including routing rules, SSL/TLS certificates, and health checks.' },
  { id: 'appServer', title: 'Application Servers', icon: 'appServer', purpose: 'Hosts the SPA (Single Page Application) code and serves the application to users.', configuration: 'Use the same operating system, web server (e.g., Nginx, Apache, IIS), and runtime environment (e.g., Node.js, Python) as production. The SPA files (HTML, CSS, JavaScript) should be deployed to these servers.' },
  { id: 'database', title: 'Database Servers', icon: 'database', purpose: 'Stores the application\'s data.', configuration: 'Use a replica of the production database schema and, ideally, a sanitized copy of production data (for realistic testing). Ensure proper data masking and anonymization for sensitive information.' },
  { id: 'cache', title: 'Caching Servers', icon: 'cache', purpose: 'Caches frequently accessed data to improve performance.', configuration: 'Mirror the production caching configuration, including cache size, eviction policies, and data partitioning (e.g., Redis, Memcached).' },
  { id: 'messageQueue', title: 'Message Queues', icon: 'messageQueue', purpose: 'Enables asynchronous communication between different application components.', configuration: 'Match the production message queue configuration, including queue names, routing keys, and message formats (e.g., RabbitMQ, Kafka).' },
  { id: 'cdn', title: 'Content Delivery Network (CDN)', icon: 'cdn', purpose: 'Caches static assets (images, CSS, JavaScript) at geographically distributed locations to reduce latency.', configuration: 'Use a CDN to serve static assets in the staging environment, mirroring the production CDN setup.' },
  { id: 'monitoring', title: 'Monitoring & Logging', icon: 'monitoring', purpose: 'Collects metrics and logs to monitor application performance and identify errors.', configuration: 'Integrate with the same monitoring and logging tools as production (e.g., Prometheus, Grafana, ELK stack). This ensures consistent monitoring across all environments.' },
  { id: 'network', title: 'Network Configuration', icon: 'network', purpose: 'Defines the network topology and security rules for the staging environment.', configuration: 'Segregate the staging environment from production using firewalls and network segmentation. Use the same DNS records and routing rules, but with different hostnames (e.g., staging.example.com).' },
];

export const initialSpaInstructionData: SpaInstruction[] = [
    {
        id: 'build',
        title: 'A. Build Process',
        description: 'Instructions on how to build your SPA for a staging environment, focusing on framework-specific commands and environment variables.',
        instructions: [
            {
                title: 'React (Create React App)',
                details: [
                    '`npm run build`: Builds the application for production.',
                    '`CI=false npm run build`: Disables continuous integration checks.',
                    '`REACT_APP_API_URL=https://staging.api.example.com npm run build`: Sets environment variables for staging.'
                ]
            },
            {
                title: 'Angular (Angular CLI)',
                details: [
                    '`ng build --configuration=staging`: Builds using the "staging" configuration in `angular.json`.',
                    '`ng build --prod --base-href=/staging/`: Builds for production and sets the base URL.'
                ]
            },
            {
                title: 'Vue.js (Vue CLI)',
                details: [
                    '`vue-cli-service build --mode staging`: Builds using the "staging" mode in `vue.config.js`.',
                    '`vue-cli-service build --dest dist/staging`: Specifies the output directory.'
                ]
            }
        ]
    },
    {
        id: 'config',
        title: 'B. Configuration Management',
        description: 'Key configuration points to manage when deploying to a staging environment.',
        instructions: [
            {
                title: 'API Endpoints',
                details: ['Critically, point the SPA to the staging API endpoints, not production.']
            },
            {
                title: 'Feature Flags',
                details: ['Use feature flags to enable or disable specific features in staging for isolated testing.']
            },
            {
                title: 'Authentication & Authorization',
                details: ['Configure the SPA to use staging authentication services, which may involve different API keys or OAuth credentials.']
            },
        ]
    },
    {
        id: 'deploy',
        title: 'C. Deployment Process',
        description: 'Best practices for deploying your SPA to the staging environment.',
        instructions: [
            {
                title: 'Automated Deployment',
                details: ['Use a CI/CD pipeline (e.g., Jenkins, GitHub Actions) to automate deployment.']
            },
            {
                title: 'Deployment Strategy',
                details: ['Choose a strategy that minimizes downtime, such as blue-green or rolling deployments.']
            },
            {
                title: 'Rollback Plan',
                details: ['Always have a rollback plan in case the deployment fails.']
            },
             {
                title: 'Cache Busting',
                details: ['Implement a cache-busting mechanism (e.g., hashing filenames) to ensure users get the latest version.']
            },
        ]
    }
];

export const initialTestingData: TestItem[] = [
    {id: 'automated', title: 'Automated Tests', description: 'Run automated tests (unit, integration, end-to-end) in the staging environment against the deployed application.'},
    {id: 'uat', title: 'User Acceptance Testing (UAT)', description: 'Have actual users or stakeholders test the SPA in the staging environment before it is deployed to production.'},
    {id: 'performance', title: 'Performance Testing', description: 'Conduct performance tests (e.g., load testing) to identify any performance bottlenecks under realistic conditions.'},
    {id: 'security', title: 'Security Testing', description: 'Perform security testing (e.g., penetration testing, vulnerability scanning) to identify any security vulnerabilities.'},
];

export const fullContextForAI = `
I. Application Staging Environment Architecture
A good staging environment mimics your production environment as closely as possible.
- Load Balancer (LB): Distributes traffic across multiple application servers. Configuration should mirror production LB, including routing, SSL/TLS, and health checks.
- Application Servers: Hosts the SPA code. Use the same OS, web server (Nginx, Apache), and runtime (Node.js) as production.
- Database Servers: Stores data. Use a replica of the production schema and sanitized data. Ensure data masking for sensitive info.
- Caching Servers (Redis, Memcached): Caches data to improve performance. Mirror production cache size, eviction policies.
- Message Queues (RabbitMQ, Kafka): Enables async communication. Match production queue names, routing keys, message formats.
- CDN (Content Delivery Network): Caches static assets. Use a CDN in staging to mirror the production setup.
- Monitoring & Logging: Collects metrics and logs. Integrate with same tools as production (Prometheus, Grafana, ELK).
- Network Configuration: Defines network topology. Segregate staging from production with firewalls. Use different hostnames (e.g., staging.example.com).

II. Custom Instructions for the SPA
- A. Build Process:
  - React (Create React App): \`npm run build\`; \`CI=false npm run build\`; \`REACT_APP_API_URL=https://staging.api.example.com npm run build\`
  - Angular (Angular CLI): \`ng build --configuration=staging\`; \`ng build --prod --base-href=/staging/\`
  - Vue.js (Vue CLI): \`vue-cli-service build --mode staging\`; \`vue-cli-service build --dest dist/staging\`
- B. Configuration Management:
  - API Endpoints: Point the SPA to staging API endpoints.
  - Feature Flags: Use flags to test new features in isolation.
  - Authentication & Authorization: Use staging auth services and credentials.
- C. Deployment Process:
  - Automated Deployment: Use a CI/CD pipeline.
  - Deployment Strategy: Use blue-green or rolling deployments.
  - Rollback Plan: Have a plan in case of failure.
  - Cache Busting: Ensure users get the latest version of the SPA.

D. Testing:
- Automated Tests: Run unit, integration, and end-to-end tests in staging.
- User Acceptance Testing (UAT): Have users test the SPA in staging before production.
- Performance Testing: Identify performance bottlenecks.
- Security Testing: Identify security vulnerabilities.

This guide is interactive. You, the AI assistant, can answer questions about the above content, and you can also ADD new items to the 'architecture' and 'testing' sections if the user asks.
`;