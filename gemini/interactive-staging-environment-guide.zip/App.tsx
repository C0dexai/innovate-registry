

import React, { useState, useCallback } from 'react';
import ArchitectureCard from './components/ArchitectureCard';
import InteractiveAssistant from './components/GeminiQa';
import TwoColumnGuide from './components/TwoColumnGuide';
import FloatingNav from './components/FloatingNav';
import { initialArchitectureData, initialSpaInstructionData, initialTestingData } from './constants';
import type { InstructionDetail, TestItem, ArchitectureComponent, SpaInstruction, SimplePersona } from './types';

const SectionHeader: React.FC<{ title: string; subtitle: string }> = ({ title, subtitle }) => (
    <div className="text-center mb-12">
        <h2 className="text-4xl font-extrabold text-content tracking-tight sm:text-5xl">{title}</h2>
        <p className="mt-4 max-w-3xl mx-auto text-xl text-content/80">{subtitle}</p>
    </div>
);

// Define a default AI persona for the simplified app
const defaultPersona: SimplePersona = {
  name: 'Staging Guide Assistant',
  role: 'AI Expert',
  persona: {
    description: 'I am an AI assistant specializing in software deployment and staging environments. My goal is to provide clear, accurate, and helpful information based on the provided guide content.',
    tone: 'Helpful, clear, and professional',
  },
};

const App: React.FC = () => {
    const [architectureData, setArchitectureData] = useState<ArchitectureComponent[]>(initialArchitectureData);
    const [testingData, setTestingData] = useState<TestItem[]>(initialTestingData);
    const [newlyAddedId, setNewlyAddedId] = useState<string | null>(null);
    
    const handleAddItem = useCallback((section: string, item: any) => {
        if (section === 'architecture') {
            setArchitectureData(prev => [...prev, item as ArchitectureComponent]);
        } else if (section === 'testing') {
            setTestingData(prev => [...prev, item as TestItem]);
        }
        setNewlyAddedId(item.id);
        setTimeout(() => setNewlyAddedId(null), 2000);
    }, []);

    return (
        <div className="min-h-screen bg-base-100 font-sans">
             <div className="absolute inset-0 -z-10 h-full w-full bg-base-100 bg-[linear-gradient(to_right,#8080800a_1px,transparent_1px),linear-gradient(to_bottom,#8080800a_1px,transparent_1px)] bg-[size:14px_24px]"><div className="absolute left-0 right-0 top-0 -z-10 m-auto h-[310px] w-[310px] rounded-full bg-brand-primary/10 opacity-20 blur-[120px]"></div></div>

            <header className="py-8 text-center max-w-4xl mx-auto px-4">
                 <h1 className="text-5xl font-extrabold tracking-tight text-content sm:text-6xl md:text-7xl bg-clip-text text-transparent bg-gradient-to-r from-brand-primary to-brand-secondary">
                    Interactive Staging Environment Guide
                </h1>
                <p className="mt-6 text-xl text-content/80">
                    An interactive guide to application staging environments, SPA custom instructions, and deployment processes, with an AI assistant to answer your questions.
                </p>
            </header>

            <main className="container mx-auto px-4 py-8 max-w-7xl">

                {/* Gemini Q&A Section */}
                <section id="ai-qa" className="mb-20">
                    <InteractiveAssistant 
                        onAddItem={handleAddItem}
                        selectedPersona={defaultPersona}
                    />
                </section>

                {/* Staging Architecture Section */}
                <section id="architecture" className="mb-20">
                    <SectionHeader 
                        title="Staging Environment Architecture"
                        subtitle="A close mimic of production to catch issues early. Here are the key components."
                    />
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
                        {architectureData.map((component) => (
                           <div key={component.id} className={`${component.id === newlyAddedId ? 'newly-added rounded-xl' : ''}`}>
                                <ArchitectureCard component={component} />
                           </div>
                        ))}
                    </div>
                </section>

                {/* SPA Instructions Section */}
                <section id="spa-instructions" className="mb-20">
                    <SectionHeader 
                        title="SPA Custom Instructions"
                        subtitle="Framework-specific commands and configurations for your single-page application."
                    />
                    <TwoColumnGuide
                        items={initialSpaInstructionData}
                        renderContent={(item) => {
                            const instruction = item as SpaInstruction;
                            return (
                                <>
                                    <p className="mb-6 text-content/90">{instruction.description}</p>
                                    {instruction.instructions.map((instr: InstructionDetail) => (
                                        <div key={instr.title} className="mb-4 pl-4 border-l-4 border-base-300">
                                            <h4 className="font-semibold text-lg text-neon-blue">{instr.title}</h4>
                                            <ul className="list-none mt-2 space-y-2">
                                                {instr.details.map((detail, i) => (
                                                    <li key={i} className="text-content/80 font-mono text-sm bg-base-300/50 p-3 rounded-md">{detail}</li>
                                                ))}
                                            </ul>
                                        </div>
                                    ))}
                                </>
                            );
                        }}
                    />
                </section>

                {/* Testing Section */}
                <section id="testing" className="mb-20">
                     <SectionHeader 
                        title="Deployment & Testing Strategy"
                        subtitle="Essential testing practices to ensure a high-quality, stable release."
                    />
                     <TwoColumnGuide
                        items={testingData.map(item => ({...item, newlyAdded: item.id === newlyAddedId}))}
                        renderContent={(item) => {
                             const testItem = item as TestItem;
                             return <p className="text-content/90 text-lg leading-relaxed">{testItem.description}</p>
                        }}
                     />
                </section>
            </main>

            <FloatingNav />

            <footer className="text-center py-8 mt-12 text-content/60 border-t-2 border-neon-purple/30 shadow-[0_-4px_15px_-5px_rgba(157,0,255,0.2)]">
                <p>Built with React, Tailwind CSS, and the Gemini API.</p>
            </footer>
        </div>
    );
};

export default App;