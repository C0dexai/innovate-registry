
import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import { ImageStyle, ImageSize, AppRecord, Suggestion, Category } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // In a real app, you might want to handle this more gracefully,
  // but for this context, throwing an error is clear.
  throw new Error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const callApi = async (prompt: string, errorMessage: string): Promise<string> => {
    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                temperature: 0.2,
                topP: 0.8,
                topK: 10,
            }
        });
        const text = response.text;
        if (!text) {
            throw new Error('Received an empty response from the AI.');
        }
        // Clean up markdown code blocks if present
        return text.trim().replace(/^```(?:\w*\n)?([\s\S]*?)```$/, '$1').trim();
    } catch (error) {
        console.error(`Error with Gemini API for ${errorMessage}:`, error);
        throw new Error(`Failed to communicate with the AI service for ${errorMessage}.`);
    }
};

export const generateDescription = async (name: string): Promise<string> => {
  const prompt = `Generate a concise, one-sentence description for a data record named "${name}". The description should be suitable for a technical audience and explain the record's purpose.`;
  return callApi(prompt, 'description generation');
};

export const generateImage = async (prompt: string, style?: ImageStyle, size?: ImageSize): Promise<string> => {
    const fullPrompt = style ? `${prompt}, in a ${style.toLowerCase()} style.` : prompt;
    try {
        const response = await ai.models.generateImages({
            model: 'imagen-3.0-generate-002',
            prompt: fullPrompt,
            config: {
              numberOfImages: 1,
              outputMimeType: 'image/jpeg',
              aspectRatio: size || '1:1',
            },
        });
        if (!response.generatedImages || response.generatedImages.length === 0) {
            throw new Error('No images were generated.');
        }

        const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
        return `data:image/jpeg;base64,${base64ImageBytes}`;
    } catch(error) {
        console.error('Error generating image:', error);
        // Fallback to a placeholder image on error
        const placeholderBg = 'cccccc';
        const placeholderText = 'Image generation failed';
        return `https://via.placeholder.com/1024x576/${placeholderBg}/FFFFFF?text=${encodeURIComponent(placeholderText)}`;
    }
};

export const generateRecordSuggestions = async (record: AppRecord): Promise<Suggestion> => {
    const prompt = `Analyze the following data record and suggest an improved name, a more detailed and professional description, and the most appropriate category.
    Current Record:
    - Name: ${record.name}
    - Description: ${record.description}
    - Category: ${record.category}

    Provide your response as a JSON object. The category must be one of "USER", "AI", or "SYSTEM".`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: 'application/json',
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    name: { type: Type.STRING },
                    description: { type: Type.STRING },
                    category: { type: Type.STRING, enum: Object.values(Category) },
                },
                required: ['name', 'description', 'category'],
            },
        },
    });

    const jsonText = response.text.trim();
    return JSON.parse(jsonText) as Suggestion;
};

export const generateYamlPlan = (topic: string): Promise<string> => {
    const prompt = `Create a detailed, structured project plan in YAML format for a new software project with the topic: "${topic}".
    The YAML should include keys like 'project_name', 'objective', 'milestones' (with 'name', 'tasks', 'due_date'), and 'team_roles'.
    Be creative and thorough.`;
    return callApi(prompt, 'YAML plan generation');
};

export const generateJsonRequirements = (yamlPlan: string): Promise<string> => {
    const prompt = `Based on the following YAML project plan, generate a detailed set of technical requirements in JSON format.
    The JSON should be an array of objects, where each object has 'id', 'component', 'requirement_description', and 'priority' (High, Medium, Low).
    YAML Plan:
    ---
    ${yamlPlan}
    ---`;
    return callApi(prompt, 'JSON requirements generation');
};

export const generateMarkdownSummary = (jsonRequirements: string): Promise<string> => {
    const prompt = `Based on the following JSON of technical requirements, write a concise but comprehensive project summary in GitHub-flavored Markdown.
    The summary should include a title, a brief overview, a section for key features (as a bulleted list), and a table of requirements.
    JSON Requirements:
    ---
    ${jsonRequirements}
    ---`;
    return callApi(prompt, 'Markdown summary generation');
};

export const generateHtmlPreview = (topic: string, yamlPlan: string, jsonRequirements: string, mdSummary: string): Promise<string> => {
    const prompt = `Create a single, self-contained, visually appealing HTML file that acts as a project dashboard for the project: "${topic}".
    Incorporate the following data into the HTML:
    1. A project overview section based on the Markdown summary.
    2. A section displaying key milestones from the YAML plan.
    3. A section displaying the technical requirements from the JSON data, perhaps in a styled table.

    Use inline or embedded CSS for styling. Make it professional, modern, and easy to read. Use a dark theme. Do not include any \`\`\`html or markdown specifiers in your response, just return the raw HTML code.

    ---
    Markdown Summary:
    ${mdSummary}
    ---
    YAML Plan:
    ${yamlPlan}
    ---
    JSON Requirements:
    ${jsonRequirements}
    ---
    `;
    return callApi(prompt, 'HTML preview generation');
};

export const generateLaunchCopy = async (hashtags: string, punchyStat: string): Promise<{ linkedin: string, x: string }> => {
    const prompt = `You are "Dude", a hip and energetic marketing copywriter.
    Your task is to craft compelling launch copy for a new AI feature.
    - Incorporate this key statistic: "${punchyStat}"
    - Include these hashtags: ${hashtags}

    Write one post for LinkedIn (professional but engaging) and one for X (Twitter) (short, punchy, and exciting).
    Provide your response as a JSON object.`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: 'application/json',
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    linkedin: { type: Type.STRING },
                    x: { type: Type.STRING },
                },
                required: ['linkedin', 'x'],
            },
        },
    });

    const jsonText = response.text.trim();
    return JSON.parse(jsonText) as { linkedin: string, x: string };
};
