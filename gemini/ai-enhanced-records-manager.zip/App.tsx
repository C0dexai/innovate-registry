import React from 'react';
import Header from './components/Header';
import RecordsPage from './components/RecordsPage';

function App() {
  return (
    <div className="min-h-screen text-[--text-color]">
      <Header />
      <main id="app" className="p-4 sm:p-6 max-w-7xl mx-auto">
        <RecordsPage />
      </main>
    </div>
  );
}

export default App;
