import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-gradient-to-b from-black/50 to-transparent text-white shadow-md sticky top-0 z-40 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-center items-center">
        <h1 className="text-2xl sm:text-3xl font-bold tracking-widest text-glow-primary text-[--primary-color]">
          AI-Enhanced Records Manager
        </h1>
      </div>
    </header>
  );
};

export default Header;
