import React, { useState } from 'react';
import { clearAllRecordsDB, addRecordDB } from '../services/dbService';
import { initialRecordsForSeed } from '../services/initialData';

const DevToolsPage: React.FC = () => {
    const [message, setMessage] = useState('');

    const resetMessage = () => {
        setTimeout(() => setMessage(''), 5000);
    }

    const handleClearRecords = async () => {
        if(window.confirm('Are you sure you want to delete ALL records? This cannot be undone.')) {
            try {
                await clearAllRecordsDB();
                setMessage('All records have been cleared. Refresh the page to see changes.');
                resetMessage();
            } catch (error) {
                setMessage('Error clearing records. See console for details.');
                console.error(error);
                resetMessage();
            }
        }
    }
    
    const handleSeedData = async () => {
        if(window.confirm('This will delete all current records and re-seed with initial data. Continue?')) {
            try {
                await clearAllRecordsDB();
                for (const record of initialRecordsForSeed) {
                    await addRecordDB(record);
                }
                setMessage('Database has been cleared and re-seeded. Refresh the page to see changes.');
                resetMessage();
            } catch(error) {
                setMessage('Error seeding data. See console for details.');
                console.error(error);
                resetMessage();
            }
        }
    }

    const getMessageColor = () => {
        return message.startsWith('Error') ? 'bg-red-900/50 text-red-200' : 'bg-green-900/50 text-green-200';
    }

    return (
        <div className="bg-[--card-bg] backdrop-blur-md border border-[--card-border-color] p-6 rounded-lg shadow-lg max-w-2xl mx-auto">
            <h2 className="text-2xl font-bold text-glow-primary text-[--primary-color] mb-6 border-b border-[--primary-color]/30 pb-3">
                Developer Tools
            </h2>
            <div className="space-y-6">
                <p className="text-sm text-gray-400">Use these tools to manage the application's local state. Actions here are destructive and cannot be undone.</p>
                
                {message && (
                    <div className={`p-3 rounded-md text-sm ${getMessageColor()} transition-opacity duration-300`}>
                        {message}
                    </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <button onClick={handleSeedData} className="px-4 py-2 font-semibold text-black bg-blue-500 rounded-md hover:bg-blue-600 transition shadow-[0_0_8px_var(--neon-blue)]">
                        Reset & Seed Data
                    </button>
                    <button onClick={handleClearRecords} className="px-4 py-2 font-semibold text-black bg-red-500 rounded-md hover:bg-red-600 transition shadow-[0_0_8px_#f00]">
                        Clear All Records
                    </button>
                </div>

                <div className="bg-black/20 p-4 rounded-md text-sm text-gray-400 border-l-4 border-[--neon-cyan]">
                    <p><strong>Note:</strong> Most changes will require a page refresh to be fully reflected in the UI, as the data is loaded on application startup.</p>
                </div>
            </div>
        </div>
    );
}

export default DevToolsPage;