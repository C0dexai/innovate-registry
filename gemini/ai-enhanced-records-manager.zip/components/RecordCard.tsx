import React from 'react';
import { AppRecord, Category } from '../types';
import { PencilIcon, TrashIcon, RefreshIcon } from './icons';

interface RecordCardProps {
  record: AppRecord;
  onEdit: (record: AppRecord) => void;
  onDelete: (id: string) => void;
  onImageClick: (url: string) => void;
  onRegenerateImage: (record: AppRecord) => void;
  isRegenerating: boolean;
}

const categoryStyles: { [key in Category]: string } = {
  [Category.USER]: 'bg-blue-500/30 text-blue-300 ring-1 ring-blue-500',
  [Category.AI]: 'bg-purple-500/30 text-purple-300 ring-1 ring-purple-500',
  [Category.SYSTEM]: 'bg-green-500/30 text-green-300 ring-1 ring-green-500',
};

const RecordCard: React.FC<RecordCardProps> = ({ record, onEdit, onDelete, onImageClick, onRegenerateImage, isRegenerating }) => {
  return (
    <div className="bg-[--card-bg] backdrop-blur-md rounded-lg shadow-lg hover:shadow-[0_0_20px_var(--neon-cyan)] transition-shadow duration-300 flex flex-col border border-[--card-border-color] hover:border-[--neon-cyan]">
      {record.imageUrl && (
          <button 
            onClick={() => onImageClick(record.imageUrl!)} 
            className="w-full aspect-video block overflow-hidden rounded-t-lg group"
            aria-label={`View image for ${record.name}`}
          >
            <img 
              src={record.imageUrl} 
              alt={`Generated visual for ${record.name}`}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
            />
          </button>
      )}
      <div className="p-5 flex-grow flex flex-col">
        <div className="flex-grow">
          <span className={`inline-block px-2.5 py-0.5 text-xs font-semibold rounded-full ${categoryStyles[record.category]}`}>
            {record.category}
          </span>
          <h3 className="mt-3 mb-2 text-lg font-bold text-gray-100">
            {record.name}
          </h3>
          <p className="text-gray-300 text-sm leading-relaxed">
            {record.description || 'No description provided.'}
          </p>
        </div>

        <div className="mt-6 pt-4 border-t border-gray-700/50 flex justify-end items-center gap-3">
          {record.imageUrl && (
            <button
              onClick={() => onRegenerateImage(record)}
              disabled={isRegenerating}
              className="flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-cyan-300 bg-cyan-900/40 rounded-md hover:bg-cyan-900/60 transition-colors disabled:opacity-50 disabled:cursor-wait"
              aria-label={`Regenerate image for ${record.name}`}
            >
              <RefreshIcon className={`w-4 h-4 ${isRegenerating ? 'animate-spin' : ''}`} />
              {isRegenerating ? 'Regenerating...' : 'Regenerate Image'}
            </button>
          )}
          <button
            onClick={() => onEdit(record)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-gray-300 bg-gray-700 rounded-md hover:bg-gray-600 transition-colors"
            aria-label={`Edit ${record.name}`}
          >
            <PencilIcon className="w-4 h-4" />
            Edit
          </button>
          <button
            onClick={() => onDelete(record.id)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-red-400 bg-red-900/40 rounded-md hover:bg-red-900/60 transition-colors"
            aria-label={`Delete ${record.name}`}
          >
            <TrashIcon className="w-4 h-4" />
            Delete
          </button>
        </div>
      </div>
    </div>
  );
};

export default RecordCard;
