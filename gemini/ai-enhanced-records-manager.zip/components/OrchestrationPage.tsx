import React, { useState, useMemo } from 'react';
import { AppRecord } from '../types';
import { useRecords } from '../hooks/useRecords';
import * as workflowService from '../services/workflowService';
import { FolderIcon, SparklesIcon } from './icons';
import InferencePreview from './InferencePreview';

const OrchestrationPage: React.FC = () => {
    const { records, updateRecord, isLoading } = useRecords();
    const [selectedRecord, setSelectedRecord] = useState<AppRecord | null>(null);

    const stagedRecords = useMemo(() => {
        return records
            .filter(r => r.status === 'staged' || r.status === 'processing')
            .sort((a, b) => (b.id > a.id ? 1 : -1));
    }, [records]);

    const handlePrepareWorkflow = async (record: AppRecord) => {
        setSelectedRecord({ ...record, status: 'processing' });
        const { id, ...baseData } = record;
        await updateRecord(record.id, { ...baseData, status: 'processing' });
        
        try {
            const { fileIds, htmlPreview } = await workflowService.runProjectSpecAndPreview(record.name);
            const updatedRecordData = {
                status: 'staged' as const,
                generatedFileIds: fileIds,
                generatedHtmlPreview: htmlPreview,
            };
            await updateRecord(record.id, { ...baseData, ...updatedRecordData });
            setSelectedRecord({ ...record, ...updatedRecordData });
        } catch (error) {
            console.error("Workflow preparation failed:", error);
            // Revert status on failure
            await updateRecord(record.id, { ...baseData, status: 'staged' });
            setSelectedRecord({ ...record, status: 'staged' });
        }
    };

    const handleFinalize = async (record: AppRecord) => {
        const { id, ...baseData } = record;
        await updateRecord(record.id, { ...baseData, status: 'complete' });
        setSelectedRecord(null);
    };

    const renderRecordList = () => {
        if (isLoading) return <div className="text-center p-4">Loading...</div>;
        if (stagedRecords.length === 0) {
            return (
                <div className="text-center p-6 text-gray-400">
                    <p>No records staged for orchestration.</p>
                    <p className="text-sm mt-1">Use "AI Suggest" then "Apply & Stage" on the Records page to add records here.</p>
                </div>
            );
        }
        return (
            <ul className="space-y-2">
                {stagedRecords.map(record => (
                    <li key={record.id}>
                        <button
                            onClick={() => setSelectedRecord(record)}
                            disabled={record.status === 'processing'}
                            className={`w-full text-left p-3 rounded-md transition-colors border ${
                                selectedRecord?.id === record.id 
                                ? 'bg-[--primary-color]/20 text-[--primary-color] border-[--primary-color]' 
                                : 'bg-gray-800/50 hover:bg-gray-700/50 border-gray-700'
                            } disabled:opacity-50 disabled:cursor-not-allowed`}
                        >
                            <p className="font-semibold text-gray-100">{record.name}</p>
                            <p className="text-xs text-gray-400">{record.status === 'processing' ? 'Processing...' : 'Ready to preview'}</p>
                        </button>
                    </li>
                ))}
            </ul>
        );
    }
    
    return (
        <div className="bg-[--card-bg-opaque] p-4 sm:p-6 rounded-lg shadow-lg max-w-full mx-auto min-h-[80vh]">
            <h2 className="text-2xl font-bold text-glow-primary text-[--primary-color] mb-4 border-b border-[--primary-color]/30 pb-3">
                Orchestration Workbench
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-[70vh]">
                <div className="md:col-span-1 border-r border-gray-700 pr-4 overflow-y-auto">
                    <h3 className="text-lg font-semibold text-gray-300 mb-3">Staged Records</h3>
                    {renderRecordList()}
                </div>
                <div className="md:col-span-2 overflow-hidden">
                    {!selectedRecord && (
                        <div className="flex items-center justify-center h-full text-gray-400 flex-col gap-4 text-center">
                            <FolderIcon className="w-16 h-16 text-gray-600"/>
                            <p>Select a staged record to view its workflow preview.</p>
                        </div>
                    )}
                    {selectedRecord && !selectedRecord.generatedFileIds && (
                         <div className="flex items-center justify-center h-full text-gray-400 flex-col gap-4 text-center">
                            <div className="text-center">
                               <h3 className="text-lg font-bold text-gray-200 mb-2">{selectedRecord.name}</h3>
                               <p className="mb-4">This record is ready for workflow preparation.</p>
                               <button 
                                 onClick={() => handlePrepareWorkflow(selectedRecord)}
                                 disabled={selectedRecord.status === 'processing'}
                                 className="flex items-center justify-center gap-2 px-4 py-2 text-sm font-semibold text-black bg-[--primary-color] rounded-md shadow-[0_0_10px_var(--primary-color)] hover:bg-[--primary-color-hover] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[--primary-color] transition disabled:opacity-70 disabled:cursor-wait"
                               >
                                  {selectedRecord.status === 'processing' ? 'Processing...' : <><SparklesIcon className="w-4 h-4"/> Prepare Workflow</>}
                               </button>
                            </div>
                        </div>
                    )}
                    {selectedRecord && selectedRecord.generatedFileIds && (
                       <InferencePreview
                            record={selectedRecord}
                            onFinalize={handleFinalize}
                       />
                    )}
                </div>
            </div>
        </div>
    );
};

export default OrchestrationPage;