
import React, { useState, createContext, useContext } from 'react';

interface TabsContextType {
  activeIndex: number;
  setActiveIndex: (index: number) => void;
}

const TabsContext = createContext<TabsContextType | null>(null);

export const Tabs: React.FC<{ children: React.ReactNode[] }> = ({ children }) => {
  const [activeIndex, setActiveIndex] = useState(0);

  const tabs = React.Children.toArray(children).filter(child => React.isValidElement(child) && child.type === Tab) as React.ReactElement<TabProps>[];

  return (
    <TabsContext.Provider value={{ activeIndex, setActiveIndex }}>
      <div>
        <div className="border-b border-dark-base-300/50">
          <nav className="-mb-px flex space-x-4" aria-label="Tabs">
            {tabs.map((tab, index) => (
              <button
                key={index}
                onClick={() => setActiveIndex(index)}
                className={`
                  ${activeIndex === index
                    ? 'border-brand-secondary text-brand-secondary'
                    : 'border-transparent text-dark-base-content/60 hover:text-dark-base-content/90 hover:border-dark-base-300'
                  }
                  whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 transition-colors
                `}
              >
                {tab.props.icon}
                <span>{tab.props.label}</span>
              </button>
            ))}
          </nav>
        </div>
        <div>{tabs[activeIndex]}</div>
      </div>
    </TabsContext.Provider>
  );
};

interface TabProps {
  label: string;
  children: React.ReactNode;
  icon?: React.ReactNode;
}

export const Tab: React.FC<TabProps> = ({ children }) => {
  return <div className="py-4">{children}</div>;
};