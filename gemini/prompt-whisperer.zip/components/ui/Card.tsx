import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  title?: string;
}

export const Card: React.FC<CardProps> = ({ children, className = '', title }) => {
  return (
    <div className={`bg-black/50 border border-fuchsia-500/20 rounded-lg shadow-lg shadow-fuchsia-900/10 backdrop-blur-sm ${className}`}>
      {title && (
        <div className="px-4 py-3 border-b border-fuchsia-500/20">
          <h3 className="text-lg font-semibold text-fuchsia-400 tracking-wider">{title}</h3>
        </div>
      )}
      <div className="p-4">{children}</div>
    </div>
  );
};