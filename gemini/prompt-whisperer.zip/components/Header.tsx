import React from 'react';
import { ICONS } from '../constants';

interface HeaderProps {}

const Header: React.FC<HeaderProps> = () => {
  return (
    <header className="flex items-center justify-between p-3 border-b border-fuchsia-500/20 bg-black/70 backdrop-blur-md sticky top-0 z-20 flex-shrink-0">
      <div className="flex items-center gap-4">
        <h1 className="text-xl font-bold text-fuchsia-400 tracking-widest">Prompt Whisperer</h1>
      </div>
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2 text-sm text-gray-400">
          {React.cloneElement(ICONS.GIT, { className: 'h-5 w-5' })}
          <span>main</span>
        </div>
      </div>
    </header>
  );
};

export default Header;