import type { GitHubFile } from '../types';

const API_BASE_URL = 'https://api.github.com';

const commonHeaders = (token: string) => ({
    'Authorization': `Bearer ${token}`,
    'Accept': 'application/vnd.github.v3+json',
    'X-GitHub-Api-Version': '2022-11-28'
});

export const getRepoContents = async (owner: string, repo: string, path: string, token: string): Promise<GitHubFile[]> => {
    const url = `${API_BASE_URL}/repos/${owner}/${repo}/contents/${path}`;
    const response = await fetch(url, { headers: commonHeaders(token) });

    if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`GitHub API Error: ${errorData.message || response.statusText}`);
    }

    const data = await response.json();
    return Array.isArray(data) ? data : [data];
};


export const getFileContent = async (owner: string, repo: string, path: string, token: string): Promise<GitHubFile> => {
    const url = `${API_BASE_URL}/repos/${owner}/${repo}/contents/${path}`;
    const response = await fetch(url, { headers: commonHeaders(token) });
    
    if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`GitHub API Error fetching file: ${errorData.message || response.statusText}`);
    }

    const fileData: GitHubFile = await response.json();

    if (fileData.content) {
        try {
            // Decode from base64
            fileData.content = atob(fileData.content);
        } catch (e) {
            console.error("Base64 decoding error:", e);
            throw new Error("Failed to decode file content from base64.");
        }
    }
    
    return fileData;
};


export const updateFile = async (
    owner: string, 
    repo: string, 
    path: string, 
    token: string, 
    content: string, 
    sha: string, 
    commitMessage: string
): Promise<any> => {
    const url = `${API_BASE_URL}/repos/${owner}/${repo}/contents/${path}`;
    
    // Encode content to base64
    const encodedContent = btoa(content);

    const body = JSON.stringify({
        message: commitMessage,
        content: encodedContent,
        sha: sha
    });

    const response = await fetch(url, {
        method: 'PUT',
        headers: {
            ...commonHeaders(token),
            'Content-Type': 'application/json'
        },
        body: body
    });

    if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`GitHub API Error updating file: ${errorData.message || response.statusText}`);
    }

    return await response.json();
};
