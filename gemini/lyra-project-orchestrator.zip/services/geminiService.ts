
import { GoogleGenAI, Type } from "@google/genai";
import { TechStackSuggestion, WorkflowStep } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export interface WorkflowParseResult {
    projectName: string;
    vision: string;
    userStories: string[];
    architectureNotes: string;
    workflowSteps: WorkflowStep[];
}

const USER_STORIES_SCHEMA = {
    type: Type.OBJECT,
    properties: {
        stories: {
            type: Type.ARRAY,
            items: {
                type: Type.STRING
            }
        },
        suggestions: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "Exactly 3 next-step suggestions. Two for refinement, one starting with '[PROCEED]'."
        }
    },
    required: ["stories", "suggestions"]
};

const TECH_STACK_SCHEMA = {
     type: Type.OBJECT,
    properties: {
        stack: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    category: { type: Type.STRING, description: 'e.g., Frontend, Backend, Database' },
                    name: { type: Type.STRING, description: 'e.g., React, Node.js, PostgreSQL' },
                    justification: { type: Type.STRING, description: 'Reason for the suggestion.' }
                },
                required: ['category', 'name', 'justification']
            }
        },
        suggestions: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "Exactly 3 next-step suggestions. Two for refinement, one starting with '[PROCEED]'."
        }
    },
    required: ["stack", "suggestions"]
};

const WORKFLOW_SCHEMA = {
    type: Type.OBJECT,
    properties: {
        steps: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    id: { type: Type.STRING },
                    name: { type: Type.STRING },
                    agent: { type: Type.STRING },
                    verb: { type: Type.STRING },
                    input: { type: Type.STRING },
                    output: { type: Type.STRING },
                    mission: { type: Type.STRING },
                },
                required: ["id", "name", "agent", "verb", "input", "output", "mission"]
            }
        },
        suggestions: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "Exactly 3 next-step suggestions. Two for refinement, one starting with '[PROCEED]' to advance to the next project phase."
        }
    },
    required: ["steps", "suggestions"]
};


export const generateUserStories = async (projectVision: string): Promise<{stories: string[], suggestions: string[]}> => {
    if (!projectVision) return { stories: [], suggestions: [] };
    
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Based on the following project vision, generate 5-7 user stories in the format 'As a [user type], I want [goal] so that [benefit].'.
            
After generating the stories, provide exactly 3 suggestions for the user's next action. 
- Two suggestions should be for refining or expanding upon the user stories. 
- The third suggestion must be to continue to the next phase, and must start with the exact text '[PROCEED]'. For example: '[PROCEED] Use these stories to create the technical blueprint.'

Vision: ${projectVision}`,
            config: {
                responseMimeType: "application/json",
                responseSchema: USER_STORIES_SCHEMA,
            }
        });

        const jsonStr = response.text.trim();
        const parsed = JSON.parse(jsonStr);
        return { stories: parsed.stories || [], suggestions: parsed.suggestions || [] };

    } catch (error) {
        console.error("Error generating user stories:", error);
        throw new Error("Failed to generate user stories from AI.");
    }
};

export const refineUserStories = async (vision: string, stories: string[], instruction: string): Promise<{stories: string[], suggestions: string[]}> => {
     if (!instruction) return { stories, suggestions: [] };
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Given the project vision and current user stories, refine them based on the instruction.
Then, provide exactly 3 new suggestions for the next action (2 for refinement, 1 starting with '[PROCEED]').

Vision: ${vision}
Current Stories: ${stories.join(', ')}
Instruction: "${instruction}"`,
            config: {
                responseMimeType: "application/json",
                responseSchema: USER_STORIES_SCHEMA
            }
        });
        const jsonStr = response.text.trim();
        const parsed = JSON.parse(jsonStr);
        return { stories: parsed.stories || [], suggestions: parsed.suggestions || [] };
    } catch (error) {
        console.error("Error refining user stories:", error);
        throw new Error("Failed to refine user stories with AI.");
    }
};


export const generateTechStack = async (vision: string, notes: string): Promise<{stack: TechStackSuggestion[], suggestions: string[]}> => {
    if (!vision && !notes) return { stack: [], suggestions: [] };

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Based on the project vision and architecture notes, suggest a technology stack (frontend, backend, etc.).
Provide a brief justification for each choice.

After suggesting the stack, provide exactly 3 suggestions for the user's next action. 
- Two suggestions should be for refining or expanding upon the architecture.
- The third suggestion must be to continue to the next phase, and must start with the exact text '[PROCEED]'. For example: '[PROCEED] Define the project execution workflow.'

Vision: ${vision}
Architecture Notes: ${notes}`,
            config: {
                responseMimeType: "application/json",
                responseSchema: TECH_STACK_SCHEMA,
            }
        });
        
        const jsonStr = response.text.trim();
        const parsed = JSON.parse(jsonStr);
        return { stack: parsed.stack || [], suggestions: parsed.suggestions || [] };

    } catch (error) {
        console.error("Error generating tech stack:", error);
        throw new Error("Failed to generate tech stack from AI.");
    }
};

export const refineWorkflow = async (currentSteps: WorkflowStep[], instruction: string): Promise<{steps: WorkflowStep[], suggestions: string[]}> => {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Given the current workflow steps, refine them based on the provided instruction. If the instruction is empty or generic, analyze the current workflow and suggest general improvements (like adding a QA step, clarifying an output, etc).
The returned 'steps' should be the complete, updated list of workflow steps.
Also provide 3 new suggestions for the next action (2 for refinement, 1 starting with '[PROCEED]').

Current Workflow: ${JSON.stringify(currentSteps, null, 2)}

Instruction: "${instruction}"
`,
            config: {
                responseMimeType: "application/json",
                responseSchema: WORKFLOW_SCHEMA
            }
        });
        const jsonStr = response.text.trim();
        const parsed = JSON.parse(jsonStr);
        return { steps: parsed.steps || [], suggestions: parsed.suggestions || [] };
    } catch (error) {
        console.error("Error refining workflow:", error);
        throw new Error("Failed to refine workflow with AI.");
    }
};

export const processProjectDocument = async (documentContent: string): Promise<WorkflowParseResult> => {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Analyze the following project plan document. Based on its content, please populate the following JSON structure.

- 'projectName': Extract a suitable project name. It's likely in the title or overview.
- 'vision': Create a concise project vision statement from the 'Overview' or 'Objective' sections.
- 'userStories': Generate 3-5 high-level user stories based on the overall goal of the project described in the 'Objective' section. Frame them as "As a [role], I want [action] so that [benefit]".
- 'architectureNotes': Summarize the technical requirements, components, APIs, and execution deliverables into technical notes.
- 'workflowSteps': Based on the 'Execution Deliverables' and 'Execution Path' sections, define a sequence of workflow steps. Each step should have an id, name, an agent from the 'AI Family Summary and Roles' section, a verb (e.g., SPECIFY, DESIGN, IMPLEMENT, DEPLOY, MONITOR), input, output, and a mission. The mission should be a creative, second-person directive for the assigned agent.

Example mission for an agent named 'LYRA' with role 'Master Orchestrator':
"You are **LYRA**, Master Orchestrator. Mission: Draft the unified orchestration specification based on the project plan. Your output will be \`orchestration_spec.yml\`. This is the foundational document for all other agents. HANDOVER to Sophia."

Project Document:
---
${documentContent}
---
`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        projectName: { type: Type.STRING },
                        vision: { type: Type.STRING },
                        userStories: {
                            type: Type.ARRAY,
                            items: { type: Type.STRING }
                        },
                        architectureNotes: { type: Type.STRING },
                        workflowSteps: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    id: { type: Type.STRING },
                                    name: { type: Type.STRING },
                                    agent: { type: Type.STRING },
                                    verb: { type: Type.STRING },
                                    input: { type: Type.STRING },
                                    output: { type: Type.STRING },
                                    mission: { type: Type.STRING },
                                },
                                required: ["id", "name", "agent", "verb", "input", "output", "mission"]
                            }
                        }
                    },
                    required: ["projectName", "vision", "userStories", "architectureNotes", "workflowSteps"]
                }
            }
        });

        const jsonStr = response.text.trim();
        const parsed = JSON.parse(jsonStr);
        return parsed;

    } catch (error) {
        console.error("Error processing project document:", error);
        throw new Error("Failed to process document with AI. The document might be malformed or the service is unavailable.");
    }
};