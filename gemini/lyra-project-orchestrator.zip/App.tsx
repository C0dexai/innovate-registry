import React, { useState, useCallback, useRef } from 'react';
import { PhaseKey, ProjectData, OvertureData, BlueprintData, GenericPhaseData, WorkflowData, CodeData } from './types';
import { PHASES } from './constants';
import Sidebar from './components/Sidebar';
import OvertureView from './components/phases/OvertureView';
import BlueprintView from './components/phases/BlueprintView';
import PhaseView from './components/PhaseView';
import WorkflowView from './components/phases/WorkflowView';
import CodeView from './components/phases/CodeView';
import ImportWorkflowModal from './components/ImportWorkflowModal';
import { processProjectDocument } from './services/geminiService';
import ScrollToBottomButton from './components/ScrollToBottomButton';


const initialProjectData: ProjectData = {
  projectName: 'My New Composition',
  [PhaseKey.Overture]: { vision: '', userStories: [], suggestions: [] },
  [PhaseKey.Blueprint]: { architectureNotes: '', techStackSuggestions: [], suggestions: [] },
  [PhaseKey.Workflow]: { steps: [], suggestions: [] },
  [PhaseKey.Code]: { githubToken: '', repoOwner: '', repoName: '', repoUrl: '' },
  [PhaseKey.Refinement]: { notes: '' },
  [PhaseKey.Debut]: { notes: '' },
  [PhaseKey.Evolving]: { notes: '' },
};

const generateMarkdown = (projectData: ProjectData): string => {
  let markdown = `# ${projectData.projectName || 'Untitled Project'}\n\n`;

  (Object.keys(PHASES) as PhaseKey[]).forEach(key => {
    const phaseConfig = PHASES[key];
    
    if(key === PhaseKey.Workflow && projectData.WORKFLOW.steps.length === 0) return;

    markdown += `---\n\n`;
    markdown += `## ${phaseConfig.title}: ${phaseConfig.subtitle}\n\n`;

    switch (key) {
      case PhaseKey.Overture: {
        const phaseData = projectData[key];
        markdown += `### Vision\n`;
        markdown += `> ${phaseData.vision?.trim() || 'No vision defined.'}\n\n`;
        markdown += `### User Stories\n`;
        if (phaseData.userStories && phaseData.userStories.length > 0) {
          markdown += phaseData.userStories.map(story => `- ${story}`).join('\n') + '\n\n';
        } else {
          markdown += `No user stories generated.\n\n`;
        }
        break;
      }
      case PhaseKey.Blueprint: {
        const phaseData = projectData[key];
        markdown += `### Architecture & Design Notes\n`;
        markdown += `> ${phaseData.architectureNotes?.trim() || 'No architecture notes.'}\n\n`;
        markdown += `### Technology Stack Suggestions\n`;
        if (phaseData.techStackSuggestions && phaseData.techStackSuggestions.length > 0) {
          markdown += phaseData.techStackSuggestions.map(tech => 
            `- **${tech.category}:** ${tech.name}\n  - *Justification:* ${tech.justification}`
          ).join('\n\n') + '\n\n';
        } else {
          markdown += `No tech stack suggestions generated.\n\n`;
        }
        break;
      }
       case PhaseKey.Workflow: {
        const { steps } = projectData[key];
        markdown += `### Pipeline Steps\n\n`;
        if (steps && steps.length > 0) {
          steps.forEach(step => {
            markdown += `#### Step ${step.id}: ${step.name}\n\n`;
            markdown += `- **Agent:** ${step.agent}\n`;
            markdown += `- **Verb:** \`${step.verb}\`\n`;
            markdown += `- **Mission:**\n`;
            markdown += `  > ${step.mission.replace(/\n/g, '\n  > ')}\n\n`;
            markdown += `- **Input:** \`${step.input}\`\n`;
            markdown += `- **Output:** \`${step.output}\`\n\n`;
          });
        } else {
          markdown += `No workflow steps defined.\n\n`;
        }
        break;
      }
      case PhaseKey.Code: {
        const { repoUrl, repoOwner, repoName } = projectData[key];
        markdown += `### GitHub Repository\n`;
        if (repoUrl) {
            markdown += `Connected to: [${repoOwner}/${repoName}](${repoUrl})\n\n`;
        } else {
            markdown += `No repository connected.\n\n`;
        }
        break;
      }
      case PhaseKey.Refinement:
      case PhaseKey.Debut:
      case PhaseKey.Evolving: {
        const phaseData = projectData[key];
        if ('notes' in phaseData) {
            markdown += `### Notes\n`;
            markdown += `> ${phaseData.notes?.trim() || 'No notes for this phase.'}\n\n`;
        }
        break;
      }
    }
  });

  return markdown;
};


function App() {
  const [activePhase, setActivePhase] = useState<PhaseKey>(PhaseKey.Overture);
  const [projectData, setProjectData] = useState<ProjectData>(initialProjectData);
  const [isImportModalOpen, setImportModalOpen] = useState(false);
  const [sidebarWidth, setSidebarWidth] = useState(320);
  const [showScrollButton, setShowScrollButton] = useState(false);
  const mainRef = useRef<HTMLElement>(null);

  const handleUpdatePhaseData = useCallback((phase: PhaseKey, data: Partial<OvertureData | BlueprintData | GenericPhaseData | WorkflowData | CodeData>) => {
    setProjectData(prev => ({
        ...prev,
        [phase]: {
            ...prev[phase],
            ...data
        }
    }));
  }, []);
  
  const handleProjectNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setProjectData(prev => ({...prev, projectName: e.target.value}));
  };

  const handleImportDocument = useCallback(async (content: string) => {
    const parsedData = await processProjectDocument(content);
    setProjectData(prev => ({
      ...prev,
      projectName: parsedData.projectName,
      [PhaseKey.Overture]: {
        ...prev[PhaseKey.Overture],
        vision: parsedData.vision,
        userStories: parsedData.userStories,
      },
      [PhaseKey.Blueprint]: {
        ...prev[PhaseKey.Blueprint],
        architectureNotes: parsedData.architectureNotes,
      },
      [PhaseKey.Workflow]: {
          ...prev[PhaseKey.Workflow],
          steps: parsedData.workflowSteps,
          suggestions: [],
      }
    }));
    setActivePhase(PhaseKey.Workflow);
  }, []);

  const handleExportProject = () => {
    const markdownContent = generateMarkdown(projectData);
    const blob = new Blob([markdownContent], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const sanitizedName = projectData.projectName.toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-');
    const fileName = `${sanitizedName || 'lyra-project'}.md`;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleScroll = () => {
    if (mainRef.current) {
        const { scrollTop, scrollHeight, clientHeight } = mainRef.current;
        const distanceToBottom = scrollHeight - scrollTop - clientHeight;
        setShowScrollButton(distanceToBottom > 300);
    }
  };

  const handleScrollToBottom = () => {
    if (mainRef.current) {
        mainRef.current.scrollTo({ top: mainRef.current.scrollHeight, behavior: 'smooth' });
    }
  };

  const renderActivePhase = () => {
    switch (activePhase) {
      case PhaseKey.Overture:
        return <OvertureView 
                  config={PHASES[PhaseKey.Overture]}
                  data={projectData[PhaseKey.Overture]} 
                  onUpdate={(data) => handleUpdatePhaseData(PhaseKey.Overture, data)}
                  onNavigateToBlueprint={() => setActivePhase(PhaseKey.Blueprint)}
                />;
      case PhaseKey.Blueprint:
        return <BlueprintView 
                  config={PHASES[PhaseKey.Blueprint]}
                  data={projectData[PhaseKey.Blueprint]}
                  vision={projectData[PhaseKey.Overture].vision}
                  onUpdate={(data) => handleUpdatePhaseData(PhaseKey.Blueprint, data)}
                  onNavigateToCode={() => setActivePhase(PhaseKey.Workflow)}
                />
      case PhaseKey.Workflow:
        return <WorkflowView
                  config={PHASES[PhaseKey.Workflow]}
                  data={projectData[PhaseKey.Workflow]}
                  onUpdate={(data) => handleUpdatePhaseData(PhaseKey.Workflow, data)}
                  onNavigateToCode={() => setActivePhase(PhaseKey.Code)}
                />;
      case PhaseKey.Code:
        return <CodeView
                  config={PHASES[PhaseKey.Code]}
                  data={projectData[PhaseKey.Code]}
                  onUpdate={(data) => handleUpdatePhaseData(PhaseKey.Code, data)}
                  onNavigateToRefinement={() => setActivePhase(PhaseKey.Refinement)}
                />;
      case PhaseKey.Refinement:
      case PhaseKey.Debut:
      case PhaseKey.Evolving:
        const phaseData = projectData[activePhase];
        if ('notes' in phaseData) {
            return <PhaseView
                config={PHASES[activePhase]}
                data={phaseData}
                onUpdate={(data) => handleUpdatePhaseData(activePhase, data)}
                />
        }
        return null;
      default:
        return <div className="text-center text-gray-500">Select a phase to begin.</div>;
    }
  };

  return (
    <div className="flex h-screen w-full bg-zinc-950">
      <Sidebar 
        phases={PHASES} 
        activePhase={activePhase} 
        onSelectPhase={setActivePhase}
        onImport={() => setImportModalOpen(true)}
        onExport={handleExportProject}
        width={sidebarWidth}
        onResize={setSidebarWidth}
      />
      <ImportWorkflowModal
        isOpen={isImportModalOpen}
        onClose={() => setImportModalOpen(false)}
        onImport={handleImportDocument}
      />
      <main ref={mainRef} onScroll={handleScroll} style={{ marginLeft: `${sidebarWidth}px` }} className="flex-1 p-10 overflow-y-auto">
        <div className="max-w-4xl mx-auto">
           <div className="mb-8">
              <input
                type="text"
                value={projectData.projectName}
                onChange={handleProjectNameChange}
                className="text-4xl font-bold bg-transparent text-white w-full p-2 -ml-2 rounded-lg hover:bg-zinc-800/50 focus:bg-zinc-800/50 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-opacity-50 transition-all focus:shadow-[0_0_15px_theme(colors.purple.500_/_0.5)]"
                aria-label="Project Name"
              />
            </div>
            {renderActivePhase()}
        </div>
      </main>
      <ScrollToBottomButton isVisible={showScrollButton} onClick={handleScrollToBottom} />
    </div>
  );
}

export default App;