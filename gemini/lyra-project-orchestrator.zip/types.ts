
import type React from 'react';

export enum PhaseKey {
  Overture = 'OVERTURE',
  Blueprint = 'BLUEPRINT',
  Workflow = 'WORKFLOW',
  Code = 'CODE',
  Refinement = 'REFINEMENT',
  Debut = 'DEBUT',
  Evolving = 'EVOLVING',
}

export type ExecutionState = 'locked' | 'ready' | 'running' | 'completed' | 'error';

export interface PhaseConfig {
  key: PhaseKey;
  title: string;
  subtitle: string;
  description: string;
  icon: React.ReactNode;
}

export interface OvertureData {
  vision: string;
  userStories: string[];
  suggestions?: string[];
}

export interface TechStackSuggestion {
    category: string;
    name: string;
    justification: string;
}

export interface Agent {
    name: string;
    role: string;
}

export interface WorkflowStep {
    id: string;
    name: string;
    agent: string;
    mission: string;
    input: string;
    output: string;
    verb: string;
}

export interface BlueprintData {
  architectureNotes: string;
  techStackSuggestions: TechStackSuggestion[];
  suggestions?: string[];
}

export interface WorkflowData {
    steps: WorkflowStep[];
    suggestions?: string[];
}

export interface CodeData {
    githubToken: string;
    repoOwner: string;
    repoName: string;
    repoUrl: string;
}

export interface GenericPhaseData {
    notes: string;
}

export interface ProjectData {
  projectName: string;
  [PhaseKey.Overture]: OvertureData;
  [PhaseKey.Blueprint]: BlueprintData;
  [PhaseKey.Workflow]: WorkflowData;
  [PhaseKey.Code]: CodeData;
  [PhaseKey.Refinement]: GenericPhaseData;
  [PhaseKey.Debut]: GenericPhaseData;
  [PhaseKey.Evolving]: GenericPhaseData;
}

// GitHub API Types
export interface GitHubFile {
  name: string;
  path: string;
  sha: string;
  type: 'file' | 'dir';
  download_url: string | null;
  content?: string; // Base64 encoded content
  children?: GitHubFile[]; // For tree structure
}
