import React, { useState } from 'react';
import type { GitHubFile } from '../types';

const FolderIcon = ({ isOpen }: { isOpen: boolean }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 flex-shrink-0 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
    {isOpen 
      ? <path strokeLinecap="round" strokeLinejoin="round" d="M5 19a2 2 0 01-2-2V7a2 2 0 012-2h4l2 2h4a2 2 0 012 2v1M5 19h14a2 2 0 002-2v-5a2 2 0 00-2-2H9a2 2 0 00-2 2v5a2 2 0 01-2 2z" />
      : <path strokeLinecap="round" strokeLinejoin="round" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
    }
  </svg>
);

const FileIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 flex-shrink-0 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
    </svg>
);


interface FileNodeProps {
  node: GitHubFile;
  onSelect: (file: GitHubFile) => void;
  selectedPath: string | null;
  level: number;
}

const FileNode: React.FC<FileNodeProps> = ({ node, onSelect, selectedPath, level }) => {
  const [isOpen, setIsOpen] = useState(false);

  const isDirectory = node.type === 'dir';
  const isSelected = selectedPath === node.path;

  const handleToggle = () => {
    if (isDirectory) {
      setIsOpen(!isOpen);
    }
    onSelect(node);
  };

  const sortedChildren = node.children?.sort((a, b) => {
      if (a.type === b.type) return a.name.localeCompare(b.name);
      return a.type === 'dir' ? -1 : 1;
  });

  return (
    <div>
      <button
        onClick={handleToggle}
        style={{ paddingLeft: `${level * 1.25}rem` }}
        className={`w-full flex items-center text-left py-1.5 px-2 rounded-md transition-colors text-sm ${
            isSelected ? 'bg-purple-500/20 text-white' : 'text-gray-300 hover:bg-zinc-700/50'
        }`}
      >
        {isDirectory ? <FolderIcon isOpen={isOpen} /> : <FileIcon />}
        <span className="truncate">{node.name}</span>
      </button>
      {isDirectory && isOpen && (
        <div>
          {sortedChildren?.map(child => (
            <FileNode key={child.path} node={child} onSelect={onSelect} selectedPath={selectedPath} level={level + 1} />
          ))}
        </div>
      )}
    </div>
  );
};


interface FileExplorerProps {
  files: GitHubFile[];
  onSelect: (file: GitHubFile) => void;
  selectedPath: string | null;
}

const FileExplorer: React.FC<FileExplorerProps> = ({ files, onSelect, selectedPath }) => {
  const sortedFiles = files.sort((a, b) => {
      if (a.type === b.type) return a.name.localeCompare(b.name);
      return a.type === 'dir' ? -1 : 1;
  });
  
  return (
    <div className="space-y-1">
      {sortedFiles.map(node => (
        <FileNode key={node.path} node={node} onSelect={onSelect} selectedPath={selectedPath} level={0}/>
      ))}
    </div>
  );
};

export default FileExplorer;
