import React, { useState } from 'react';
import Spinner from './Spinner';

interface ImportWorkflowModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImport: (content: string) => Promise<void>;
}

const EXAMPLE_DOCUMENT = `📝 Execute Request: AI Family Multi-App Orchestration with Gemini CLI + OpenAI
Overview
We are requesting Gemini Studio to draft a comprehensive orchestration and API integration plan for the AI Family ecosystem, enabling seamless coordination, task handoffs, and feedback loops across 15 applications currently in proactive development.
This orchestration platform is designed to:
Serve as the service layer between applications
Leverage Gemini CLI and OpenAI GPT for background intelligence
Provide adaptive, AI-driven orchestration to support the Operator
Automate CI/CD pipelines for cross-application software development and deployment
Enable multi-agent collaboration under a unified orchestration framework
AI Family Summary and Roles
LYRA: Master Orchestrator – Supervises overall task flows and coordinates multi-agent operations.
KARA: Security and Compliance – Monitors agent actions, ensures safe orchestration and governance.
SOPHIA: Semantic Intelligence – Handles complex reasoning, semantic mapping, and context linking.
CECILIA: Assistive Technology Lead – Provides real-time guidance, adaptive support, and operator aid.
GUAC: Communication Moderator – Oversees inter-application messaging and network security.
ANDIE / DAN / STAN / DUDE: Specialized agents for code execution, testing, creative output, and multi-modal operations.
Together, these agents use AI technology to maintain service orientation, ensuring the Operator is supported with intelligent, context-aware orchestration throughout the development and deployment lifecycle.
Objective
To enable Gemini Studio to:
Integrate with all AI Family applications (CUA, Image Maker, SoundNodeLab, Gemini Studio SPA, WebETA, Container Manager, Audio/Voice modules, and others).
Provide API instructions for each application to allow direct orchestration (not limited to Gemini/OpenAI API calls).
Establish orchestration handoffs and feedback loops between applications and agents.
Support CI/CD automation across the ecosystem for software builds, deployments, and version synchronization.
Enable logical interoperability where applications exchange context and outputs in a standardized format.
Execution Deliverables
Unified Orchestration Specification
YAML/JSON templates for defining multi-app workflows.
Agent and Operator routing rules for task delegation.
Context persistence and state synchronization guidelines.
API Documentation and Instructions
Endpoints for each application:
Task submission (POST)
Data retrieval (GET)
Orchestration triggers and event hooks
Internal service layer connectors for direct inter-app communication.
Authentication and access control for secure orchestration.
Feedback Loop Architecture
Mechanism for each application to:
Report progress, logs, and errors
Return results to the orchestrator
Allow dynamic task reassignment
Aggregated feedback dashboard for the Operator.
CI/CD Orchestration Flow
Scripts and APIs to automate builds, tests, and deployments between applications.
Rollback and version control strategy.
Cross-app synchronization for consistent software delivery.
Implementation Guide
GitHub Organization and repository structure.
Multi-container orchestration templates.
Operator instructions for initiating and managing task flows.
Next-Phase Dual-LLM Adaptation
To future-proof the ecosystem:
Introduce context synchronization between Gemini and OpenAI for memory and decision-sharing.
Enhance Gemini CLI with commands for multi-agent orchestration and CI/CD triggers.
Implement parallel execution of tasks across multiple applications with coordinated aggregation.
Build a real-time Operator Control Center for monitoring and manual overrides.
Expand AI-as-a-Service deployment with role-based access and multi-tenant support.
Execution Path
Gemini Studio to map all applications, draft API instructions, and deliver orchestration specs.
AI Family roles to be aligned within orchestration flows for maximum operator support.
GitHub repositories to be prepared for orchestrator service, application APIs, and CI/CD pipelines.
Feedback-driven deployment to evolve orchestration iteratively with Gemini and OpenAI intelligence.`;


const ImportWorkflowModal: React.FC<ImportWorkflowModalProps> = ({ isOpen, onClose, onImport }) => {
  const [documentContent, setDocumentContent] = useState(EXAMPLE_DOCUMENT);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleImportClick = async () => {
    if (!documentContent) return;
    setIsLoading(true);
    setError('');
    try {
      await onImport(documentContent);
      onClose();
      // Keep content for now in case user wants to re-import with tweaks
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred during import.');
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 animate-fade-in-fast" aria-modal="true" role="dialog">
      <div className="bg-zinc-900/90 backdrop-blur-lg rounded-2xl shadow-2xl p-8 w-full max-w-2xl border border-purple-500/40 shadow-[0_0_40px_rgba(168,85,247,0.3)] m-4">
        <div className="flex justify-between items-start">
            <h2 id="import-modal-title" className="text-2xl font-bold text-white mb-4">Import Project Document</h2>
            <button onClick={onClose} className="text-gray-400 hover:text-white text-3xl leading-none">&times;</button>
        </div>

        <p className="text-gray-400 mb-6">Paste your project plan or workflow definition below. The AI will parse it and populate the project phases.</p>
        <textarea
          value={documentContent}
          onChange={(e) => setDocumentContent(e.target.value)}
          rows={15}
          className="w-full bg-zinc-950/70 border border-zinc-700 rounded-md p-4 text-gray-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition font-mono text-xs focus:shadow-[0_0_10px_theme(colors.purple.500)]"
          placeholder="Paste project document here..."
          aria-labelledby="import-modal-title"
        />
        {error && <p className="text-red-400 text-sm mt-4" role="alert">{error}</p>}
        <div className="flex justify-end items-center mt-6 space-x-4">
          <button
            onClick={onClose}
            className="px-4 py-2 text-gray-300 font-semibold rounded-lg hover:bg-zinc-700/80 transition-colors"
            aria-label="Cancel import"
          >
            Cancel
          </button>
          <button
            onClick={handleImportClick}
            disabled={isLoading || !documentContent}
            className="flex items-center justify-center w-48 px-4 py-2 bg-purple-600 text-white font-semibold rounded-lg transition-all disabled:bg-purple-900/50 disabled:cursor-not-allowed neon-glow neon-glow-purple"
          >
            {isLoading ? <Spinner /> : 'Import Document'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ImportWorkflowModal;