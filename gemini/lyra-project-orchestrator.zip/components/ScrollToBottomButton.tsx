import React from 'react';

interface ScrollToBottomButtonProps {
  isVisible: boolean;
  onClick: () => void;
}

const DoubleArrowDownIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M19 13l-7 7-7-7m14-8l-7 7-7-7" />
    </svg>
);

const ScrollToBottomButton: React.FC<ScrollToBottomButtonProps> = ({ isVisible, onClick }) => {
  return (
    <button
      onClick={onClick}
      aria-label="Scroll to bottom"
      className={`fixed bottom-8 right-12 z-20 p-3 rounded-full bg-purple-600/80 backdrop-blur-sm text-white shadow-lg transition-all duration-300 ease-in-out transform
        ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-16 pointer-events-none'}
        hover:bg-purple-500 neon-glow neon-glow-purple focus:outline-none focus:ring-2 focus:ring-purple-400 focus:ring-opacity-75`}
    >
      <DoubleArrowDownIcon />
    </button>
  );
};

export default ScrollToBottomButton;
