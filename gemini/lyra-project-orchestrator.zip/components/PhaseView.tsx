import React from 'react';
import { PhaseConfig, GenericPhaseData } from '../types';

interface PhaseViewProps {
  config: PhaseConfig;
  data: GenericPhaseData;
  onUpdate: (data: Partial<GenericPhaseData>) => void;
}

const PhaseView: React.FC<PhaseViewProps> = ({ config, data, onUpdate }) => {
  return (
    <div className="space-y-8 animate-fade-in">
      <div>
        <h2 className="text-3xl font-bold text-white">{config.title}: <span className="text-pink-400">{config.subtitle}</span></h2>
        <p className="mt-2 text-gray-400 max-w-2xl">{config.description}</p>
      </div>
      <div className="bg-zinc-900/60 backdrop-blur-sm border border-pink-500/30 rounded-xl p-6 shadow-[0_0_25px_rgba(236,72,153,0.15)]">
        <label htmlFor="notes" className="block text-sm font-medium text-gray-300 mb-2">Notes</label>
        <textarea
          id="notes"
          value={data.notes}
          onChange={(e) => onUpdate({ notes: e.target.value })}
          rows={15}
          className="w-full bg-zinc-950/70 border border-zinc-700 rounded-md p-4 text-gray-200 focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition focus:shadow-[0_0_10px_theme(colors.pink.500)]"
          placeholder={`Enter your notes for the ${config.subtitle} phase...`}
        />
      </div>
    </div>
  );
};

export default PhaseView;