import React, { useState, useEffect } from 'react';
import { WorkflowData, PhaseConfig, ExecutionState } from '../../types';
import { refineWorkflow } from '../../services/geminiService';
import WorkflowStepCard from './WorkflowStepCard';
import Spinner from '../Spinner';

interface WorkflowViewProps {
  config: PhaseConfig;
  data: WorkflowData;
  onUpdate: (data: Partial<WorkflowData>) => void;
  onNavigateToCode: () => void;
}

const RefreshIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h5M20 20v-5h-5M4 4l1.5 1.5A9 9 0 0121.5 16.5M20 20l-1.5-1.5A9 9 0 002.5 7.5" />
    </svg>
);

const SuggestionIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
    </svg>
);

const ProceedIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3" />
    </svg>
);


const STEPS_PER_PAGE = 2;

const WorkflowView: React.FC<WorkflowViewProps> = ({ config, data, onUpdate, onNavigateToCode }) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [stepStates, setStepStates] = useState<ExecutionState[]>([]);
  const [activeExecution, setActiveExecution] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isRefining, setIsRefining] = useState(false);
  const [error, setError] = useState('');
  
  const initializeStates = () => {
    if (data.steps.length > 0) {
        const initialStates: ExecutionState[] = Array(data.steps.length).fill('locked');
        initialStates[0] = 'ready';
        setStepStates(initialStates);
    } else {
        setStepStates([]);
    }
    setActiveExecution(null);
    setCurrentPage(1);
  };

  useEffect(() => {
    initializeStates();
  }, [data.steps]);

  const handleGenerateSuggestions = async () => {
    setIsLoading(true);
    setError('');
    try {
      const { steps, suggestions } = await refineWorkflow(data.steps, 'Analyze the current workflow and suggest improvements.');
      onUpdate({ steps, suggestions });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSuggestionClick = async (suggestion: string) => {
    if (suggestion.startsWith('[PROCEED]')) {
        onNavigateToCode();
        return;
    }
    setIsRefining(true);
    setError('');
    try {
        const { steps, suggestions: newSuggestions } = await refineWorkflow(data.steps, suggestion);
        onUpdate({ steps, suggestions: newSuggestions });
    } catch(err) {
        setError(err instanceof Error ? err.message : 'An unknown error occurred during refinement.');
    } finally {
        setIsRefining(false);
    }
  }

  if (!data.steps || data.steps.length === 0) {
    return (
        <div className="animate-fade-in space-y-8">
             <div>
                <h2 className="text-3xl font-bold text-white">{config.title}: <span className="text-purple-400">{config.subtitle}</span></h2>
                <p className="mt-2 text-gray-400 max-w-2xl">{config.description}</p>
            </div>
            <div className="mt-8 text-center p-8 bg-zinc-900/60 backdrop-blur-sm border border-dashed border-zinc-700 rounded-xl">
                <h3 className="text-xl font-bold text-white">No Workflow Imported</h3>
                <p className="mt-2 text-gray-400">Use the "Import Document" button in the sidebar to get started.</p>
            </div>
      </div>
    );
  }
  
  const totalPages = Math.ceil(data.steps.length / STEPS_PER_PAGE);
  const currentSteps = data.steps.slice(
    (currentPage - 1) * STEPS_PER_PAGE,
    currentPage * STEPS_PER_PAGE
  );

  const getStepIndex = (stepId: string) => data.steps.findIndex(s => s.id === stepId);
  
  const handleExecuteTask = (stepId: string) => {
    const index = getStepIndex(stepId);
    if (index === -1 || activeExecution) return;

    setActiveExecution(stepId);
    setStepStates(prev => {
        const newStates = [...prev];
        newStates[index] = 'running';
        return newStates;
    });
  };

  const handleTaskComplete = (stepId: string) => {
    const index = getStepIndex(stepId);
    if (index === -1) return;
    
    setStepStates(prev => {
        const newStates = [...prev];
        newStates[index] = 'completed';
        if (index + 1 < newStates.length) {
            newStates[index + 1] = 'ready';
        }
        return newStates;
    });
    setActiveExecution(null);
  };
    
  const handleTaskError = (stepId: string) => {
    const index = getStepIndex(stepId);
    if (index === -1) return;

    setStepStates(prev => {
        const newStates = [...prev];
        newStates[index] = 'error';
        return newStates;
    });
    setActiveExecution(null);
  };

  const goToNextPage = () => setCurrentPage((page) => Math.min(page + 1, totalPages));
  const goToPreviousPage = () => setCurrentPage((page) => Math.max(page - 1, 1));


  return (
    <div className="space-y-8 animate-fade-in">
      <div className="flex justify-between items-start flex-wrap gap-4">
        <div>
            <h2 className="text-3xl font-bold text-white">{config.title}: <span className="text-purple-400">{config.subtitle}</span></h2>
            <p className="mt-2 text-gray-400 max-w-2xl">{config.description}</p>
        </div>
        <div className="flex items-center space-x-2">
            <button
                onClick={initializeStates}
                disabled={isLoading || isRefining}
                className="flex items-center px-4 py-2 bg-zinc-800 text-white font-semibold rounded-lg hover:bg-zinc-700 transition-colors disabled:opacity-50 neon-glow neon-glow-blue"
                aria-label="Reset workflow execution"
            >
                <RefreshIcon /> Reset
            </button>
             <button
                onClick={handleGenerateSuggestions}
                disabled={isLoading || isRefining || activeExecution !== null}
                className="flex items-center justify-center px-4 py-2 bg-purple-600 text-white font-semibold rounded-lg transition-all disabled:bg-purple-900/50 disabled:cursor-not-allowed neon-glow neon-glow-purple"
              >
                {isLoading ? <Spinner /> : '✨ Suggest Actions'}
             </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 min-h-[520px]">
        {currentSteps.map((step) => {
           const stepIndex = getStepIndex(step.id);
           return (
            <WorkflowStepCard 
              key={step.id} 
              step={step} 
              executionState={stepStates[stepIndex]}
              onExecute={handleExecuteTask}
              onComplete={handleTaskComplete}
              onError={handleTaskError}
              isAnyTaskRunning={activeExecution !== null}
            />
        )})}
      </div>
      
      {totalPages > 1 && (
        <div className="flex items-center justify-center p-4 space-x-4">
            <button
                onClick={goToPreviousPage}
                disabled={currentPage === 1 || !!activeExecution}
                className="px-4 py-2 font-semibold text-white bg-zinc-800/80 rounded-lg hover:bg-purple-500/20 hover:border-purple-500/50 border border-transparent disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                aria-label="Previous page"
            >
                Previous
            </button>
            <span className="text-gray-400">
                Page {currentPage} of {totalPages}
            </span>
            <button
                onClick={goToNextPage}
                disabled={currentPage === totalPages || !!activeExecution}
                className="px-4 py-2 font-semibold text-white bg-zinc-800/80 rounded-lg hover:bg-purple-500/20 hover:border-purple-500/50 border border-transparent disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                aria-label="Next page"
            >
                Next
            </button>
        </div>
      )}

      { (data.suggestions || isRefining) &&
        <div className="bg-zinc-900/60 backdrop-blur-sm border border-purple-500/20 rounded-xl p-6 shadow-[0_0_25px_rgba(168,85,247,0.1)] animate-fade-in">
            <h3 className="text-xl font-semibold text-white mb-4">Next Actions</h3>
            {error && <p className="text-red-400 text-sm mb-4">{error}</p>}
            {isRefining && <div className="flex justify-center p-4"><Spinner /></div> }
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                { !isRefining && data.suggestions?.map((suggestion, index) => {
                    const isProceed = suggestion.startsWith('[PROCEED]');
                    const buttonText = isProceed ? suggestion.replace('[PROCEED]', '').trim() : suggestion;

                    return (
                        <button key={index}
                            onClick={() => handleSuggestionClick(suggestion)}
                            disabled={isLoading || isRefining || activeExecution !== null}
                            className={`flex items-center justify-center text-center p-3 rounded-lg transition-all text-sm font-semibold disabled:opacity-50 disabled:cursor-not-allowed neon-glow
                            ${isProceed 
                                ? 'bg-green-500/20 text-green-300 hover:bg-green-500/30 col-span-1 md:col-span-3 neon-glow-green' 
                                : 'bg-blue-500/20 text-blue-300 hover:bg-blue-500/30 neon-glow-blue'}`
                            }
                        >
                           {isProceed ? <ProceedIcon /> : <SuggestionIcon /> } {buttonText}
                        </button>
                    )
                })}
            </div>
        </div>
      }
    </div>
  );
};

export default WorkflowView;