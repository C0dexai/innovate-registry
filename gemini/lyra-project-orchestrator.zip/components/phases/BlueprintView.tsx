import React, { useState } from 'react';
import { BlueprintData, PhaseConfig } from '../../types';
import { generateTechStack } from '../../services/geminiService';
import Spinner from '../Spinner';

interface BlueprintViewProps {
  config: PhaseConfig;
  data: BlueprintData;
  vision: string;
  onUpdate: (data: Partial<BlueprintData>) => void;
  onNavigateToCode: () => void;
}

const SuggestionIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
    </svg>
);

const ProceedIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3" />
    </svg>
);

const BlueprintView: React.FC<BlueprintViewProps> = ({ config, data, vision, onUpdate, onNavigateToCode }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleGenerateStack = async () => {
    setIsLoading(true);
    setError('');
    try {
      const { stack, suggestions } = await generateTechStack(vision, data.architectureNotes);
      onUpdate({ techStackSuggestions: stack, suggestions: suggestions });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSuggestionClick = async (suggestion: string) => {
    if (suggestion.startsWith('[PROCEED]')) {
        onNavigateToCode();
        return;
    }
    // For now, we just show an alert for refinement as the Gemini service is not implemented.
    // In a full implementation, this would call a `refineTechStack` service.
    alert(`Refinement action clicked: "${suggestion}"\n\nThis would trigger another AI call in a full implementation.`);
  }

  return (
    <div className="space-y-8 animate-fade-in">
      <div>
        <h2 className="text-3xl font-bold text-white">{config.title}: <span className="text-blue-400">{config.subtitle}</span></h2>
        <p className="mt-2 text-gray-400 max-w-2xl">{config.description}</p>
      </div>

      <div className="bg-zinc-900/60 backdrop-blur-sm border border-blue-500/20 rounded-xl p-6 shadow-[0_0_25px_rgba(59,130,246,0.1)]">
        <label htmlFor="architecture-notes" className="block text-sm font-medium text-gray-300 mb-2">Architecture & Design Notes</label>
        <textarea
          id="architecture-notes"
          value={data.architectureNotes}
          onChange={(e) => onUpdate({ architectureNotes: e.target.value })}
          rows={8}
          className="w-full bg-zinc-950/70 border border-zinc-700 rounded-md p-4 text-gray-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition focus:shadow-[0_0_10px_theme(colors.blue.500)]"
          placeholder="Detail system boundaries, data flow, API contracts, user flows, etc."
        />
      </div>

      <div className="bg-zinc-900/60 backdrop-blur-sm border border-blue-500/20 rounded-xl p-6 shadow-[0_0_25px_rgba(59,130,246,0.1)]">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold text-white">Technology Stack Suggestions</h3>
          <button
            onClick={handleGenerateStack}
            disabled={isLoading}
            className="flex items-center justify-center px-4 py-2 bg-blue-600 text-white font-semibold rounded-lg transition-all disabled:bg-blue-900/50 disabled:cursor-not-allowed neon-glow neon-glow-blue"
          >
            {isLoading ? <Spinner /> : '✨ Suggest with AI'}
          </button>
        </div>
        {error && <p className="text-red-400 text-sm mb-4">{error}</p>}
        <div className="space-y-4 min-h-[8rem]">
          {data.techStackSuggestions.length > 0 ? (
            data.techStackSuggestions.map((item, index) => (
              <div key={index} className="bg-zinc-800/50 p-4 rounded-lg border border-blue-500/20 animate-fade-in">
                <p className="font-bold text-blue-400">{item.category}: <span className="text-white">{item.name}</span></p>
                <p className="text-gray-300 mt-1">{item.justification}</p>
              </div>
            ))
          ) : (
            <p className="text-gray-500">AI-generated tech stack suggestions will appear here.</p>
          )}
        </div>
      </div>
      
      { data.suggestions &&
        <div className="bg-zinc-900/60 backdrop-blur-sm border border-blue-500/20 rounded-xl p-6 shadow-[0_0_25px_rgba(59,130,246,0.1)] animate-fade-in">
            <h3 className="text-xl font-semibold text-white mb-4">Next Actions</h3>
             {error && <p className="text-red-400 text-sm mb-4">{error}</p>}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {data.suggestions?.map((suggestion, index) => {
                    const isProceed = suggestion.startsWith('[PROCEED]');
                    const buttonText = isProceed ? suggestion.replace('[PROCEED]', '').trim() : suggestion;

                    return (
                        <button key={index}
                            onClick={() => handleSuggestionClick(suggestion)}
                            disabled={isLoading}
                            className={`flex items-center justify-center text-center p-3 rounded-lg transition-all text-sm font-semibold disabled:opacity-50 disabled:cursor-not-allowed neon-glow
                            ${isProceed 
                                ? 'bg-green-500/20 text-green-300 hover:bg-green-500/30 col-span-1 md:col-span-3 neon-glow-green' 
                                : 'bg-gray-700/50 text-gray-300 hover:bg-gray-700/80 neon-glow-blue'}`
                            }
                        >
                           {isProceed ? <ProceedIcon /> : <SuggestionIcon /> } {buttonText}
                        </button>
                    )
                })}
            </div>
        </div>
      }

    </div>
  );
};

export default BlueprintView;