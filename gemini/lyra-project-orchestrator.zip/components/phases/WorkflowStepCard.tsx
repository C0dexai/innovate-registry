import React, { useState, useEffect, useRef } from 'react';
import { WorkflowStep, ExecutionState } from '../../types';
import Spinner from '../Spinner';

interface WorkflowStepCardProps {
    step: WorkflowStep;
    executionState: ExecutionState;
    onExecute: (stepId: string) => void;
    onComplete: (stepId: string) => void;
    onError: (stepId: string) => void;
    isAnyTaskRunning: boolean;
}

const MissionIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
    </svg>
);

const ExecuteIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
        <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
        <path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.022 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" />
    </svg>
);

const LockIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
    </svg>
);

const CheckCircleIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-green-400" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
    </svg>
);

const WorkflowStepCard: React.FC<WorkflowStepCardProps> = ({ step, executionState, onExecute, onComplete, onError, isAnyTaskRunning }) => {
    const [log, setLog] = useState<string[]>([]);
    const [progress, setProgress] = useState(0);
    const intervalRef = useRef<number | null>(null);

    const cleanup = () => {
        if (intervalRef.current) {
            clearInterval(intervalRef.current);
            intervalRef.current = null;
        }
    };
    
    useEffect(() => {
        return cleanup;
    }, []);

    useEffect(() => {
        // Reset local simulation state if the step is reset externally
        if (executionState === 'ready' || executionState === 'locked') {
            setProgress(0);
            setLog([]);
            cleanup();
        }

        if (executionState === 'running' && !intervalRef.current) {
            setLog([`[${new Date().toLocaleTimeString()}] Task initiated for agent ${step.agent}...`]);
            setProgress(0);

            intervalRef.current = window.setInterval(() => {
                setProgress(prev => {
                    const newProgress = prev + 10;
                    if (newProgress >= 100) {
                        cleanup();
                        setLog(l => [...l, `[${new Date().toLocaleTimeString()}] Agent ${step.agent} finished.` , `[${new Date().toLocaleTimeString()}] Processing complete. Handing over output: ${step.output}`]);
                        onComplete(step.id);
                        return 100;
                    }
                    const messages = [ "Reticulating splines...", "Optimizing flux capacitor...", "Calibrating sub-ether relays...", "Defragmenting reality...", "Parsing model outputs...", "Fine-tuning weights...", "Compiling shaders...", "Queuing render farm...", "Packaging assets..."];
                    const randomMessage = messages[Math.floor(Math.random()*messages.length)];
                    setLog(l => [...l, `[${new Date().toLocaleTimeString()}] ${randomMessage} (${newProgress}%)`]);
                    return newProgress;
                });
            }, 400);
        }
    }, [executionState, step.id, onComplete]);
    
    const getStateStyles = () => {
        switch (executionState) {
            case 'completed': return 'border-green-500/50 shadow-[0_0_12px_theme(colors.green.500_/_0.3)]';
            case 'running': return 'border-purple-500/80 shadow-[0_0_15px_theme(colors.purple.500_/_0.5)]';
            case 'ready': return 'border-cyan-500/50 shadow-[0_0_12px_theme(colors.cyan.500_/_0.3)]';
            case 'error': return 'border-red-500/50 shadow-[0_0_12px_theme(colors.red.500_/_0.3)]';
            default: return 'border-zinc-700/50';
        }
    };
    
    const cardClasses = `bg-zinc-900/70 backdrop-blur-sm rounded-lg shadow-lg border flex flex-col h-full animate-fade-in transition-all duration-300 ${getStateStyles()} ${executionState === 'locked' ? 'opacity-60' : ''}`;

    return (
        <div className={cardClasses}>
            <div className="p-4 border-b border-zinc-700/50">
                <div className="flex justify-between items-start">
                    <div>
                        <p className="text-sm font-mono text-purple-400">STEP {step.id}</p>
                        <h3 className="text-lg font-bold text-white mt-1 capitalize">{step.name.replace(/_/g, ' ')}</h3>
                        <p className="text-sm text-gray-400">Agent: {step.agent}</p>
                    </div>
                    <div className="text-right flex-shrink-0 ml-4">
                        <span className="inline-block bg-zinc-700 rounded-full px-3 py-1 text-sm font-semibold text-gray-300">{step.verb}</span>
                    </div>
                </div>
            </div>

            {/* Mission Section */}
            <div className="p-4 border-b border-zinc-700/50">
                <div className="flex items-center text-gray-300 mb-3">
                    <MissionIcon />
                    <h4 className="font-semibold text-white">Mission Briefing</h4>
                </div>
                <div className="space-y-3">
                    <div className="p-3 bg-black/40 rounded-md border border-zinc-700/50">
                        <p className="text-gray-300 whitespace-pre-wrap font-mono text-xs leading-relaxed">{step.mission}</p>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                        <div className="bg-black/30 p-2 rounded-md">
                            <p className="font-semibold text-gray-400">Input:</p>
                            <p className="font-mono text-cyan-400 break-all text-xs">{step.input}</p>
                        </div>
                        <div className="bg-black/30 p-2 rounded-md">
                            <p className="font-semibold text-gray-400">Output:</p>
                            <p className="font-mono text-green-400 break-all text-xs">{step.output}</p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Execute Section */}
            <div className="p-4 flex-grow flex flex-col">
                <div className="flex items-center text-gray-300 mb-3">
                    {executionState === 'locked' ? <LockIcon /> : <ExecuteIcon />}
                    <h4 className="font-semibold text-white">Execution</h4>
                </div>
                <div className="flex-grow">
                    {executionState === 'locked' && (
                        <div className="text-center h-full flex flex-col items-center justify-center">
                            <LockIcon />
                            <h4 className="font-semibold text-white mt-2">Task Locked</h4>
                            <p className="text-gray-400 text-sm">Complete the previous step to unlock.</p>
                        </div>
                    )}
                    {executionState === 'ready' && (
                        <div className="text-center h-full flex flex-col items-center justify-center">
                            <h4 className="font-semibold text-white">Ready to Execute Task</h4>
                            <p className="text-gray-400 text-sm mb-4">Start the process for this step.</p>
                            <button onClick={() => onExecute(step.id)} disabled={isAnyTaskRunning} className="w-48 flex items-center justify-center px-4 py-2 bg-green-600 text-white font-semibold rounded-lg transition-all disabled:bg-zinc-600 disabled:cursor-not-allowed neon-glow neon-glow-green">
                                {isAnyTaskRunning ? 'Waiting...' : 'Begin Task'}
                            </button>
                        </div>
                    )}
                    {executionState === 'running' && (
                        <div className="h-full flex flex-col">
                            <h4 className="font-semibold text-white mb-2">Executing Task...</h4>
                            <div className="w-full bg-zinc-700 rounded-full h-2.5 mb-2">
                                <div className="bg-purple-600 h-2.5 rounded-full transition-all duration-500 shadow-[0_0_10px_theme(colors.purple.500)]" style={{ width: `${progress}%` }}></div>
                            </div>
                            <div className="flex-grow bg-black/50 p-2 rounded-md font-mono text-xs text-gray-300 overflow-y-auto h-32">
                                {log.map((l, i) => <p key={i} className="animate-fade-in-fast">{l}</p>)}
                            </div>
                        </div>
                    )}
                    {executionState === 'completed' && (
                        <div className="text-center h-full flex flex-col items-center justify-center">
                            <CheckCircleIcon />
                            <h4 className="font-semibold text-green-400 mt-2">Task Completed</h4>
                            <p className="text-gray-400 text-sm">The agent has finished its work.</p>
                        </div>
                    )}
                    {executionState === 'error' && (
                        <div className="text-center h-full flex flex-col items-center justify-center">
                            <h4 className="font-semibold text-red-400">Task Error</h4>
                            <p className="text-gray-400 text-sm mb-4">An error occurred during execution.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default WorkflowStepCard;