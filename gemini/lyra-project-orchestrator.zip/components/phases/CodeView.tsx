import React, { useState, useEffect, useCallback } from 'react';
import { Editor } from '@monaco-editor/react';
import { CodeData, PhaseConfig, GitHubFile } from '../../types';
import * as githubService from '../../services/githubService';
import Spinner from '../Spinner';
import FileExplorer from '../FileExplorer';

interface CodeViewProps {
  config: PhaseConfig;
  data: CodeData;
  onUpdate: (data: Partial<CodeData>) => void;
  onNavigateToRefinement: () => void;
}

const languageMap: Record<string, string> = {
  js: 'javascript', ts: 'typescript', jsx: 'javascript', tsx: 'typescript',
  json: 'json', yml: 'yaml', yaml: 'yaml', md: 'markdown',
  html: 'html', css: 'css', py: 'python', sh: 'shell',
  java: 'java', go: 'go', php: 'php', rb: 'ruby'
};

const getLanguage = (filename: string): string => {
  const extension = filename.split('.').pop()?.toLowerCase() || '';
  return languageMap[extension] || 'plaintext';
};


const CodeView: React.FC<CodeViewProps> = ({ config, data, onUpdate }) => {
  const [isConnected, setIsConnected] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [files, setFiles] = useState<GitHubFile[]>([]);
  const [selectedFile, setSelectedFile] = useState<GitHubFile | null>(null);
  const [activeFileContent, setActiveFileContent] = useState<string>('');
  const [isDirty, setIsDirty] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [commitMessage, setCommitMessage] = useState('');

  const checkInitialConnection = useCallback(async () => {
    if (data.githubToken && data.repoOwner && data.repoName) {
      setIsLoading(true);
      setError(null);
      try {
        const rootFiles = await githubService.getRepoContents(data.repoOwner, data.repoName, '', data.githubToken);
        setFiles(rootFiles);
        setIsConnected(true);
        onUpdate({ repoUrl: `https://github.com/${data.repoOwner}/${data.repoName}` });
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to connect to repository.');
        setIsConnected(false);
      } finally {
        setIsLoading(false);
      }
    }
  }, [data.githubToken, data.repoOwner, data.repoName, onUpdate]);

  useEffect(() => {
    checkInitialConnection();
  }, [checkInitialConnection]);
  

  const handleFileSelect = async (file: GitHubFile) => {
    if (isDirty && !window.confirm("You have unsaved changes. Are you sure you want to discard them?")) {
        return;
    }

    setIsLoading(true);
    setError(null);
    setSelectedFile(file);

    try {
      if (file.type === 'dir') {
        const contents = await githubService.getRepoContents(data.repoOwner, data.repoName, file.path, data.githubToken);
        // Find and update the directory node with its children
        const updateTree = (nodes: GitHubFile[]): GitHubFile[] => {
            return nodes.map(node => {
                if (node.path === file.path) {
                    return { ...node, children: contents };
                }
                if (node.children) {
                    return { ...node, children: updateTree(node.children) };
                }
                return node;
            });
        };
        setFiles(prevFiles => updateTree(prevFiles));
        setActiveFileContent('');
      } else {
        const fileData = await githubService.getFileContent(data.repoOwner, data.repoName, file.path, data.githubToken);
        setSelectedFile(fileData); // update with full data including sha
        setActiveFileContent(fileData.content || '');
        setCommitMessage(`Update ${file.name}`);
        setIsDirty(false);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : `Failed to load ${file.name}`);
      setActiveFileContent('');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveContent = async () => {
    if (!selectedFile || selectedFile.type === 'dir' || !isDirty) return;

    setIsSaving(true);
    setError(null);
    try {
        const updateResponse = await githubService.updateFile(
            data.repoOwner,
            data.repoName,
            selectedFile.path,
            data.githubToken,
            activeFileContent,
            selectedFile.sha,
            commitMessage
        );
        // Update SHA of the file to allow subsequent saves
        setSelectedFile(prev => prev ? { ...prev, sha: updateResponse.content.sha } : null);
        setIsDirty(false);
        setCommitMessage('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save file.');
    } finally {
        setIsSaving(false);
    }
  };
  
  const handleConnect = async (e: React.FormEvent) => {
    e.preventDefault();
    checkInitialConnection();
  };

  const handleDisconnect = () => {
    onUpdate({ githubToken: '', repoOwner: '', repoName: '', repoUrl: '' });
    setIsConnected(false);
    setFiles([]);
    setSelectedFile(null);
    setActiveFileContent('');
  };


  return (
    <div className="space-y-8 animate-fade-in">
      <div className="flex justify-between items-start">
        <div>
            <h2 className="text-3xl font-bold text-white">{config.title}: <span className="text-cyan-400">{config.subtitle}</span></h2>
            <p className="mt-2 text-gray-400 max-w-2xl">{config.description}</p>
        </div>
        {isConnected && 
          <button onClick={handleDisconnect} className="px-4 py-2 bg-zinc-800 text-white font-semibold rounded-lg hover:bg-zinc-700 transition-colors neon-glow neon-glow-blue">Disconnect</button>
        }
      </div>

      {!isConnected ? (
        <div className="bg-zinc-900/60 backdrop-blur-sm border border-cyan-500/20 rounded-xl p-6 shadow-[0_0_25px_rgba(34,211,238,0.1)]">
            <h3 className="text-xl font-semibold text-white mb-4">Connect to GitHub</h3>
            <form onSubmit={handleConnect} className="space-y-4">
                <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1" htmlFor="github-token">GitHub Personal Access Token</label>
                    <input type="password" id="github-token" value={data.githubToken} onChange={e => onUpdate({ githubToken: e.target.value })} className="w-full bg-zinc-950/70 border border-zinc-700 rounded-md p-2 text-gray-200 focus:ring-1 focus:ring-cyan-500"/>
                </div>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-300 mb-1" htmlFor="github-owner">Repository Owner</label>
                        <input type="text" id="github-owner" value={data.repoOwner} onChange={e => onUpdate({ repoOwner: e.target.value })} placeholder="e.g., 'google'" className="w-full bg-zinc-950/70 border border-zinc-700 rounded-md p-2 text-gray-200 focus:ring-1 focus:ring-cyan-500"/>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-300 mb-1" htmlFor="github-repo">Repository Name</label>
                        <input type="text" id="github-repo" value={data.repoName} onChange={e => onUpdate({ repoName: e.target.value })} placeholder="e.g., 'lyra'" className="w-full bg-zinc-950/70 border border-zinc-700 rounded-md p-2 text-gray-200 focus:ring-1 focus:ring-cyan-500"/>
                    </div>
                </div>
                {error && <p className="text-red-400 text-sm">{error}</p>}
                <div className="flex justify-end">
                    <button type="submit" disabled={isLoading} className="flex items-center justify-center w-36 px-4 py-2 bg-cyan-600 text-white font-semibold rounded-lg transition-all disabled:bg-cyan-900/50 disabled:cursor-not-allowed neon-glow neon-glow-blue">
                         {isLoading ? <Spinner /> : 'Connect'}
                    </button>
                </div>
            </form>
        </div>
      ) : (
        <div className="flex flex-col md:flex-row gap-6 min-h-[70vh]">
            <div className="w-full md:w-1/3 bg-zinc-900/60 backdrop-blur-sm border border-cyan-500/20 rounded-xl p-4 shadow-[0_0_25px_rgba(34,211,238,0.1)] overflow-y-auto">
                <h3 className="text-lg font-semibold text-white mb-3 px-2">File Explorer</h3>
                <FileExplorer files={files} onSelect={handleFileSelect} selectedPath={selectedFile?.path || null}/>
            </div>
            <div className="w-full md:w-2/3 flex flex-col gap-4">
                <div className="flex-grow bg-zinc-900/60 backdrop-blur-sm border border-cyan-500/20 rounded-xl p-1 shadow-[0_0_25px_rgba(34,211,238,0.1)] overflow-hidden">
                   {selectedFile && selectedFile.type === 'file' ? (
                     <Editor
                        height="100%"
                        theme="vs-dark"
                        path={selectedFile.path}
                        language={getLanguage(selectedFile.name)}
                        value={activeFileContent}
                        onChange={(value) => { setActiveFileContent(value || ''); setIsDirty(true); }}
                        loading={<Spinner />}
                        options={{ minimap: { enabled: false } }}
                     />
                   ) : (
                    <div className="flex items-center justify-center h-full text-gray-500">
                        {isLoading ? <Spinner /> : 'Select a file to view or edit its content.'}
                    </div>
                   )}
                </div>
                {selectedFile && selectedFile.type === 'file' && (
                  <div className="bg-zinc-900/60 backdrop-blur-sm border border-cyan-500/20 rounded-xl p-4 shadow-[0_0_25px_rgba(34,211,238,0.1)] space-y-3">
                     <input 
                        type="text" 
                        value={commitMessage} 
                        onChange={e => setCommitMessage(e.target.value)} 
                        placeholder="Commit message..."
                        className="w-full bg-zinc-950/70 border border-zinc-700 rounded-md p-2 text-gray-200 focus:ring-1 focus:ring-cyan-500"
                    />
                    {error && <p className="text-red-400 text-sm">{error}</p>}
                    <div className="flex justify-end">
                      <button onClick={handleSaveContent} disabled={!isDirty || isSaving} className="w-48 flex items-center justify-center px-4 py-2 bg-green-600 text-white font-semibold rounded-lg transition-all disabled:bg-zinc-600 disabled:cursor-not-allowed neon-glow neon-glow-green">
                          {isSaving ? <Spinner /> : `Commit "${selectedFile.name}"`}
                      </button>
                    </div>
                  </div>
                )}
            </div>
        </div>
      )}
    </div>
  );
};

export default CodeView;
