import React, { useState } from 'react';
import { OvertureData, PhaseConfig } from '../../types';
import { generateUserStories, refineUserStories } from '../../services/geminiService';
import Spinner from '../Spinner';

interface OvertureViewProps {
  config: PhaseConfig;
  data: OvertureData;
  onUpdate: (data: Partial<OvertureData>) => void;
  onNavigateToBlueprint: () => void;
}

const SuggestionIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
    </svg>
);

const ProceedIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3" />
    </svg>
);


const OvertureView: React.FC<OvertureViewProps> = ({ config, data, onUpdate, onNavigateToBlueprint }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [isRefining, setIsRefining] = useState(false);
  const [error, setError] = useState('');

  const handleGenerateStories = async () => {
    if (!data.vision) {
      setError('Please provide a project vision first.');
      return;
    }
    setIsLoading(true);
    setError('');
    try {
      const { stories, suggestions } = await generateUserStories(data.vision);
      onUpdate({ userStories: stories, suggestions });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleSuggestionClick = async (suggestion: string) => {
    if (suggestion.startsWith('[PROCEED]')) {
        onNavigateToBlueprint();
        return;
    }
    setIsRefining(true);
    setError('');
    try {
        const { stories, suggestions: newSuggestions } = await refineUserStories(data.vision, data.userStories, suggestion);
        onUpdate({ userStories: stories, suggestions: newSuggestions });
    } catch(err) {
        setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
        setIsRefining(false);
    }
  }

  return (
    <div className="space-y-8 animate-fade-in">
      <div>
        <h2 className="text-3xl font-bold text-white">{config.title}: <span className="text-purple-400">{config.subtitle}</span></h2>
        <p className="mt-2 text-gray-400 max-w-2xl">{config.description}</p>
      </div>

      <div className="bg-zinc-900/60 backdrop-blur-sm border border-purple-500/20 rounded-xl p-6 shadow-[0_0_25px_rgba(168,85,247,0.1)]">
        <label htmlFor="vision" className="block text-sm font-medium text-gray-300 mb-2">Project Vision</label>
        <textarea
          id="vision"
          value={data.vision}
          onChange={(e) => onUpdate({ vision: e.target.value })}
          rows={6}
          className="w-full bg-zinc-950/70 border border-zinc-700 rounded-md p-4 text-gray-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition focus:shadow-[0_0_10px_theme(colors.purple.500)]"
          placeholder="Describe the fundamental problem, target audience, and desired experience..."
        />
      </div>

      <div className="bg-zinc-900/60 backdrop-blur-sm border border-purple-500/20 rounded-xl p-6 shadow-[0_0_25px_rgba(168,85,247,0.1)]">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold text-white">User Stories</h3>
          <button
            onClick={handleGenerateStories}
            disabled={isLoading || isRefining}
            className="flex items-center justify-center px-4 py-2 bg-purple-600 text-white font-semibold rounded-lg transition-all disabled:bg-purple-900/50 disabled:cursor-not-allowed neon-glow neon-glow-purple"
          >
            {isLoading ? <Spinner /> : '✨ Generate with AI'}
          </button>
        </div>
        
        <div className="space-y-3 pl-4 border-l-2 border-purple-500/20 min-h-[8rem]">
          {data.userStories.length > 0 ? (
            data.userStories.map((story, index) => (
              <div key={index} className="bg-zinc-800/50 p-3 rounded-lg border border-purple-500/10 text-gray-300 italic animate-fade-in">
                "{story}"
              </div>
            ))
          ) : (
            <p className="text-gray-500 pt-2">AI-generated user stories will appear here.</p>
          )}
        </div>
      </div>
      
      { (data.suggestions || isRefining) &&
        <div className="bg-zinc-900/60 backdrop-blur-sm border border-purple-500/20 rounded-xl p-6 shadow-[0_0_25px_rgba(168,85,247,0.1)] animate-fade-in">
            <h3 className="text-xl font-semibold text-white mb-4">Next Actions</h3>
            {error && <p className="text-red-400 text-sm mb-4">{error}</p>}
            {isRefining && <div className="flex justify-center p-4"><Spinner /></div> }
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                { !isRefining && data.suggestions?.map((suggestion, index) => {
                    const isProceed = suggestion.startsWith('[PROCEED]');
                    const buttonText = isProceed ? suggestion.replace('[PROCEED]', '').trim() : suggestion;

                    return (
                        <button key={index}
                            onClick={() => handleSuggestionClick(suggestion)}
                            disabled={isLoading || isRefining}
                            className={`flex items-center justify-center text-center p-3 rounded-lg transition-all text-sm font-semibold disabled:opacity-50 disabled:cursor-not-allowed neon-glow
                            ${isProceed 
                                ? 'bg-green-500/20 text-green-300 hover:bg-green-500/30 col-span-1 md:col-span-3 neon-glow-green' 
                                : 'bg-blue-500/20 text-blue-300 hover:bg-blue-500/30 neon-glow-blue'}`
                            }
                        >
                           {isProceed ? <ProceedIcon /> : <SuggestionIcon /> } {buttonText}
                        </button>
                    )
                })}
            </div>
        </div>
      }
    </div>
  );
};

export default OvertureView;