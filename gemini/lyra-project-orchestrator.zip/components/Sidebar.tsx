import React, { useRef, useCallback, useEffect } from 'react';
import { PhaseKey, PhaseConfig } from '../types';

interface SidebarProps {
  phases: Record<PhaseKey, PhaseConfig>;
  activePhase: PhaseKey;
  onSelectPhase: (phase: PhaseKey) => void;
  onExport: () => void;
  onImport: () => void;
  width: number;
  onResize: (newWidth: number) => void;
}

const DownloadIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
    </svg>
);

const UploadIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
    </svg>
);


const Sidebar: React.FC<SidebarProps> = ({ phases, activePhase, onSelectPhase, onExport, onImport, width, onResize }) => {
  const sidebarRef = useRef<HTMLElement>(null);
  const isResizing = useRef(false);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!isResizing.current) return;
    const newWidth = Math.max(280, Math.min(e.clientX, 600)); // Clamp width
    onResize(newWidth);
  }, [onResize]);

  const handleMouseUp = useCallback(() => {
    isResizing.current = false;
    document.removeEventListener('mousemove', handleMouseMove);
    document.removeEventListener('mouseup', handleMouseUp);
    document.body.style.userSelect = '';
    document.body.style.cursor = '';
  }, [handleMouseMove]);
  
  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    isResizing.current = true;
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    document.body.style.userSelect = 'none';
    document.body.style.cursor = 'col-resize';
  }, [handleMouseMove, handleMouseUp]);

  return (
    <aside 
      ref={sidebarRef}
      style={{ width: `${width}px` }}
      className="bg-zinc-900/80 backdrop-blur-md border-r border-purple-500/30 flex flex-col fixed h-full"
    >
      <div 
        onMouseDown={handleMouseDown}
        className="absolute top-0 right-0 h-full w-2 cursor-col-resize z-10 group"
      >
        <div className="w-0.5 h-full bg-yellow-300/30 group-hover:bg-yellow-300 transition-all mx-auto group-hover:shadow-[0_0_10px_theme(colors.yellow.300)]"></div>
      </div>
      
      <div className="p-6 pb-2">
        <h1 className="text-3xl font-bold text-purple-400 tracking-wider mb-2" style={{textShadow: '0 0 8px rgba(168, 85, 247, 0.7)'}}>LYRA</h1>
        <p className="text-gray-400 text-sm mb-2">Let the composition begin.</p>
      </div>

      <div className="flex-grow my-2 overflow-y-auto px-6 space-y-2">
        {(Object.keys(phases) as PhaseKey[]).map((key) => {
          const phase = phases[key];
          const isActive = activePhase === phase.key;
          return (
            <button
              key={phase.key}
              onClick={() => onSelectPhase(phase.key)}
              className={`w-full flex items-center space-x-4 p-3 rounded-lg text-left transition-all duration-300 ${
                isActive
                  ? 'bg-purple-500/20 text-white shadow-[inset_0_0_10px_rgba(168,85,247,0.2),0_0_15px_rgba(168,85,247,0.3)] border border-purple-400/50'
                  : 'text-gray-400 hover:bg-zinc-800/80 hover:text-purple-300 transform hover:-translate-y-px'
              }`}
            >
              <div className={`p-2 rounded-lg transition-all duration-300 ${isActive ? 'bg-purple-500 text-white' : 'bg-zinc-700 text-gray-300 group-hover:bg-purple-500/20'}`}>
                {phase.icon}
              </div>
              <div>
                <p className="font-semibold">{phase.title}</p>
                <p className="text-xs text-gray-500">{phase.subtitle}</p>
              </div>
            </button>
          );
        })}
      </div>

      <div className="flex-shrink-0 px-6 pb-6 pt-2 border-t border-purple-500/30 space-y-2">
        <button
          onClick={onImport}
          className="w-full flex items-center justify-center space-x-2 p-3 rounded-lg transition-colors duration-200 text-gray-300 hover:bg-zinc-800/60 hover:text-white neon-glow"
          aria-label="Import project document"
        >
          <UploadIcon />
          <span className="font-semibold">Import Document</span>
        </button>
        <button
          onClick={onExport}
          className="w-full flex items-center justify-center space-x-2 p-3 rounded-lg transition-colors duration-200 text-gray-300 hover:bg-zinc-800/60 hover:text-white neon-glow"
          aria-label="Export project to Markdown"
        >
          <DownloadIcon />
          <span className="font-semibold">Export Project</span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;