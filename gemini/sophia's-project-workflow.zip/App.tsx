import React, { useState } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { WORKFLOW_DATA, PRINCIPLES_DATA } from './constants';
import type { WorkflowPhase, ChecklistState } from './types';
import Header from './components/Header';
import WorkflowPhaseCard from './components/WorkflowPhaseCard';
import PrinciplesCard from './components/PrinciplesCard';
import ChecklistModal from './components/ChecklistModal';

// This guard is for development environments where process.env might not be defined.
// In a production/Vercel environment, process.env.API_KEY is expected to be set.
const apiKey = process.env.API_KEY;
if (!apiKey) {
  console.warn("API_KEY environment variable not set. AI features will be disabled.");
}
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

const App: React.FC = () => {
  const [openPhases, setOpenPhases] = useState<Set<number>>(new Set([0]));
  const [modalPhase, setModalPhase] = useState<WorkflowPhase | null>(null);
  const [checklistState, setChecklistState] = useState<ChecklistState>({
    loading: false,
    items: [],
    error: null,
  });

  const togglePhase = (phaseIndex: number) => {
    setOpenPhases(prev => {
      const newOpenPhases = new Set(prev);
      if (newOpenPhases.has(phaseIndex)) {
        newOpenPhases.delete(phaseIndex);
      } else {
        newOpenPhases.add(phaseIndex);
      }
      return newOpenPhases;
    });
  };

  const handleGenerateChecklist = async (phase: WorkflowPhase) => {
    if (!ai) {
      setModalPhase(phase);
      setChecklistState({
        loading: false,
        items: ['AI features are disabled. Please set the API_KEY environment variable.'],
        error: "API Key not configured."
      });
      return;
    }

    setModalPhase(phase);
    setChecklistState({ loading: true, items: [], error: null });

    try {
      const prompt = `You are a helpful and expert project management assistant. For the software development phase titled "${phase.title}", with the objective "${phase.objective}", generate a concise and actionable checklist of 5 to 7 key tasks. Base the tasks on these primary activities: ${phase.activities.join('; ')}. The checklist should be composed of clear, actionable items that a project manager or developer would perform.`;
      
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.STRING,
              description: 'A single actionable checklist item.'
            }
          }
        }
      });
      
      const checklistItems = JSON.parse(response.text);
      setChecklistState({ loading: false, items: checklistItems, error: null });

    } catch (err) {
      console.error("Gemini API Error:", err);
      setChecklistState({
        loading: false,
        items: [],
        error: 'Failed to generate checklist. The model may be overloaded. Please try again later.'
      });
    }
  };

  const handleCloseModal = () => {
    setModalPhase(null);
    // Reset checklist state for next time
    setChecklistState({ loading: false, items: [], error: null });
  };

  const handleAddChecklistItem = (newItem: string) => {
    setChecklistState(prev => ({
      ...prev,
      items: [...prev.items, newItem],
    }));
  };

  return (
    <div className="min-h-screen text-gray-200 font-sans">
      <main className="max-w-4xl mx-auto p-4 sm:p-6 md:p-8">
        <Header />
        <div className="mt-12 space-y-4">
          {WORKFLOW_DATA.map((phase, index) => (
            <WorkflowPhaseCard
              key={phase.phase}
              phaseData={phase}
              isOpen={openPhases.has(index)}
              onToggle={() => togglePhase(index)}
              onGenerateChecklist={() => handleGenerateChecklist(phase)}
            />
          ))}
        </div>
        <div className="mt-12">
           <PrinciplesCard principles={PRINCIPLES_DATA} />
        </div>
         <footer className="text-center py-8 mt-8 text-gray-500 text-sm">
            <p>SOPHIA (Systematic Operations & Planning Heuristic Intelligence Agent) at your service.</p>
        </footer>
      </main>

      <ChecklistModal
        isOpen={!!modalPhase}
        onClose={handleCloseModal}
        phase={modalPhase}
        checklistState={checklistState}
        onAddItem={handleAddChecklistItem}
      />
    </div>
  );
};

export default App;