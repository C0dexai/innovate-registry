
import type { WorkflowPhase, Principle } from './types';

export const WORKFLOW_DATA: WorkflowPhase[] = [
  {
    phase: 0,
    title: "Vision & Scoping",
    subtitle: "The 'Why' and 'What'",
    objective: "Establish the project's core purpose, high-level objectives, and initial boundaries.",
    activities: [
      "Problem Definition: Clearly articulate the problem the software aims to solve.",
      "Stakeholder Identification: List key individuals and groups with vested interests.",
      "High-Level Requirements Gathering: Conduct preliminary interviews/workshops to understand essential functionalities.",
      "Goal Setting (SMART): Define Specific, Measurable, Achievable, Relevant, Time-bound goals.",
      "Initial Scope Definition: Delineate what is IN and OUT of scope for the first major release.",
      "Success Metrics: Determine how the project's success will be measured."
    ]
  },
  {
    phase: 1,
    title: "Deep Dive & Blueprinting",
    subtitle: "The 'How'",
    objective: "Translate the high-level vision into detailed, actionable plans and initial architectural designs.",
    activities: [
      "Detailed Requirements & User Stories: Flesh out functional and non-functional requirements.",
      "System Architecture Design: Define the overall structure, technologies, and major components.",
      "Database Design: Plan the data models and relationships.",
      "User Experience (UX) & User Interface (UI) Design: Create wireframes, mockups, and prototypes.",
      "Technical Stack Selection: Finalize the programming languages, frameworks, and tools.",
      "Risk Assessment & Mitigation Planning: Identify potential roadblocks and plan for them."
    ]
  },
  {
    phase: 2,
    title: "Iterative Development & Integration",
    subtitle: "The 'Build'",
    objective: "Systematically construct the software in manageable, iterative cycles.",
    activities: [
      "Sprint Planning (Agile Focus): Break down features into smaller tasks for time-boxed sprints.",
      "Feature Development: Code, implement, and unit test individual components.",
      "Continuous Integration (CI): Regularly merge code changes into a central repository.",
      "Automated Testing Setup: Implement unit, integration, and potentially API tests.",
      "Regular Stand-ups/Check-ins: Foster consistent communication within the development team."
    ]
  },
  {
    phase: 3,
    title: "Quality Assurance & Validation",
    subtitle: "The 'Verify'",
    objective: "Rigorously test the software to ensure it meets requirements and is free of critical defects.",
    activities: [
      "Test Case Creation: Develop comprehensive test cases based on requirements.",
      "Functional Testing: Verify that all features work as intended.",
      "Non-Functional Testing: Conduct performance, security, usability, and compatibility testing.",
      "User Acceptance Testing (UAT): Involve stakeholders to confirm the software meets their business needs.",
      "Defect Tracking & Resolution: Log, prioritize, and manage bug fixes."
    ]
  },
  {
    phase: 4,
    title: "Deployment & Monitoring",
    subtitle: "The 'Launch' and 'Observe'",
    objective: "Release the software to its intended environment and ensure its stable operation.",
    activities: [
      "Deployment Planning: Outline the deployment strategy, tools, and rollback procedures.",
      "Production Deployment: Execute the deployment, often automated.",
      "Post-Launch Monitoring: Track system performance, errors, and user behavior.",
      "Incident Management: Establish protocols for addressing issues in the live environment.",
      "User Training & Support Documentation: Prepare resources for end-users."
    ]
  },
  {
    phase: 5,
    title: "Continuous Refinement & Evolution",
    subtitle: "The 'Improve'",
    objective: "Gather feedback, analyze performance, and plan future iterations and enhancements.",
    activities: [
      "Feedback Collection: Solicit input from users and stakeholders.",
      "Performance Review: Analyze metrics and system health.",
      "Feature Backlog Management: Prioritize future features and improvements.",
      "Regular Updates & Maintenance: Apply security patches, optimize performance, and release new versions."
    ]
  }
];

export const PRINCIPLES_DATA: Principle[] = [
    {
        name: "Communication",
        description: "Consistent, clear, and open communication channels across all stakeholders."
    },
    {
        name: "Documentation",
        description: "Maintain up-to-date documentation for requirements, design, code, and deployment."
    },
    {
        name: "Iteration & Feedback",
        description: "Embrace an iterative approach, allowing for continuous feedback and adaptation."
    },
    {
        name: "Version Control",
        description: "Utilize robust version control systems for all code and relevant assets."
    },
    {
        name: "Automation",
        description: "Automate repetitive tasks (testing, deployment) where possible."
    }
];
