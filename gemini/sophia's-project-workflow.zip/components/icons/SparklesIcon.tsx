import React from 'react';

const SparklesIcon: React.FC = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    className="h-5 w-5"
    viewBox="0 0 20 20"
    fill="currentColor"
    aria-hidden="true"
  >
    <path
      fillRule="evenodd"
      d="M10 3a1 1 0 011 1v2a1 1 0 11-2 0V4a1 1 0 011-1zM5.5 5.5a1 1 0 011.414 0l1.414 1.414a1 1 0 01-1.414 1.414L5.5 6.914a1 1 0 010-1.414zM14.5 5.5a1 1 0 00-1.414 0l-1.414 1.414a1 1 0 001.414 1.414L14.5 6.914a1 1 0 000-1.414zM10 17a1 1 0 01-1-1v-2a1 1 0 112 0v2a1 1 0 01-1 1zM5.5 14.5a1 1 0 00-1.414 0l-1.414-1.414a1 1 0 001.414-1.414l1.414 1.414a1 1 0 000 1.414zM14.5 14.5a1 1 0 011.414 0l1.414-1.414a1 1 0 01-1.414-1.414L14.5 13.086a1 1 0 010 1.414z"
      clipRule="evenodd"
    />
  </svg>
);

export default SparklesIcon;
