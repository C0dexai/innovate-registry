import React from 'react';
import type { WorkflowPhase } from '../types';
import ChevronDownIcon from './icons/ChevronDownIcon';
import SparklesIcon from './icons/SparklesIcon';

interface WorkflowPhaseCardProps {
  phaseData: WorkflowPhase;
  isOpen: boolean;
  onToggle: () => void;
  onGenerateChecklist: () => void;
}

const WorkflowPhaseCard: React.FC<WorkflowPhaseCardProps> = ({ phaseData, isOpen, onToggle, onGenerateChecklist }) => {
  return (
    <div className="bg-gray-900/60 backdrop-blur-sm border border-purple-500/30 rounded-xl shadow-lg transition-all duration-300 ease-in-out hover:border-purple-500/60 hover:shadow-xl hover:shadow-purple-500/20">
      <button
        onClick={onToggle}
        className="w-full flex justify-between items-center p-5 sm:p-6 text-left"
        aria-expanded={isOpen}
      >
        <div className="flex items-center space-x-4">
          <div className="flex-shrink-0 bg-gray-800 text-cyan-400 font-bold text-lg rounded-lg w-12 h-12 flex items-center justify-center">
            {phaseData.phase}
          </div>
          <div>
            <h3 className="text-lg sm:text-xl font-bold text-gray-100">{phaseData.title}</h3>
            <p className="text-sm text-gray-400">{phaseData.subtitle}</p>
          </div>
        </div>
        <ChevronDownIcon isOpen={isOpen} />
      </button>
      <div
        className={`grid transition-all duration-500 ease-in-out ${
          isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'
        }`}
      >
        <div className="overflow-hidden">
          <div className="px-5 sm:px-6 pb-6 pt-2 border-t border-gray-700/50">
            <p className="text-gray-300 mb-4 font-medium italic">
              <span className="font-semibold text-cyan-400 not-italic">Objective:</span> {phaseData.objective}
            </p>
            <ul className="space-y-2 text-gray-400 list-disc list-inside">
              {phaseData.activities.map((activity, index) => (
                <li key={index} className="leading-relaxed">{activity}</li>
              ))}
            </ul>
            <div className="mt-6 flex justify-end">
              <button
                onClick={(e) => {
                  e.stopPropagation(); // Prevent card from toggling
                  onGenerateChecklist();
                }}
                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-bold text-black bg-cyan-400 rounded-md shadow-md shadow-cyan-400/40 hover:bg-cyan-300 hover:shadow-lg hover:shadow-cyan-400/60 transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-pink-500"
              >
                <SparklesIcon />
                Generate Checklist
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WorkflowPhaseCard;