import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="text-center">
        <div className="inline-block bg-gray-900/70 rounded-full p-3 mb-4 border border-cyan-500/50 shadow-lg shadow-cyan-500/50">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M12 6V3m0 18v-3M5.636 5.636l-1.414-1.414M19.778 19.778l-1.414-1.414M18.364 5.636l1.414-1.414M4.222 19.778l1.414-1.414M12 12a6 6 0 100-12 6 6 0 000 12z" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 12a3 3 0 100-6 3 3 0 000 6z" />
            </svg>
        </div>
      <h1 className="text-4xl sm:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-400">
        SOPHIA's Project Workflow
      </h1>
      <p className="mt-4 max-w-2xl mx-auto text-lg text-gray-400">
        A foundational framework designed to promote clarity, mitigate risks, and foster a predictable yet agile development cycle.
      </p>
    </header>
  );
};

export default Header;