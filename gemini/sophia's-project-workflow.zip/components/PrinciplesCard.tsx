import React from 'react';
import type { Principle } from '../types';
import CheckCircleIcon from './icons/CheckCircleIcon';

interface PrinciplesCardProps {
  principles: Principle[];
}

const PrinciplesCard: React.FC<PrinciplesCardProps> = ({ principles }) => {
  return (
    <div className="bg-gray-900/60 backdrop-blur-sm border border-green-500/30 rounded-xl shadow-xl shadow-green-500/10 p-6 sm:p-8">
      <h2 className="text-2xl font-bold text-gray-100 mb-6">Underlying Principles for Success</h2>
      <ul className="space-y-4">
        {principles.map((principle) => (
          <li key={principle.name} className="flex items-start space-x-3">
            <div className="flex-shrink-0 mt-1 text-green-400">
              <CheckCircleIcon />
            </div>
            <div>
              <h4 className="font-semibold text-gray-200">{principle.name}</h4>
              <p className="text-gray-400">{principle.description}</p>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default PrinciplesCard;