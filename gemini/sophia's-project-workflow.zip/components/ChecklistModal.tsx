import React, { useState, useEffect } from 'react';
import type { WorkflowPhase, ChecklistState } from '../types';
import CloseIcon from './icons/CloseIcon';
import SpinnerIcon from './icons/SpinnerIcon';

interface ChecklistModalProps {
  isOpen: boolean;
  onClose: () => void;
  phase: WorkflowPhase | null;
  checklistState: ChecklistState;
  onAddItem: (item: string) => void;
}

const ChecklistItem = ({ item }: { item: string }) => {
  const [isChecked, setIsChecked] = useState(false);

  return (
    <li className="flex items-start space-x-3 py-2 border-b border-gray-700/50 last:border-b-0">
      <input
        type="checkbox"
        id={`item-${item}`}
        checked={isChecked}
        onChange={() => setIsChecked(!isChecked)}
        className="mt-1 h-4 w-4 rounded border-gray-600 bg-gray-700 text-pink-500 focus:ring-pink-600 cursor-pointer"
      />
      <label htmlFor={`item-${item}`} className={`text-gray-300 transition-colors ${isChecked ? 'line-through text-gray-500' : ''}`}>
        {item}
      </label>
    </li>
  );
};

const ChecklistModal: React.FC<ChecklistModalProps> = ({ isOpen, onClose, phase, checklistState, onAddItem }) => {
  const [customItem, setCustomItem] = useState('');

  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [onClose]);

  if (!isOpen || !phase) return null;

  const handleAddCustomItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (customItem.trim()) {
      onAddItem(customItem.trim());
      setCustomItem('');
    }
  };

  return (
    <div
      className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="checklist-title"
    >
      <div
        className="bg-gray-900 border border-pink-500/50 rounded-xl shadow-2xl shadow-pink-500/20 w-full max-w-2xl max-h-[90vh] flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        <header className="flex justify-between items-center p-4 sm:p-5 border-b border-gray-700">
          <h2 id="checklist-title" className="text-xl font-bold text-gray-100">
            Checklist for: <span className="text-pink-400">{phase.title}</span>
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-pink-400 transition-colors"
            aria-label="Close modal"
          >
            <CloseIcon />
          </button>
        </header>

        <main className="p-4 sm:p-6 flex-grow overflow-y-auto">
          {checklistState.loading && (
            <div className="flex flex-col items-center justify-center h-48 text-pink-400">
              <SpinnerIcon />
              <p className="mt-4 text-gray-400">Generating your checklist...</p>
            </div>
          )}
          {checklistState.error && (
            <div className="flex flex-col items-center justify-center h-48 text-center">
              <p className="text-red-400 font-semibold">An Error Occurred</p>
              <p className="mt-2 text-gray-400">{checklistState.error}</p>
            </div>
          )}
          {!checklistState.loading && (
            <>
              <ul className="space-y-1">
                {checklistState.items.map((item, index) => (
                  <ChecklistItem key={`${item}-${index}`} item={item} />
                ))}
              </ul>

              <form onSubmit={handleAddCustomItem} className="mt-6">
                <label htmlFor="custom-item" className="block text-sm font-medium text-gray-300 mb-2">
                  Add a custom item
                </label>
                <div className="flex gap-2">
                  <input
                    id="custom-item"
                    type="text"
                    value={customItem}
                    onChange={(e) => setCustomItem(e.target.value)}
                    placeholder="E.g., 'Schedule kick-off meeting'"
                    className="flex-grow bg-gray-800 border border-gray-600 rounded-md px-3 py-2 text-gray-200 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-pink-500"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 bg-pink-500 text-black font-bold rounded-md hover:bg-pink-600 transition-colors disabled:bg-gray-700 disabled:text-gray-400 disabled:cursor-not-allowed"
                    disabled={!customItem.trim()}
                  >
                    Add
                  </button>
                </div>
              </form>
            </>
          )}
        </main>

        <footer className="p-4 border-t border-gray-700 text-right">
            <button
                onClick={onClose}
                className="px-4 py-2 bg-gray-700 text-gray-200 font-semibold rounded-md hover:bg-gray-600 transition-colors"
            >
                Done
            </button>
        </footer>
      </div>
    </div>
  );
};

export default ChecklistModal;