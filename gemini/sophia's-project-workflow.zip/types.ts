export interface WorkflowPhase {
  phase: number;
  title: string;
  subtitle: string;
  objective: string;
  activities: string[];
}

export interface Principle {
  name: string;
  description: string;
}

export interface ChecklistState {
  loading: boolean;
  items: string[];
  error: string | null;
}
