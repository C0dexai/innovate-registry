export interface Task {
  id: number;
  text: string;
  completed: boolean;
}

export enum ToolCategory {
  PROJECT_MANAGEMENT = 'Project Management',
  COMMUNICATION = 'Communication',
  CODE_REPOSITORY = 'Code Repository',
}

export interface Tool {
  name: string;
  category: ToolCategory;
}

export interface SelectedTools {
  [key:string]: boolean;
}

export type CliPreference = 'none' | 'gemini' | 'openai';

export interface ProjectState {
  scope: string;
  architecture: string;
  devEnv: string;
  aiIntegration: string;
  versionControl: {
    strategy: string;
    repoUrl: string;
  };
  selectedTools: SelectedTools;
  cliPreference: CliPreference;
}

export interface ConversationMessage {
  role: 'user' | 'model';
  text: string;
}

export interface ExampleProfile {
  name: string;
  description: string;
  state: ProjectState;
}
