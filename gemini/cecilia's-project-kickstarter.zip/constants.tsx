import { Tool, ToolCategory, ExampleProfile } from './types';

export const BRANCHING_STRATEGIES: string[] = ['Gitflow', 'Trunk-Based Development', 'GitHub Flow', 'GitLab Flow'];

export const TOOLS: Tool[] = [
  { name: 'Jira', category: ToolCategory.PROJECT_MANAGEMENT },
  { name: 'Trello', category: ToolCategory.PROJECT_MANAGEMENT },
  { name: 'Asana', category: ToolCategory.PROJECT_MANAGEMENT },
  { name: 'Linear', category: ToolCategory.PROJECT_MANAGEMENT },
  { name: 'Slack', category: ToolCategory.COMMUNICATION },
  { name: 'Microsoft Teams', category: ToolCategory.COMMUNICATION },
  { name: 'Discord', category: ToolCategory.COMMUNICATION },
  { name: 'GitHub', category: ToolCategory.CODE_REPOSITORY },
  { name: 'GitLab', category: ToolCategory.CODE_REPOSITORY },
  { name: 'Bitbucket', category: ToolCategory.CODE_REPOSITORY },
];

export const EXAMPLE_PROFILES: ExampleProfile[] = [
  {
    name: 'SaaS Project Manager',
    description: 'A B2B web app for team collaboration and task tracking.',
    state: {
      scope: 'A web app for small to medium-sized tech teams to manage tasks, sprints, and project timelines. The MVP will focus on creating projects, adding tasks with assignments and due dates, and a kanban board view.',
      architecture: 'A monolithic backend using Node.js/Express connected to a PostgreSQL database, serving a React (Vite) single-page application frontend. Communication via a REST API.',
      devEnv: 'Frontend: React, TypeScript, Tailwind CSS. Backend: Node.js, Express, PostgreSQL. Deployed on Heroku or similar PaaS.',
      aiIntegration: 'An AI assistant that can help users break down large tasks into smaller sub-tasks and suggest potential task dependencies based on project context.',
      versionControl: { strategy: 'GitHub Flow', repoUrl: 'https://github.com/example/saas-pm' },
      selectedTools: { 'Jira': true, 'Slack': true, 'GitHub': true },
      cliPreference: 'none',
    },
  },
  {
    name: 'Mobile Fitness Game',
    description: 'A B2C mobile app that gamifies exercise routines.',
    state: {
      scope: 'A mobile application for iOS and Android targeting young adults (18-30) who want to make fitness fun. MVP includes daily workout challenges, a point/leveling system, and social sharing of achievements.',
      architecture: 'A serverless backend (e.g., Firebase or AWS Lambda) to handle user data, authentication, and game logic. The frontend will be a cross-platform mobile app built with React Native.',
      devEnv: 'React Native, TypeScript, Firebase (Auth, Firestore, Functions). App Store and Google Play for distribution.',
      aiIntegration: 'Use AI to generate personalized weekly workout plans based on the user\'s performance, stated goals, and feedback. The AI will adapt the difficulty to keep users engaged but not overwhelmed.',
      versionControl: { strategy: 'Gitflow', repoUrl: 'https://github.com/example/fitness-game' },
      selectedTools: { 'Trello': true, 'Discord': true, 'GitHub': true },
      cliPreference: 'gemini',
    },
  },
  {
    name: 'AI Content Creation Tool',
    description: 'A desktop app for creators to generate text and images.',
    state: {
      scope: 'A desktop application (using Electron) for bloggers, marketers, and social media managers. The MVP will allow users to provide a topic and receive a draft blog post, and also generate royalty-free images based on text prompts.',
      architecture: 'An Electron shell for the cross-platform UI, which communicates with a set of cloud-based microservices for the heavy AI processing (text and image generation). This keeps the desktop app lightweight.',
      devEnv: 'Electron, React, TypeScript, Tailwind CSS. Backend services written in Python (FastAPI) to interface with AI models. Docker for containerization.',
      aiIntegration: 'Core functionality is AI. It will use a large language model for text generation (e.g., Gemini) and an image generation model (e.g., Imagen). The AI plan involves fine-tuning models for specific content styles.',
      versionControl: { strategy: 'Trunk-Based Development', repoUrl: 'https://github.com/example/ai-creator-tool' },
      selectedTools: { 'Linear': true, 'Slack': true, 'GitHub': true },
      cliPreference: 'openai',
    },
  },
];
