import React, { useState, useCallback, useEffect, useRef } from 'react';
import { Task, CliPreference, ProjectState, ConversationMessage, SelectedTools, ExampleProfile } from './types';
import { BRANCHING_STRATEGIES, TOOLS, EXAMPLE_PROFILES } from './constants';
import { startChatSession, continueChatSession, generateSuggestion } from './services/geminiService';
import type { Chat } from "@google/genai";
import type { ParsedAiResponse } from './services/geminiService';
import ToolSelector from './components/ToolSelector';
import TaskList from './components/TaskList';
import ContextColumn from './components/ContextColumn';
import CliOutput from './components/CliOutput';
import ProfileManager from './components/ProfileManager';
import Conversation from './components/Conversation';
import Dropdown from './components/Dropdown';
import { SparklesIcon, CircleSpinner, UserIcon, CogIcon, TerminalIcon, LightBulbIcon } from './components/icons';

const getInitialProjectState = (): ProjectState => ({
  scope: '',
  architecture: '',
  devEnv: '',
  aiIntegration: '',
  versionControl: { strategy: BRANCHING_STRATEGIES[0], repoUrl: '' },
  selectedTools: {},
  cliPreference: 'none',
});

type HintableField = 'scope' | 'architecture' | 'devEnv' | 'aiIntegration';

const ResizeHandle: React.FC<{ onMouseDown: (event: React.MouseEvent) => void }> = ({ onMouseDown }) => (
    <div
        className="w-2.5 h-full cursor-col-resize flex items-center justify-center group"
        onMouseDown={onMouseDown}
    >
        <div className="w-1 h-full bg-yellow-400/30 group-hover:bg-yellow-400/80 transition-colors duration-200 rounded-full group-hover:shadow-[0_0_10px_theme(colors.yellow.400)]"></div>
    </div>
);

const GlowingFooter: React.FC = () => {
    const [isFlipped, setIsFlipped] = useState(false);

    useEffect(() => {
        const timer = setTimeout(() => setIsFlipped(true), 300);
        return () => clearTimeout(timer);
    }, []);

    return (
        <footer className="mt-8 flex justify-center" style={{ perspective: '800px' }}>
            <div
                className={`
                    origin-top transition-transform duration-1000 [transform-style:preserve-3d]
                    ${isFlipped ? 'rotate-x-0' : 'rotate-x-[-90deg]'}
                `}
            >
                <div className="relative p-0.5 rounded-lg bg-gradient-to-r from-fuchsia-500 via-purple-500 to-cyan-400 shadow-[0_0_15px_rgba(192,132,252,0.4),0_0_25px_rgba(34,211,238,0.2)]">
                    <div className="px-6 py-2 bg-zinc-950 rounded-md">
                        <p className="text-zinc-400 font-medium">
                            Built with inspiration from <span className="font-bold bg-clip-text text-transparent bg-gradient-to-r from-fuchsia-400 to-cyan-300">CECILIA</span>'s workflow.
                        </p>
                    </div>
                </div>
            </div>
        </footer>
    );
};


const App: React.FC = () => {
  const [projectState, setProjectState] = useState<ProjectState>(getInitialProjectState());
  const { scope, architecture, devEnv, aiIntegration, versionControl, selectedTools, cliPreference } = projectState;
  
  const [tasks, setTasks] = useState<Task[]>([]);
  const [cliScript, setCliScript] = useState<string>('');
  const [isAiBusy, setIsAiBusy] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const [profiles, setProfiles] = useState<Record<string, ProjectState>>({});
  const [profileName, setProfileName] = useState<string>('');
  const [currentProfile, setCurrentProfile] = useState<string | null>(null);

  const [chat, setChat] = useState<Chat | null>(null);
  const [conversation, setConversation] = useState<ConversationMessage[]>([]);
  const [suggestions, setSuggestions] = useState<string[]>([]);

  const [visibleHints, setVisibleHints] = useState<Record<string, boolean>>({});
  const [hintContent, setHintContent] = useState<Record<string, string>>({});
  const [isHintLoading, setIsHintLoading] = useState<Record<string, boolean>>({});
  
  const [columnWidths, setColumnWidths] = useState<number[]>([34, 33, 33]);
  const isResizing = useRef<number | null>(null);
  const mainContainerRef = useRef<HTMLDivElement>(null);


  useEffect(() => {
    try {
      const savedProfiles = localStorage.getItem('project-kickstarter-profiles');
      if (savedProfiles) {
        setProfiles(JSON.parse(savedProfiles));
      }
    } catch (e) {
      console.error("Failed to load profiles from localStorage", e);
    }
  }, []);
  
  const resetOutputs = useCallback(() => {
    setTasks([]);
    setCliScript('');
    setError(null);
    setChat(null);
    setConversation([]);
    setSuggestions([]);
  }, []);

  const updateProjectState = useCallback((update: Partial<ProjectState> | ((prevState: ProjectState) => Partial<ProjectState>)) => {
    setProjectState(prev => ({ ...prev, ...(typeof update === 'function' ? update(prev) : update) }));
    setCurrentProfile(null); 
  }, []);

  const handleToolToggle = useCallback((toolName: string) => {
    updateProjectState(prev => ({
      selectedTools: { ...prev.selectedTools, [toolName]: !prev.selectedTools[toolName] }
    }));
  }, [updateProjectState]);

  const handleAddTask = useCallback((text: string) => {
    setTasks(prev => [...prev, { id: Date.now(), text, completed: false }]);
  }, []);

  const handleToggleTask = useCallback((id: number) => {
    setTasks(prev => prev.map(task => task.id === id ? { ...task, completed: !task.completed } : task));
  }, []);

  const handleDeleteTask = useCallback((id: number) => {
    setTasks(prev => prev.filter(task => task.id !== id));
  }, []);
  
  const processAiResponse = (response: ParsedAiResponse) => {
    if (response.userStories) {
      const newTasks: Task[] = response.userStories.map((text, index) => ({
        id: Date.now() + index,
        text,
        completed: false
      }));
      setTasks(newTasks);
    }
    
    if (response.architecture || response.devEnv || response.suggestedTools) {
      updateProjectState(prev => {
        const updatedState: Partial<ProjectState> = {};
        if (response.architecture && !prev.architecture) updatedState.architecture = response.architecture;
        if (response.devEnv && !prev.devEnv) updatedState.devEnv = response.devEnv;

        if (response.suggestedTools) {
          const freshSelection: SelectedTools = {};
          response.suggestedTools.forEach(toolName => {
              if (TOOLS.some(t => t.name === toolName)) {
                 freshSelection[toolName] = true;
              }
          });
          updatedState.selectedTools = freshSelection;
        }
        return updatedState;
      });
    }

    setConversation(prev => [...prev, { role: 'model', text: response.responseText }]);
    setSuggestions(response.followUpSuggestions);
  };

  const handleStartConversation = useCallback(async () => {
    if (!scope.trim()) {
      setError("Please define the user persona and MVP first.");
      return;
    }
    setIsAiBusy(true);
    setError(null);
    resetOutputs();

    try {
      const { chat: newChat, response } = await startChatSession(scope, architecture, devEnv, aiIntegration);
      setChat(newChat);
      processAiResponse(response);
    } catch (err) {
      setError(err instanceof Error ? err.message : "An unknown error occurred.");
    } finally {
      setIsAiBusy(false);
    }
  }, [scope, architecture, devEnv, aiIntegration, resetOutputs]);

  const handleAiInteraction = useCallback(async (message: string, userFacingMessage?: string) => {
    if (isAiBusy) return;
    if (!chat) {
        setError("Please generate user stories first to start a conversation.");
        return;
    }

    setIsAiBusy(true);
    setError(null);
    setSuggestions([]);
    setConversation(prev => [...prev, { role: 'user', text: userFacingMessage || message }]);

    try {
        const response = await continueChatSession(chat, message);
        processAiResponse(response);
    } catch (err) {
        setError(err instanceof Error ? err.message : "An unknown error occurred.");
    } finally {
        setIsAiBusy(false);
    }
  }, [chat, isAiBusy]);

  const handleSuggestBlueprint = useCallback(() => {
    const toolList = TOOLS.map(t => t.name).join(', ');
    const detailedMessage = `Taking my project scope ("${scope}") and existing system info into account, please act as a solutions architect. Suggest a "Core Architecture" and "Tech Stack / Dev Environment". Only populate the 'architecture' and 'devEnv' fields if they are currently empty. Also, from the following list of tools, please suggest which ones would be appropriate by listing their names in the 'suggestedTools' field: [${toolList}]. Provide your reasoning in the 'responseText'.`;
    const userMessage = "Suggest a system blueprint for me.";
    handleAiInteraction(detailedMessage, userMessage);
  }, [scope, handleAiInteraction]);


  const handleSaveProfile = useCallback(() => {
    if (!profileName.trim()) return;
    const newProfiles = { ...profiles, [profileName]: projectState };
    setProfiles(newProfiles);
    setCurrentProfile(profileName);
    localStorage.setItem('project-kickstarter-profiles', JSON.stringify(newProfiles));
  }, [profileName, projectState, profiles]);

  const handleLoadProfile = useCallback((name: string) => {
    if (profiles[name]) {
      setProjectState(profiles[name]);
      setProfileName(name);
      setCurrentProfile(name);
      resetOutputs();
    }
  }, [profiles, resetOutputs]);

  const handleDeleteProfile = useCallback((name: string) => {
    const newProfiles = { ...profiles };
    delete newProfiles[name];
    setProfiles(newProfiles);
    localStorage.setItem('project-kickstarter-profiles', JSON.stringify(newProfiles));
    if (currentProfile === name) {
      setProjectState(getInitialProjectState());
      setCurrentProfile(null);
      setProfileName('');
      resetOutputs();
    }
  }, [profiles, currentProfile, resetOutputs]);
  
  const handleLoadTemplate = useCallback((state: ProjectState) => {
      setProjectState(state);
      setCurrentProfile(null);
      resetOutputs();
  }, [resetOutputs]);

  const handleGenerateCliScript = useCallback(() => {
    let script = `#!/bin/bash
# Auto-generated setup script by CECILIA's Project Kickstarter
# This script provides suggestions. Review and adapt it to your needs.

# --- Environment Setup ---
echo "Setting up environment..."
# Ensure API keys are set as environment variables.
# For Gemini, you might use:
# export GOOGLE_API_KEY="YOUR_GEMINI_API_KEY"
# For OpenAI, you would use:
# export OPENAI_API_KEY="YOUR_OPENAI_API_KEY"
`;

    script += `\n# --- Version Control Setup ---
echo "Initializing Git repository..."
git init
git branch -m main
`;
    if (versionControl.strategy === 'Gitflow') {
        script += `# Gitflow requires a separate installation. Assuming it's installed.
git flow init -d
`;
    }
    if (versionControl.repoUrl.trim()) {
        script += `git remote add origin ${versionControl.repoUrl.trim()}\n`;
    }
    script += `echo "# ${scope.split('\n')[0] || 'My New Project'}" > README.md
git add .
git commit -m "Initial commit: Project setup"
echo "Git repository initialized."
`;

    if (devEnv.trim()) {
        script += `\n# --- Development Environment (Suggestions) ---
echo "Setting up development environment based on your description..."
# The following are suggested commands based on your input: "${devEnv}"
# You may need to adjust them for your package manager (npm, yarn, pnpm).
`;
        const lowerDevEnv = devEnv.toLowerCase();
        if (lowerDevEnv.includes('react') || lowerDevEnv.includes('vite')) {
            script += '# Example for React + Vite: npm create vite@latest my-react-app -- --template react-ts\n';
        }
        if (lowerDevEnv.includes('node') || lowerDevEnv.includes('express')) {
            script += '# Example for Node.js: npm init -y && npm install express\n';
        }
        if (lowerDevEnv.includes('tailwind')) {
            script += '# Example for Tailwind CSS: npm install -D tailwindcss postcss autoprefixer && npx tailwindcss init -p\n';
        }
    }
    
    if (cliPreference === 'gemini') {
        script += `\n# --- Google Cloud & Gemini CLI Setup ---
echo "Configuring for Google Cloud and Gemini..."
# 1. Make sure you have the Google Cloud SDK (gcloud) installed.
# 2. Authenticate with Google Cloud:
# gcloud auth application-default login
# 3. Enable the Vertex AI API in your Google Cloud project:
# gcloud services enable aiplatform.googleapis.com --project YOUR_PROJECT_ID
# 4. Example curl to test the Gemini API (replace with your project ID and model):
# curl -X POST -H "Authorization: Bearer $(gcloud auth application-default print-access-token)" -H "Content-Type: application/json" https://us-central1-aiplatform.googleapis.com/v1/projects/YOUR_PROJECT_ID/locations/us-central1/publishers/google/models/gemini-2.5-flash:generateContent -d '{ "contents": [{"role": "user", "parts": [{"text": "Why is the sky blue?"}]}] }'
`;
    }

    if (cliPreference === 'openai') {
        script += `\n# --- OpenAI CLI Setup ---
echo "Configuring for OpenAI..."
# 1. Make sure you have Python and pip installed.
# 2. Install the OpenAI Python library:
# pip install openai
# 3. Set your API key as an environment variable:
# export OPENAI_API_KEY='YOUR_OPENAI_API_KEY'
# 4. Example using the OpenAI CLI (if installed via 'pip install openai'):
# openai api chat.completions.create -m gpt-4 -g "Why is the sky blue?"
# 5. Example Python script 'test_openai.py':
# echo '
# from openai import OpenAI
# client = OpenAI()
# response = client.chat.completions.create(
#   model="gpt-4",
#   messages=[{"role": "user", "content": "Why is the sky blue?"}]
# )
# print(response.choices[0].message.content)
# ' > test_openai.py
# python test_openai.py
`;
    }

    const selectedToolNames = Object.keys(selectedTools).filter(key => selectedTools[key]);
    if (selectedToolNames.length > 0) {
        script += `\n# --- Tooling Notes ---
# You've selected the following tools: ${selectedToolNames.join(', ')}.
# Remember to configure their respective CLIs or SDKs (e.g., 'gh', 'linear', 'jira').\n`
    }
    
    script += `\n# --- End of Script ---
echo "Setup script finished. Please review and run commands manually."
`;

    setCliScript(script);
  }, [projectState]);
  
  const handleMouseDown = useCallback((index: number) => {
    isResizing.current = index;
    document.body.style.cursor = 'col-resize';
  }, []);

  const handleMouseUp = useCallback(() => {
    isResizing.current = null;
    document.body.style.cursor = 'default';
  }, []);

  const handleMouseMove = useCallback((event: MouseEvent) => {
    if (isResizing.current === null || !mainContainerRef.current) return;

    const container = mainContainerRef.current;
    const containerRect = container.getBoundingClientRect();
    const dividers = container.querySelectorAll('.w-2\\.5');
    const dividerWidth = dividers.length > 0 ? (dividers[0] as HTMLElement).offsetWidth : 10;
    
    setColumnWidths(prevWidths => {
      const newWidths = [...prevWidths];
      const index = isResizing.current!;
      const totalWidth = 100;
      
      const mouseX = event.clientX - containerRect.left;
      let leftWidthsPercent = 0;
      for (let i = 0; i < index + 1; i++) {
        leftWidthsPercent += newWidths[i];
      }

      const leftWidthsPixels = (leftWidthsPercent / totalWidth) * (containerRect.width - (newWidths.length -1) * dividerWidth);
      const delta = mouseX - leftWidthsPixels - (index * dividerWidth);
      let dxPercent = (delta / (containerRect.width - (newWidths.length - 1) * dividerWidth)) * totalWidth;

      const minWidthPercent = 15;
      if (newWidths[index] + dxPercent < minWidthPercent) {
        dxPercent = minWidthPercent - newWidths[index];
      }
      if (newWidths[index + 1] - dxPercent < minWidthPercent) {
        dxPercent = newWidths[index+1] - minWidthPercent;
      }
      
      newWidths[index] += dxPercent;
      newWidths[index + 1] -= dxPercent;

      return newWidths;
    });
  }, []);


  useEffect(() => {
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [handleMouseMove, handleMouseUp]);


  const toggleHintVisibility = (field: HintableField) => {
    setVisibleHints(prev => ({ ...prev, [field]: !prev[field] }));
  };

  const handleGetHint = async (field: HintableField) => {
    setIsHintLoading(prev => ({ ...prev, [field]: true }));
    setError(null);
    try {
      const suggestion = await generateSuggestion(field, projectState);
      setHintContent(prev => ({ ...prev, [field]: suggestion }));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't get suggestion.");
    } finally {
      setIsHintLoading(prev => ({ ...prev, [field]: false }));
    }
  };

  const handleUseHint = (field: HintableField) => {
    if (hintContent[field]) {
      updateProjectState({ [field]: hintContent[field] });
      setVisibleHints(prev => ({ ...prev, [field]: false }));
    }
  };
  
  const renderHint = (field: HintableField) => {
    return (
        <div className="p-3 bg-zinc-950/70 rounded-md mt-2 border border-zinc-700 text-sm animate-fade-in-up">
            {isHintLoading[field] ? (
                <div className="flex items-center gap-2 text-zinc-400">
                    <CircleSpinner className="w-4 h-4" />
                    <span>Getting suggestion...</span>
                </div>
            ) : hintContent[field] ? (
                <div className="space-y-3">
                    <p className="text-zinc-300 whitespace-pre-wrap">{hintContent[field]}</p>
                    <button 
                        onClick={() => handleUseHint(field)} 
                        className="text-xs font-semibold bg-purple-600 text-white px-3 py-1 rounded-md hover:bg-purple-500 transition-colors"
                    >
                        Use this suggestion
                    </button>
                </div>
            ) : (
                <div className="space-y-3">
                    <p className="text-zinc-400">Let CECILIA suggest a starting point based on your current project definition.</p>
                    <button 
                        onClick={() => handleGetHint(field)} 
                        className="text-xs font-semibold bg-zinc-700 text-white px-3 py-1.5 rounded-md hover:bg-zinc-600 transition-colors flex items-center gap-2"
                    >
                        <SparklesIcon className="w-4 h-4" />
                        <span>Generate Suggestion</span>
                    </button>
                </div>
            )}
        </div>
    )
  }

  return (
    <div className="min-h-screen bg-zinc-950 text-white p-4 sm:p-6 lg:p-8 font-sans flex flex-col">
      <div className="max-w-screen-2xl w-full mx-auto flex flex-col flex-grow">
        <header className="text-center mb-6">
            <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-fuchsia-500 via-purple-500 to-cyan-400 pb-2">
                CECILIA's Project Kickstarter
            </h1>
            <p className="text-lg text-zinc-400 max-w-3xl mx-auto">
                Interactively define your project's USER, SYSTEM, and AI contexts to generate user stories and setup commands.
            </p>
        </header>

        <ProfileManager
            profiles={Object.keys(profiles)}
            profileName={profileName}
            setProfileName={setProfileName}
            onSave={handleSaveProfile}
            onLoad={handleLoadProfile}
            onDelete={handleDeleteProfile}
            currentProfile={currentProfile}
            exampleProfiles={EXAMPLE_PROFILES}
            onLoadTemplate={handleLoadTemplate}
        />

        <main ref={mainContainerRef} className="flex-grow flex gap-0 min-h-[65vh]">
            <div className="h-full flex flex-col" style={{ flexBasis: `${columnWidths[0]}%` }}>
                <ContextColumn title="Project Definition" icon={<UserIcon />} borderColor="border-fuchsia-500/30">
                    <div className="space-y-4">
                        <div className="space-y-1">
                            <div className="flex justify-between items-center">
                                <label htmlFor="scope" className="text-sm font-semibold text-zinc-300">User Persona &amp; MVP Scope</label>
                                <button onClick={() => toggleHintVisibility('scope')} className="text-xs flex items-center gap-1 text-purple-400 hover:text-purple-300 transition-colors">
                                    <LightBulbIcon className="w-4 h-4" />
                                    {visibleHints.scope ? 'Hide Hint' : 'Get Hint'}
                                </button>
                            </div>
                            <textarea id="scope" value={scope} onChange={e => updateProjectState({ scope: e.target.value })} rows={3} className="w-full bg-zinc-900/50 border border-zinc-700 rounded-md px-3 py-2 text-zinc-200 placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-fuchsia-500 focus:border-fuchsia-500 transition" placeholder="Describe your target user and the core features..."/>
                            {visibleHints.scope && renderHint('scope')}
                        </div>

                        <div className="space-y-1">
                            <div className="flex justify-between items-center">
                                <label htmlFor="aiIntegration" className="text-sm font-semibold text-zinc-300">AI Integration Plan</label>
                                <button onClick={() => toggleHintVisibility('aiIntegration')} className="text-xs flex items-center gap-1 text-purple-400 hover:text-purple-300 transition-colors">
                                    <LightBulbIcon className="w-4 h-4" />
                                    {visibleHints.aiIntegration ? 'Hide Hint' : 'Get Hint'}
                                </button>
                            </div>
                            <textarea id="aiIntegration" value={aiIntegration} onChange={e => updateProjectState({ aiIntegration: e.target.value })} rows={3} className="w-full bg-zinc-900/50 border border-zinc-700 rounded-md px-3 py-2 text-zinc-200 placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-fuchsia-500 focus:border-fuchsia-500 transition" placeholder="How will AI be integrated? Describe the features..."/>
                            {visibleHints.aiIntegration && renderHint('aiIntegration')}
                        </div>

                         <div className="space-y-1">
                            <div className="flex justify-between items-center">
                                <label htmlFor="architecture" className="text-sm font-semibold text-zinc-300">Core Architecture</label>
                                <button onClick={() => toggleHintVisibility('architecture')} className="text-xs flex items-center gap-1 text-purple-400 hover:text-purple-300 transition-colors">
                                    <LightBulbIcon className="w-4 h-4" />
                                    {visibleHints.architecture ? 'Hide Hint' : 'Get Hint'}
                                </button>
                            </div>
                            <textarea id="architecture" value={architecture} onChange={e => updateProjectState({ architecture: e.target.value })} rows={3} className="w-full bg-zinc-900/50 border border-zinc-700 rounded-md px-3 py-2 text-zinc-200 placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-fuchsia-500 focus:border-fuchsia-500 transition" placeholder="Describe the proposed system architecture..."/>
                            {visibleHints.architecture && renderHint('architecture')}
                        </div>

                        <div className="space-y-1">
                            <div className="flex justify-between items-center">
                                <label htmlFor="devEnv" className="text-sm font-semibold text-zinc-300">Tech Stack / Dev Environment</label>
                                <button onClick={() => toggleHintVisibility('devEnv')} className="text-xs flex items-center gap-1 text-purple-400 hover:text-purple-300 transition-colors">
                                    <LightBulbIcon className="w-4 h-4" />
                                    {visibleHints.devEnv ? 'Hide Hint' : 'Get Hint'}
                                </button>
                            </div>
                            <textarea id="devEnv" value={devEnv} onChange={e => updateProjectState({ devEnv: e.target.value })} rows={3} className="w-full bg-zinc-900/50 border border-zinc-700 rounded-md px-3 py-2 text-zinc-200 placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-fuchsia-500 focus:border-fuchsia-500 transition" placeholder="What is the planned tech stack..."/>
                            {visibleHints.devEnv && renderHint('devEnv')}
                        </div>
                        
                        <button onClick={handleSuggestBlueprint} disabled={isAiBusy || !scope} className="w-full mt-2 flex items-center justify-center gap-2 px-4 py-2 bg-zinc-700 text-white rounded-md font-bold hover:bg-zinc-600 transition-colors duration-200 disabled:bg-zinc-800 disabled:text-zinc-500 disabled:cursor-not-allowed">
                            <SparklesIcon className="w-5 h-5" />
                            <span>Suggest System Blueprint</span>
                        </button>
                    </div>
                </ContextColumn>
            </div>
            
            <ResizeHandle onMouseDown={() => handleMouseDown(0)} />

            <div className="h-full flex flex-col" style={{ flexBasis: `${columnWidths[1]}%` }}>
                <ContextColumn title="AI-Generated Plan" icon={<CogIcon />} borderColor="border-purple-500/30">
                    <div className="space-y-4 flex-shrink-0">
                        <button onClick={handleStartConversation} disabled={isAiBusy || !scope} className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-purple-600 to-fuchsia-600 text-white rounded-lg font-bold hover:opacity-90 transition-opacity duration-200 disabled:from-zinc-800 disabled:to-zinc-800 disabled:text-zinc-500 disabled:cursor-not-allowed shadow-[0_0_20px_theme(colors.purple.500/0.5)]">
                            {isAiBusy && conversation.length === 0 ? <CircleSpinner className="w-5 h-5" /> : <SparklesIcon className="w-5 h-5" />}
                            <span>Generate User Stories</span>
                        </button>
                        {error && <p className="text-pink-500 text-sm text-center bg-pink-500/10 p-2 rounded-md">{error}</p>}
                    </div>
                    <div className="flex-grow min-h-0 overflow-y-auto pr-1 -mr-3 mt-4 space-y-4">
                        <TaskList tasks={tasks} onAddTask={handleAddTask} onToggleTask={handleToggleTask} onDeleteTask={handleDeleteTask} />
                        {conversation.length > 0 && (
                            <Conversation conversation={conversation} suggestions={suggestions} onSendMessage={handleAiInteraction} isResponding={isAiBusy} />
                        )}
                    </div>
                </ContextColumn>
            </div>

            <ResizeHandle onMouseDown={() => handleMouseDown(1)} />

            <div className="h-full flex flex-col" style={{ flexBasis: `${columnWidths[2]}%` }}>
                <ContextColumn title="Project Setup" icon={<TerminalIcon />} borderColor="border-cyan-500/30">
                    <div className="space-y-6">
                        <ToolSelector selectedTools={selectedTools} onToolToggle={handleToolToggle} />
                        
                        <div className="space-y-2">
                            <label className="text-sm font-semibold text-zinc-300">Version Control</label>
                            <div className="space-y-2">
                                <Dropdown
                                    options={BRANCHING_STRATEGIES}
                                    selected={versionControl.strategy}
                                    onSelect={(strategy) => updateProjectState(prev => ({ versionControl: { ...prev.versionControl, strategy } }))}
                                />
                                <input type="text" value={versionControl.repoUrl} onChange={e => updateProjectState(prev => ({ versionControl: { ...prev.versionControl, repoUrl: e.target.value } }))} placeholder="Optional: Git repo URL" className="w-full bg-zinc-900/50 border border-zinc-700 rounded-md px-3 py-2 text-zinc-200 placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition" />
                            </div>
                        </div>

                        <div className="space-y-2">
                            <label className="text-sm font-semibold text-zinc-300">CLI Helper Preference</label>
                            <div className="flex justify-around bg-zinc-800/50 p-1 rounded-lg">
                                {(['none', 'gemini', 'openai'] as CliPreference[]).map(pref => (
                                    <button key={pref} onClick={() => updateProjectState({ cliPreference: pref })} className={`w-full capitalize text-center px-3 py-1.5 text-sm font-semibold rounded-md transition-colors ${cliPreference === pref ? 'bg-cyan-500 text-black' : 'text-zinc-300 hover:bg-zinc-700'}`}>
                                        {pref}
                                    </button>
                                ))}
                            </div>
                        </div>
                    </div>
                    <div className="flex-grow flex flex-col justify-end">
                        <button onClick={handleGenerateCliScript} className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-black rounded-md font-bold hover:bg-green-500 transition-colors duration-200 mt-4">
                            Generate CLI Script
                        </button>
                        <div className="mt-4 flex-grow flex flex-col">
                          <CliOutput script={cliScript} />
                        </div>
                    </div>
                </ContextColumn>
            </div>
        </main>
        
        <GlowingFooter />
      </div>
    </div>
  );
};

export default App;
