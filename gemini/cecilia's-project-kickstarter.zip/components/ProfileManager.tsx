import React from 'react';
import { SaveIcon, TrashIcon } from './icons';
import { ExampleProfile, ProjectState } from '../types';

interface ProfileManagerProps {
    profiles: string[];
    profileName: string;
    setProfileName: (name: string) => void;
    onSave: () => void;
    onLoad: (name: string) => void;
    onDelete: (name: string) => void;
    currentProfile: string | null;
    exampleProfiles: ExampleProfile[];
    onLoadTemplate: (state: ProjectState) => void;
}

const ProfileManager: React.FC<ProfileManagerProps> = ({
    profiles,
    profileName,
    setProfileName,
    onSave,
    onLoad,
    onDelete,
    currentProfile,
    exampleProfiles,
    onLoadTemplate,
}) => {

    return (
        <div className="bg-zinc-900/60 backdrop-blur-lg border border-cyan-500/30 rounded-2xl shadow-lg p-4 mb-8 space-y-4 transition-all duration-300 hover:border-cyan-500/60">
            {/* Save Section */}
            <div className="flex items-center gap-2">
                <label htmlFor="profile-name" className="sr-only">Profile Name</label>
                <input
                    id="profile-name"
                    type="text"
                    value={profileName}
                    onChange={(e) => setProfileName(e.target.value)}
                    placeholder="Enter profile name to save..."
                    className="w-full bg-zinc-900/50 border border-zinc-700 rounded-md px-3 py-2 text-zinc-200 placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
                />
                 <button
                    onClick={onSave}
                    disabled={!profileName.trim()}
                    className="flex-shrink-0 flex items-center justify-center gap-2 px-4 py-2 bg-cyan-500 text-black rounded-md font-bold hover:bg-cyan-400 transition-colors duration-200 disabled:bg-zinc-700 disabled:text-zinc-400 disabled:cursor-not-allowed disabled:shadow-none shadow-[0_0_10px_theme(colors.cyan.400/0.6)] hover:shadow-[0_0_20px_theme(colors.cyan.400/0.9)]"
                    title="Save current configuration as a profile"
                >
                    <SaveIcon className="w-5 h-5" />
                    <span className="hidden md:inline">Save</span>
                </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Load Profile Section */}
                <div>
                    <h4 className="text-sm font-semibold text-zinc-400 mb-2 ml-1">Load Saved Profile</h4>
                    <div className="p-3 rounded-lg bg-black/20 min-h-[4rem]">
                         {profiles.length > 0 ? (
                            <div className="flex flex-wrap gap-2">
                                {profiles.map(p => (
                                    <div key={p} className="relative group">
                                        <button
                                            onClick={() => onLoad(p)}
                                            className={`px-3 py-1.5 text-sm font-semibold rounded-full transition-all duration-200 border ${
                                                currentProfile === p
                                                ? 'bg-cyan-500 text-black border-cyan-400 shadow-[0_0_8px_theme(colors.cyan.400/0.6)]'
                                                : 'bg-zinc-800/50 border-zinc-700 text-zinc-300 hover:bg-zinc-700/80 hover:border-zinc-600'
                                            }`}
                                        >
                                            {p}
                                        </button>
                                        {currentProfile === p && (
                                             <button
                                                onClick={() => onDelete(p)}
                                                className="absolute -top-1 -right-1 p-0.5 bg-pink-500 text-black rounded-full hover:scale-110 transition-transform hidden group-hover:block"
                                                aria-label={`Delete profile ${p}`}
                                                title={`Delete profile ${p}`}
                                            >
                                                <TrashIcon className="w-3.5 h-3.5" />
                                            </button>
                                        )}
                                    </div>
                                ))}
                            </div>
                         ) : (
                            <p className="text-zinc-500 text-sm text-center pt-1">No saved profiles.</p>
                         )}
                    </div>
                </div>

                {/* Load Template Section */}
                <div>
                    <h4 className="text-sm font-semibold text-zinc-400 mb-2 ml-1">Load a Template</h4>
                     <div className="p-3 rounded-lg bg-black/20 min-h-[4rem]">
                        <div className="flex flex-wrap gap-2">
                            {exampleProfiles.map(p => (
                                <button
                                    key={p.name}
                                    onClick={() => {
                                        onLoadTemplate(p.state);
                                        setProfileName(p.name + ' (copy)');
                                    }}
                                    className="px-3 py-1.5 text-sm font-semibold rounded-full transition-all duration-200 border bg-zinc-800/50 border-zinc-700 text-zinc-300 hover:bg-zinc-700/80 hover:border-zinc-600"
                                >
                                    {p.name}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ProfileManager;