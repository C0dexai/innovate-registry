import React, { useState, useEffect, useRef } from 'react';
import { ConversationMessage } from '../types';
import { SendIcon, CircleSpinner, SparklesIcon } from './icons';

interface ConversationProps {
    conversation: ConversationMessage[];
    suggestions: string[];
    onSendMessage: (message: string) => void;
    isResponding: boolean;
}

const Conversation: React.FC<ConversationProps> = ({ conversation, suggestions, onSendMessage, isResponding }) => {
    const [input, setInput] = useState('');
    const endOfMessagesRef = useRef<null | HTMLDivElement>(null);

    useEffect(() => {
        endOfMessagesRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [conversation, isResponding]);

    const handleSend = () => {
        if (input.trim() && !isResponding) {
            onSendMessage(input.trim());
            setInput('');
        }
    };

    const handleSuggestionClick = (suggestion: string) => {
        if (!isResponding) {
            onSendMessage(suggestion);
        }
    };

    return (
        <div className="mt-4 pt-4 border-t border-zinc-700/50 space-y-4 flex flex-col">
            <h4 className="text-md font-semibold text-zinc-300">Conversation with CECILIA</h4>
            <div className="space-y-4 pr-2 -mr-2 max-h-96 overflow-y-auto">
                {conversation.map((msg, index) => (
                    <div key={index} className={`flex items-start gap-2.5 ${msg.role === 'user' ? 'justify-end' : ''}`}>
                        {msg.role === 'model' && (
                             <div className="flex-shrink-0 w-8 h-8 rounded-full bg-purple-500/30 flex items-center justify-center">
                                <SparklesIcon className="w-5 h-5 text-purple-300"/>
                            </div>
                        )}
                        <div className={`p-3 rounded-xl max-w-sm whitespace-pre-wrap font-medium ${
                            msg.role === 'model' 
                                ? 'bg-zinc-800/80 text-zinc-200 rounded-tl-none' 
                                : 'bg-fuchsia-600 text-black rounded-br-none'
                        }`}>
                            {msg.text}
                        </div>
                    </div>
                ))}
                 {isResponding && (
                     <div className="flex items-start gap-2.5">
                        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-purple-500/30 flex items-center justify-center">
                            <CircleSpinner className="w-5 h-5 text-purple-300"/>
                        </div>
                        <div className="p-3 rounded-xl bg-zinc-800/80 text-zinc-400 rounded-tl-none italic">
                            Thinking...
                        </div>
                     </div>
                 )}
                <div ref={endOfMessagesRef} />
            </div>

            {suggestions.length > 0 && !isResponding && (
                <div className="flex flex-wrap gap-2">
                    {suggestions.map((s, i) => (
                        <button 
                            key={i} 
                            onClick={() => handleSuggestionClick(s)}
                            className="px-3 py-1.5 text-sm font-medium rounded-full transition-all duration-200 bg-zinc-800/50 border border-zinc-700/50 text-purple-300 hover:bg-zinc-700 hover:border-purple-500"
                        >
                            {s}
                        </button>
                    ))}
                </div>
            )}

            <div className="flex gap-2 pt-2">
                <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                    placeholder="Ask a follow-up question..."
                    disabled={isResponding}
                    className="flex-grow bg-zinc-900/50 border border-zinc-700 rounded-md px-3 py-2 text-zinc-200 placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-fuchsia-500 focus:border-fuchsia-500 transition disabled:opacity-50"
                />
                <button
                    onClick={handleSend}
                    disabled={isResponding || !input.trim()}
                    className="flex-shrink-0 bg-fuchsia-600 text-black w-10 h-10 flex items-center justify-center rounded-md font-semibold hover:bg-fuchsia-500 transition-colors duration-200 disabled:bg-zinc-700 disabled:cursor-not-allowed"
                    aria-label="Send message"
                >
                    <SendIcon className="w-5 h-5" />
                </button>
            </div>
        </div>
    );
};

export default Conversation;
