import React, { useState, useEffect } from 'react';
import { ClipboardIcon, ClipboardCheckIcon } from './icons';

interface CliOutputProps {
    script: string;
}

const CliOutput: React.FC<CliOutputProps> = ({ script }) => {
    const [copied, setCopied] = useState(false);

    useEffect(() => {
        if (copied) {
            const timer = setTimeout(() => setCopied(false), 2000);
            return () => clearTimeout(timer);
        }
    }, [copied]);

    const handleCopy = () => {
        navigator.clipboard.writeText(script);
        setCopied(true);
    };

    if (!script) {
        return (
            <div className="flex items-center justify-center h-full border-2 border-dashed border-zinc-700 rounded-lg p-4">
                <p className="text-zinc-500 text-center">Generated CLI commands will appear here.</p>
            </div>
        );
    }

    return (
        <div className="bg-black/50 rounded-lg relative font-mono text-sm border border-green-500/20 flex-grow flex flex-col">
            <button
                onClick={handleCopy}
                className="absolute top-2 right-2 p-1.5 bg-zinc-800 hover:bg-zinc-700 rounded-md text-zinc-300 transition-colors z-10"
                aria-label="Copy to clipboard"
            >
                {copied ? <ClipboardCheckIcon className="w-5 h-5 text-green-400" /> : <ClipboardIcon className="w-5 h-5" />}
            </button>
            <pre className="p-4 pt-10 whitespace-pre-wrap break-words overflow-auto h-full min-h-[10rem] max-h-96">
                <code className="text-green-300">{script}</code>
            </pre>
        </div>
    );
};

export default CliOutput;
