import React from 'react';

interface StepCardProps {
  stepNumber: number;
  title: string;
  description: string;
  children: React.ReactNode;
}

const StepCard: React.FC<StepCardProps> = ({ stepNumber, title, description, children }) => {
  return (
    <div className="bg-zinc-900/60 backdrop-blur-lg border border-purple-500/30 rounded-2xl shadow-lg transition-all duration-300 hover:border-purple-500/60 shadow-[0_0_15px_rgba(168,85,247,0.1)] hover:shadow-[0_0_25px_rgba(168,85,247,0.2)]">
      <div className="p-6">
        <div className="flex items-center gap-4">
          <div className="flex-shrink-0 w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center text-black font-bold text-xl shadow-[0_0_10px_theme(colors.purple.500/0.7)]">
            {stepNumber}
          </div>
          <div>
            <h3 className="text-xl font-bold text-zinc-100">{title}</h3>
            <p className="text-sm text-zinc-400">{description}</p>
          </div>
        </div>
        <div className="mt-6 text-zinc-300">
          {children}
        </div>
      </div>
    </div>
  );
};

export default StepCard;
