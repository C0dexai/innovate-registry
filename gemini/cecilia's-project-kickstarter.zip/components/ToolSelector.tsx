import React from 'react';
import { TOOLS } from '../constants';
import { SelectedTools, Tool, ToolCategory } from '../types';

interface ToolSelectorProps {
  selectedTools: SelectedTools;
  onToolToggle: (toolName: string) => void;
}

const ToolButton: React.FC<{ tool: Tool; isSelected: boolean; onClick: (name: string) => void }> = ({ tool, isSelected, onClick }) => (
  <button
    onClick={() => onClick(tool.name)}
    className={`flex items-center gap-2 px-3 py-1.5 text-sm font-semibold rounded-full transition-all duration-200 border ${
      isSelected
        ? 'bg-gradient-to-r from-blue-500 to-cyan-400 border-cyan-500 text-black shadow-[0_0_10px_theme(colors.cyan.400/0.5)]'
        : 'bg-zinc-800/30 border-zinc-700/50 text-zinc-300 hover:bg-zinc-700/50 hover:border-zinc-600'
    }`}
  >
    {isSelected && <div className="w-2 h-2 bg-black/50 rounded-full"></div>}
    {tool.name}
  </button>
);

const ToolSelector: React.FC<ToolSelectorProps> = ({ selectedTools, onToolToggle }) => {
  const categories = Object.values(ToolCategory);

  return (
    <div className="space-y-4">
      {categories.map((category) => (
        <div key={category}>
          <h4 className="text-md font-semibold text-zinc-300 mb-2">{category}</h4>
          <div className="flex flex-wrap gap-2">
            {TOOLS.filter((tool) => tool.category === category).map((tool) => (
              <ToolButton
                key={tool.name}
                tool={tool}
                isSelected={!!selectedTools[tool.name]}
                onClick={onToolToggle}
              />
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};

export default ToolSelector;
