import React from 'react';

interface ContextColumnProps {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  borderColor?: string;
}

const ContextColumn: React.FC<ContextColumnProps> = ({ title, icon, children, borderColor = 'border-purple-500/30' }) => {
  const iconColorMap: Record<string, string> = {
    'border-fuchsia-500/30': 'text-fuchsia-400',
    'border-cyan-500/30': 'text-cyan-400',
    'border-green-500/30': 'text-green-400',
  }
  const iconColor = iconColorMap[borderColor] || 'text-purple-400';

  return (
    <div className={`h-full flex-1 bg-zinc-900/60 backdrop-blur-lg border ${borderColor} rounded-2xl shadow-lg p-6 flex flex-col gap-6 min-w-0 transition-all duration-300 hover:border-opacity-60`}>
      <div className="flex items-center gap-3 flex-shrink-0">
        <div className={`w-8 h-8 ${iconColor}`}>{icon}</div>
        <h2 className="text-2xl font-bold text-zinc-100">{title}</h2>
      </div>
      <div className="space-y-4 text-zinc-300 flex-grow flex flex-col min-h-0 overflow-y-auto pr-2 -mr-2">
        {children}
      </div>
    </div>
  );
};

export default ContextColumn;