import React, { useState } from 'react';
import { Task } from '../types';
import { PlusIcon, TrashIcon, CheckIcon } from './icons';

interface TaskListProps {
  tasks: Task[];
  onAddTask: (text: string) => void;
  onToggleTask: (id: number) => void;
  onDeleteTask: (id: number) => void;
}

const TaskItem: React.FC<{ task: Task; onToggle: (id: number) => void; onDelete: (id: number) => void }> = ({ task, onToggle, onDelete }) => (
  <li className="flex items-center gap-3 p-3 bg-zinc-800/40 rounded-lg border border-transparent hover:border-zinc-700/80 transition-colors duration-200">
    <button
      onClick={() => onToggle(task.id)}
      className={`flex-shrink-0 w-6 h-6 rounded-md border-2 flex items-center justify-center transition-all duration-200 ${
        task.completed ? 'bg-fuchsia-500 border-fuchsia-500' : 'border-zinc-600 hover:border-fuchsia-500'
      }`}
      aria-pressed={task.completed}
    >
      {task.completed && <CheckIcon className="w-4 h-4 text-black" />}
    </button>
    <span className={`flex-grow ${task.completed ? 'text-zinc-500 line-through' : 'text-zinc-200'}`}>
      {task.text}
    </span>
    <button
      onClick={() => onDelete(task.id)}
      className="text-zinc-500 hover:text-pink-500 transition-colors duration-200"
      aria-label={`Delete user story: ${task.text}`}
    >
      <TrashIcon className="w-5 h-5" />
    </button>
  </li>
);

const TaskList: React.FC<TaskListProps> = ({ tasks, onAddTask, onToggleTask, onDeleteTask }) => {
  const [newTaskText, setNewTaskText] = useState('');

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (newTaskText.trim()) {
      onAddTask(newTaskText.trim());
      setNewTaskText('');
    }
  };

  return (
    <div className="space-y-4">
      <form onSubmit={handleAddTask} className="flex gap-2">
        <input
          type="text"
          value={newTaskText}
          onChange={(e) => setNewTaskText(e.target.value)}
          placeholder="Add a user story manually..."
          className="flex-grow bg-zinc-900/50 border border-zinc-700 rounded-md px-3 py-2 text-zinc-200 placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-fuchsia-500 focus:border-fuchsia-500 transition"
        />
        <button
          type="submit"
          className="flex-shrink-0 bg-fuchsia-600 text-black px-4 py-2 rounded-md font-bold hover:bg-fuchsia-500 transition-colors duration-200 disabled:bg-zinc-700 disabled:text-zinc-400 disabled:cursor-not-allowed flex items-center gap-2"
          disabled={!newTaskText.trim()}
          aria-label="Add new user story"
        >
          <PlusIcon className="w-5 h-5" />
          <span>Add</span>
        </button>
      </form>
      {tasks.length > 0 ? (
        <ul className="space-y-2">
          {tasks.map((task) => (
            <TaskItem key={task.id} task={task} onToggle={onToggleTask} onDelete={onDeleteTask} />
          ))}
        </ul>
      ) : (
        <div className="text-center py-6 border-2 border-dashed border-zinc-700 rounded-lg">
          <p className="text-zinc-500">No user stories yet. Generate them from your MVP.</p>
        </div>
      )}
    </div>
  );
};

export default TaskList;
