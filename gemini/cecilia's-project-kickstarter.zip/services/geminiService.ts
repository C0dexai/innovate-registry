import { GoogleGenAI, Type, Chat } from "@google/genai";
import { TOOLS } from '../constants';
import { ProjectState } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("API_KEY environment variable not set. Gemini features will be disabled.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

const CHAT_SYSTEM_INSTRUCTION = `You are an expert project manager and solutions architect named CECILIA. You help users define their projects by breaking down their ideas into actionable plans. You are helpful, conversational, and provide structured output in JSON format. Your responses should be conversational but also contain structured data. When generating lists like user stories or tasks, you must also provide relevant follow-up suggestions to help the user refine the plan. When asked for tool suggestions, only suggest tools from this list: ${TOOLS.map(t => t.name).join(', ')}.`;

const SUGGESTION_SYSTEM_INSTRUCTION = `You are an expert project manager and solutions architect named CECILIA. You provide brief, targeted suggestions to help users flesh out their project plans. Keep your suggestions to 2-3 concise sentences.`;

const RESPONSE_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    responseText: {
      type: Type.STRING,
      description: "A brief, conversational text response to the user's prompt. Acknowledge the request and present the information."
    },
    userStories: {
      type: Type.ARRAY,
      description: "The complete, up-to-date list of user stories. This should be returned on the first turn, and whenever the stories are modified by the user's request.",
      items: { type: Type.STRING }
    },
    followUpSuggestions: {
      type: Type.ARRAY,
      description: "A list of 3-4 relevant follow-up questions or actions the user might take to refine the project plan.",
      items: { type: Type.STRING }
    },
    architecture: {
        type: Type.STRING,
        description: "A suggested core architecture based on the project scope."
    },
    devEnv: {
        type: Type.STRING,
        description: "A suggested tech stack and development environment."
    },
    suggestedTools: {
        type: Type.ARRAY,
        description: "A list of recommended tool names from the available list.",
        items: { type: Type.STRING }
    }
  },
  required: ["responseText", "followUpSuggestions"]
};

const generateInitialPrompt = (scope: string, architecture: string, devEnv: string, aiIntegration: string) => `
Here is my project context. Based on this, please generate the initial set of 5-7 high-level, actionable user stories for the first project iteration. These stories should be foundational and help build the core of the product.

### USER Context
**User Persona & MVP Scope:**
"""
${scope}
"""

### SYSTEM Blueprint
${architecture ? `
**Core Architecture:**
"""
${architecture}
"""
` : ''}
${devEnv ? `
**Tech Stack:**
"""
${devEnv}
"""
` : ''}

### AI Integration Plan
${aiIntegration ? `
**Planned AI Features:**
"""
${aiIntegration}
"""
` : ''}
`;

// Define a type for the parsed response for better type safety
export interface ParsedAiResponse {
    responseText: string;
    userStories?: string[];
    followUpSuggestions: string[];
    architecture?: string;
    devEnv?: string;
    suggestedTools?: string[];
}

const parseResponse = (responseText: string): ParsedAiResponse => {
    try {
        // The API should return a clean JSON string, but we'll trim just in case.
        const jsonStr = responseText.trim();
        const parsed = JSON.parse(jsonStr);

        // Basic validation
        if (typeof parsed.responseText !== 'string' || !Array.isArray(parsed.followUpSuggestions)) {
            throw new Error("Parsed JSON is missing required fields.");
        }
        return parsed as ParsedAiResponse;

    } catch (error) {
        console.error("Error parsing AI response:", error);
        console.error("Raw response text:", responseText);
        // Fallback for when JSON parsing fails
        return {
            responseText: "I apologize, but I couldn't format my response correctly. Here's the raw text: " + responseText,
            followUpSuggestions: ["Can you try that again?", "Please rephrase your request."],
        };
    }
}


export const startChatSession = async (scope: string, architecture: string, devEnv: string, aiIntegration: string): Promise<{ chat: Chat; response: ParsedAiResponse }> => {
  if (!API_KEY) {
    throw new Error("Gemini API key is not configured.");
  }
  
  const chat = ai.chats.create({
    model: 'gemini-2.5-flash',
    config: { 
      systemInstruction: CHAT_SYSTEM_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema: RESPONSE_SCHEMA,
      temperature: 0.5,
    },
  });

  const initialPrompt = generateInitialPrompt(scope, architecture, devEnv, aiIntegration);

  try {
    const result = await chat.sendMessage({ message: initialPrompt });
    const response = parseResponse(result.text);
    return { chat, response };
  } catch(error) {
      console.error("Error starting chat session:", error);
      if (error instanceof Error) {
        throw new Error(`Failed to start chat: ${error.message}`);
      }
      throw new Error("An unknown error occurred while starting the chat.");
  }
};

export const continueChatSession = async (chat: Chat, message: string): Promise<ParsedAiResponse> => {
    if (!API_KEY) {
        throw new Error("Gemini API key is not configured.");
    }

    try {
        const result = await chat.sendMessage({ message });
        const response = parseResponse(result.text);
        return response;
    } catch(error) {
        console.error("Error continuing chat session:", error);
        if (error instanceof Error) {
            throw new Error(`Failed to send message: ${error.message}`);
        }
        throw new Error("An unknown error occurred while sending the message.");
    }
};

export const generateSuggestion = async (fieldName: string, context: Partial<ProjectState>): Promise<string> => {
  if (!API_KEY) {
    throw new Error("Gemini API key is not configured.");
  }
  
  const fieldMap: Record<string, string> = {
    scope: "User Persona & MVP Scope",
    architecture: "Core Architecture",
    devEnv: "Tech Stack / Dev Environment",
    aiIntegration: "AI Integration Plan"
  };

  const prompt = `Based on the current project context, provide a specific, high-quality example for the **${fieldMap[fieldName] || fieldName}** field.

**Current Project Context:**
${context.scope ? `- User/MVP Scope: ${context.scope}\n` : ''}
${context.architecture ? `- Core Architecture: ${context.architecture}\n` : ''}
${context.devEnv ? `- Tech Stack: ${context.devEnv}\n` : ''}
${context.aiIntegration ? `- AI Plan: ${context.aiIntegration}\n` : ''}

Provide only the text for the example, without any preamble, quotation marks, or markdown formatting.`;

  try {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            systemInstruction: SUGGESTION_SYSTEM_INSTRUCTION,
            temperature: 0.7,
        }
    });
    
    return response.text.trim();
  } catch(error) {
      console.error(`Error generating suggestion for ${fieldName}:`, error);
      if (error instanceof Error) {
        throw new Error(`Failed to get suggestion: ${error.message}`);
      }
      throw new Error("An unknown error occurred while getting a suggestion.");
  }
};
