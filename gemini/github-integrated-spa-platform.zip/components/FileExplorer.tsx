
import React, { useState } from 'react';
import { GitHubTreeEntry, GitHubFile, GitHubDirectory } from '../types';
import { FileIcon, FolderIcon, FolderOpenIcon } from './icons';

interface FileExplorerProps {
  tree: Record<string, GitHubTreeEntry[]>;
  onFileSelect: (file: GitHubFile) => void;
  onDirectoryLoad: (path: string) => void;
  selectedFilePath?: string;
  isConnected: boolean;
}

const TreeEntry: React.FC<{
  entry: GitHubTreeEntry;
  onFileSelect: (file: GitHubFile) => void;
  onDirectoryLoad: (path: string) => void;
  selectedFilePath?: string;
  tree: Record<string, GitHubTreeEntry[]>;
  level: number;
}> = ({ entry, onFileSelect, onDirectoryLoad, selectedFilePath, tree, level }) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleToggle = () => {
    if (entry.type === 'dir') {
      if (!tree[entry.path]) {
        onDirectoryLoad(entry.path);
      }
      setIsOpen(!isOpen);
    }
  };

  const handleClick = () => {
    if (entry.type === 'dir') {
      handleToggle();
    } else {
      onFileSelect(entry as GitHubFile);
    }
  };

  const isSelected = selectedFilePath === entry.path;
  const children = entry.type === 'dir' ? tree[entry.path] : undefined;

  return (
    <div>
      <button
        onClick={handleClick}
        style={{ paddingLeft: `${level * 1.25}rem` }}
        className={`w-full text-left px-3 py-1.5 rounded-md flex items-center gap-2 text-sm transition-colors ${
          isSelected ? 'bg-cyan-600/30 text-cyan-300' : 'text-gray-300 hover:bg-gray-700/50'
        }`}
      >
        {entry.type === 'dir' ? (
          isOpen ? <FolderOpenIcon className="w-4 h-4 flex-shrink-0 text-cyan-400" /> : <FolderIcon className="w-4 h-4 flex-shrink-0 text-gray-400" />
        ) : (
          <FileIcon className="w-4 h-4 flex-shrink-0" />
        )}
        <span className="truncate">{entry.name}</span>
      </button>
      {isOpen && children && (
        <div>
          {children.map(child => (
            <TreeEntry
              key={child.path}
              entry={child}
              onFileSelect={onFileSelect}
              onDirectoryLoad={onDirectoryLoad}
              selectedFilePath={selectedFilePath}
              tree={tree}
              level={level + 1}
            />
          ))}
        </div>
      )}
    </div>
  );
};


export const FileExplorer: React.FC<FileExplorerProps> = ({ tree, onFileSelect, onDirectoryLoad, selectedFilePath, isConnected }) => {
  const rootTree = tree[''] || [];
  return (
    <div className="h-full bg-gray-800/50 text-white flex flex-col border-r border-gray-700">
      <div className="p-4 border-b border-gray-700 flex-shrink-0">
        <h2 className="text-base font-semibold text-gray-200">File Explorer</h2>
      </div>
      <div className="flex-grow p-2 space-y-0.5 overflow-y-auto">
        {!isConnected ? (
          <p className="text-gray-400 text-sm px-2 text-center mt-8">Connect to a repository to see files.</p>
        ) : rootTree.length === 0 ? (
          <p className="text-gray-400 text-sm px-2">Loading or empty repository...</p>
        ) : (
          rootTree.map(entry => (
            <TreeEntry
              key={entry.path}
              entry={entry}
              onFileSelect={onFileSelect}
              onDirectoryLoad={onDirectoryLoad}
              selectedFilePath={selectedFilePath}
              tree={tree}
              level={0}
            />
          ))
        )}
      </div>
    </div>
  );
};
