
import React from 'react';
import type { ApiStatus } from '../types';
import { ActivityIcon, CheckCircleIcon, XCircleIcon, GitHubIcon } from './icons';

interface ProfileCardProps {
  title: string;
  agentId: string;
  status: ApiStatus;
  repoName?: string;
}

export const ProfileCard: React.FC<ProfileCardProps> = ({ title, agentId, status, repoName }) => {
  return (
    <div className="bg-gray-700/50 border border-gray-600 rounded-lg p-4">
      <h3 className="font-bold text-white mb-2">{title}</h3>
      <div className="space-y-2 text-sm">
        <div className="flex justify-between items-center">
          <span className="text-gray-400">Agent ID:</span>
          <span className="font-mono text-cyan-300 bg-gray-900/50 px-2 py-0.5 rounded">{agentId}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-gray-400">API Status:</span>
          <span className={`flex items-center gap-1.5 font-semibold ${status.ready ? 'text-green-400' : 'text-yellow-400'}`}>
            {status.ready ? <CheckCircleIcon className="w-4 h-4"/> : <XCircleIcon className="w-4 h-4"/>}
            {status.message}
          </span>
        </div>
        {repoName && (
           <div className="flex justify-between items-center">
             <span className="text-gray-400">Repository:</span>
             <span className="flex items-center gap-1.5 font-semibold text-gray-300">
                <GitHubIcon className="w-4 h-4" />
                {repoName}
            </span>
           </div>
        )}
      </div>
    </div>
  );
};
