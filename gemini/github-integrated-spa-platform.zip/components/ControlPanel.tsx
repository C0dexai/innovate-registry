
import React, { useState, useMemo } from 'react';
import type { RepoDetails } from '../types';
import { GitHubIcon, ActivityIcon, CheckCircleIcon, XCircleIcon } from './icons';
import { ProfileCard } from './ProfileCard';

interface ControlPanelProps {
  onConnect: (details: RepoDetails) => void;
  isConnected: boolean;
  isLoading: boolean;
  repoDetails: RepoDetails | null;
  error: string | null;
}

export const ControlPanel: React.FC<ControlPanelProps> = ({
  onConnect,
  isConnected,
  isLoading,
  repoDetails,
  error,
}) => {
  const [token, setToken] = useState('');
  const [owner, setOwner] = useState('');
  const [repo, setRepo] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (token.trim() && owner.trim() && repo.trim() && !isLoading) {
      onConnect({ token, owner, repo });
    }
  };
  
  const apiStatus = useMemo(() => {
    if(isLoading) return { ready: false, message: 'Connecting...' };
    if(error) return { ready: false, message: 'Connection Failed' };
    if(isConnected) return { ready: true, message: 'API Connected' };
    return { ready: false, message: 'Awaiting Connection' };
  }, [isConnected, isLoading, error]);

  return (
    <div className="h-full flex flex-col bg-gray-800/50">
      <div className="p-4 border-b border-gray-700">
        <h1 className="text-xl font-bold text-white flex items-center gap-2">
          <ActivityIcon className="w-6 h-6 text-cyan-400" />
          GitHub Orchestrator
        </h1>
      </div>

      <div className="flex-grow p-4 overflow-y-auto space-y-6">
        <ProfileCard
            agentId="GH-API-01"
            status={apiStatus}
            title="Orchestration Agent Supervisor"
            repoName={repoDetails ? `${repoDetails.owner}/${repoDetails.repo}` : undefined}
        />

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="token" className="block text-sm font-medium text-gray-300 mb-1">GitHub PAT</label>
            <input
              id="token"
              type="password"
              value={token}
              onChange={(e) => setToken(e.target.value)}
              placeholder="ghp_..."
              className="w-full bg-gray-700 border border-gray-600 rounded-md px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              disabled={isLoading}
            />
          </div>
          <div className="flex gap-2">
            <div>
              <label htmlFor="owner" className="block text-sm font-medium text-gray-300 mb-1">Owner</label>
              <input
                id="owner"
                type="text"
                value={owner}
                onChange={(e) => setOwner(e.target.value)}
                placeholder="e.g., 'microsoft'"
                className="w-full bg-gray-700 border border-gray-600 rounded-md px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                disabled={isLoading}
              />
            </div>
            <div>
              <label htmlFor="repo" className="block text-sm font-medium text-gray-300 mb-1">Repo</label>
              <input
                id="repo"
                type="text"
                value={repo}
                onChange={(e) => setRepo(e.target.value)}
                placeholder="e.g., 'vscode'"
                className="w-full bg-gray-700 border border-gray-600 rounded-md px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                disabled={isLoading}
              />
            </div>
          </div>
          <button
            type="submit"
            disabled={isLoading || !token || !owner || !repo}
            className="w-full bg-cyan-600 hover:bg-cyan-500 disabled:bg-gray-600 disabled:cursor-not-allowed text-white font-bold py-2 px-4 rounded-md flex items-center justify-center transition-all"
          >
            {isLoading ? (
              <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            ) : (
              <>{isConnected ? 'Reconnect' : 'Connect'}</>
            )}
          </button>
        </form>
        {error && (
            <div className="bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 rounded-md text-sm">
                <p className="font-bold">Error</p>
                <p>{error}</p>
            </div>
        )}
      </div>
    </div>
  );
};
