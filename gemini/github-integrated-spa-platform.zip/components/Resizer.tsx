import React from 'react';

interface ResizerProps {
  onMouseDown: (event: React.MouseEvent<HTMLDivElement>) => void;
}

export const Resizer: React.FC<ResizerProps> = ({ onMouseDown }) => {
  return (
    <div
      onMouseDown={onMouseDown}
      className="w-2 flex-shrink-0 cursor-col-resize bg-gray-700 hover:bg-cyan-500 transition-colors duration-200"
      style={{ zIndex: 20 }}
      aria-label="Resize panel"
    />
  );
};
