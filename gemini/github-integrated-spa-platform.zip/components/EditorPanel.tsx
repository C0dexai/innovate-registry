
import React, { useRef, useEffect, useState } from 'react';
import { GitHubFile } from '../types';
import { CodeIcon, CommitIcon } from './icons';

interface EditorPanelProps {
  file: GitHubFile | null;
  content: string;
  onContentChange: (newContent: string) => void;
  onCommit: (commitMessage: string) => void;
  isLoading: boolean;
}

// A simple map from file extension to Monaco language ID
const getLanguageFromFileName = (fileName: string): string => {
  const extension = fileName.split('.').pop()?.toLowerCase();
  switch (extension) {
    case 'js':
    case 'jsx':
      return 'javascript';
    case 'ts':
    case 'tsx':
      return 'typescript';
    case 'css':
      return 'css';
    case 'json':
      return 'json';
    case 'html':
      return 'html';
    case 'md':
      return 'markdown';
    case 'yml':
    case 'yaml':
        return 'yaml';
    default:
      return 'plaintext';
  }
};

export const EditorPanel: React.FC<EditorPanelProps> = ({ file, content, onContentChange, onCommit, isLoading }) => {
  const editorContainerRef = useRef<HTMLDivElement>(null);
  const editorRef = useRef<any>(null); // Using any for Monaco editor instance
  const [commitMessage, setCommitMessage] = useState('');

  useEffect(() => {
    if (editorContainerRef.current && (window as any).monaco && !editorRef.current) {
      const monaco = (window as any).monaco;
      editorRef.current = monaco.editor.create(editorContainerRef.current, {
        value: content,
        language: file ? getLanguageFromFileName(file.name) : 'plaintext',
        theme: 'vs-dark',
        automaticLayout: true,
        readOnly: isLoading,
        fontFamily: 'Fira Code, monospace',
        fontLigatures: true,
      });

      editorRef.current.onDidChangeModelContent(() => {
        onContentChange(editorRef.current.getValue());
      });
    }

    return () => {
      if (editorRef.current) {
        editorRef.current.dispose();
        editorRef.current = null;
      }
    };
  }, []); // Run only on mount and unmount

  useEffect(() => {
    if (editorRef.current) {
      // Update content if it differs
      if (editorRef.current.getValue() !== content) {
        editorRef.current.setValue(content);
      }
      // Update language
      const model = editorRef.current.getModel();
      if (model && file) {
        const language = getLanguageFromFileName(file.name);
        (window as any).monaco.editor.setModelLanguage(model, language);
      }
      editorRef.current.updateOptions({ readOnly: isLoading || !file });
    }
  }, [content, file, isLoading]);

  const handleCommitClick = () => {
    if(commitMessage.trim()) {
      onCommit(commitMessage);
      setCommitMessage('');
    }
  }

  return (
    <div className="h-full bg-[#1e1e1e] text-white flex flex-col border-r border-gray-700">
      <div className="p-4 border-b border-gray-700 flex items-center justify-between flex-shrink-0 bg-gray-900">
        <h2 className="text-base font-semibold truncate text-gray-200 flex items-center gap-2">
          <CodeIcon className="w-5 h-5 text-cyan-400" />
          {file?.path || 'Editor'}
        </h2>
      </div>
      <div className="flex-grow relative" ref={editorContainerRef}>
        {!file && (
          <div className="flex items-center justify-center h-full text-gray-500 bg-gray-800">
            <p>Select a file to begin editing.</p>
          </div>
        )}
      </div>
      <div className="flex-shrink-0 p-3 border-t border-gray-700 bg-gray-900">
        <div className="flex items-center gap-3">
            <input
                type="text"
                value={commitMessage}
                onChange={(e) => setCommitMessage(e.target.value)}
                placeholder="Commit message (e.g., 'Update component style')"
                className="flex-grow bg-gray-700 border border-gray-600 rounded-md px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                disabled={isLoading || !file}
            />
            <button
                onClick={handleCommitClick}
                disabled={isLoading || !file || !commitMessage.trim()}
                className="bg-green-600 hover:bg-green-500 disabled:bg-gray-600 disabled:cursor-not-allowed text-white font-bold py-2 px-3 rounded-md flex items-center justify-center transition-all"
                aria-label="Commit changes"
            >
                <CommitIcon className="w-5 h-5" />
            </button>
        </div>
      </div>
    </div>
  );
};
