
import React, { useRef, useEffect } from 'react';
import type { OrchestrationLogEntry } from '../types';
import { CheckCircleIcon, XCircleIcon, InfoIcon, SendIcon } from './icons';

interface OrchestrationLogPanelProps {
  logs: OrchestrationLogEntry[];
}

const LogIcon = ({ type }: { type: OrchestrationLogEntry['type'] }) => {
    switch(type) {
        case 'SUCCESS': return <CheckCircleIcon className="w-4 h-4 text-green-400" />;
        case 'ERROR': return <XCircleIcon className="w-4 h-4 text-red-400" />;
        case 'ACTION': return <SendIcon className="w-4 h-4 text-cyan-400 transform -rotate-45" />;
        case 'INFO':
        default:
            return <InfoIcon className="w-4 h-4 text-blue-400" />;
    }
}

export const OrchestrationLogPanel: React.FC<OrchestrationLogPanelProps> = ({ logs }) => {
    const endRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        endRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [logs]);

  return (
    <div className="h-full w-full flex flex-col bg-gray-800">
      <div className="flex-shrink-0 bg-gray-900 px-4 py-3 border-b border-gray-700">
        <h2 className="text-base font-semibold flex items-center gap-2 text-gray-200">
          Orchestration Log
        </h2>
      </div>
      <div className="flex-grow w-full bg-black/50 p-2 font-mono text-xs text-gray-300 overflow-y-auto">
        {logs.length === 0 ? (
            <div className="flex items-center justify-center h-full text-gray-500">
                <p>Logs will appear here...</p>
            </div>
        ) : (
            logs.map((log, index) => (
                <div key={index} className="flex items-start gap-2 mb-1">
                    <LogIcon type={log.type} />
                    <span className="flex-shrink-0 text-gray-500">[{new Date(log.timestamp).toLocaleTimeString()}]</span>
                    <p className={`whitespace-pre-wrap ${log.type === 'ERROR' ? 'text-red-400' : 'text-gray-300'}`}>
                        {log.message}
                    </p>
                </div>
            ))
        )}
        <div ref={endRef} />
      </div>
    </div>
  );
};
