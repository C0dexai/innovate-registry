
export interface GitHubFile {
  type: 'file';
  path: string;
  name: string;
  sha: string;
  content?: string;
}

export interface GitHubDirectory {
  type: 'dir';
  path: string;
  name: string;
  sha: string;
  // Children are loaded on demand
}

export type GitHubTreeEntry = GitHubFile | GitHubDirectory;

export interface RepoDetails {
  owner: string;
  repo: string;
  token: string;
}

export interface ApiStatus {
  ready: boolean;
  message: string;
}

export interface OrchestrationLogEntry {
    type: 'INFO' | 'SUCCESS' | 'ERROR' | 'ACTION';
    message: string;
    timestamp: string;
}
