
import React, { useState, useCallback, useMemo, useRef, useEffect } from 'react';
import { ControlPanel } from './components/ControlPanel';
import { FileExplorer } from './components/FileExplorer';
import { EditorPanel } from './components/EditorPanel';
import * as githubService from './services/geminiService';
import type { RepoDetails, GitHubTreeEntry, GitHubFile, OrchestrationLogEntry } from './types';
import { Resizer } from './components/Resizer';
import { OrchestrationLogPanel } from './components/PreviewPanel';


const MIN_PANEL_WIDTH = 150; 
const RESIZER_WIDTH = 8;

const App: React.FC = () => {
  const [repoDetails, setRepoDetails] = useState<RepoDetails | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [tree, setTree] = useState<Record<string, GitHubTreeEntry[]>>({ '': [] });
  const [selectedFile, setSelectedFile] = useState<GitHubFile | null>(null);
  const [fileContent, setFileContent] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [orchestrationLog, setOrchestrationLog] = useState<OrchestrationLogEntry[]>([]);

  // Use ratios for panel widths for a flexible layout
  const [panelWidths, setPanelWidths] = useState<number[]>([0.22, 0.15, 0.40, 0.23]);
  
  const [isDragging, setIsDragging] = useState(false);
  const [dragInfo, setDragInfo] = useState<{ index: number; startX: number; startWidths: number[] } | null>(null);
  const appContainerRef = useRef<HTMLDivElement>(null);

  const addLog = (type: OrchestrationLogEntry['type'], message: string) => {
    setOrchestrationLog(prev => [...prev, { type, message, timestamp: new Date().toISOString() }]);
  };

  const handleConnect = async (details: RepoDetails) => {
    setIsLoading(true);
    setError(null);
    setRepoDetails(details);
    setTree({ '': [] });
    setSelectedFile(null);
    setFileContent('');
    setOrchestrationLog([]);
    addLog('ACTION', `Connecting to repository: ${details.owner}/${details.repo}`);
    try {
      const rootTree = await githubService.getRepoTree(details.owner, details.repo, details.token);
      setTree({ '': rootTree });
      setIsConnected(true);
      addLog('SUCCESS', `Successfully connected and fetched root directory.`);
    } catch (e) {
      const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
      setError(errorMessage);
      setIsConnected(false);
      addLog('ERROR', `Connection failed: ${errorMessage}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileSelect = async (file: GitHubFile) => {
    if (!repoDetails) return;
    setIsLoading(true);
    setError(null);
    addLog('ACTION', `Fetching content for file: ${file.path}`);
    try {
      const content = await githubService.getFileContent(repoDetails.owner, repoDetails.repo, file.path, repoDetails.token);
      setSelectedFile(file);
      setFileContent(content);
      addLog('SUCCESS', `Content loaded for ${file.path}.`);
    } catch (e) {
      const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
      setError(errorMessage);
      addLog('ERROR', `Failed to load file: ${errorMessage}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDirectoryLoad = async (path: string) => {
    if (!repoDetails || tree[path]) return; // Already loaded
    setIsLoading(true);
    addLog('ACTION', `Fetching contents of directory: ${path}`);
    try {
      const directoryTree = await githubService.getRepoTree(repoDetails.owner, repoDetails.repo, repoDetails.token, path);
      setTree(prev => ({ ...prev, [path]: directoryTree }));
      addLog('SUCCESS', `Directory loaded: ${path}`);
    } catch (e) {
      const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
      setError(errorMessage);
      addLog('ERROR', `Failed to load directory: ${errorMessage}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCommit = async (commitMessage: string) => {
    if (!repoDetails || !selectedFile || !commitMessage.trim()) return;
    setIsLoading(true);
    setError(null);
    addLog('ACTION', `Committing changes to ${selectedFile.path}`);
    try {
      const updatedFile = await githubService.commitFile(
        repoDetails.owner,
        repoDetails.repo,
        selectedFile.path,
        fileContent,
        selectedFile.sha,
        commitMessage,
        repoDetails.token
      );
      // Update the SHA of the selected file to allow for subsequent commits
      const newSha = updatedFile.content.sha;
      setSelectedFile(prev => prev ? { ...prev, sha: newSha } : null);
      
      addLog('SUCCESS', `Commit successful! New SHA: ${newSha.substring(0, 7)}`);
    } catch (e) {
      const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
      setError(errorMessage);
      addLog('ERROR', `Commit failed: ${errorMessage}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleContentChange = (newContent: string) => {
    setFileContent(newContent);
  };
  
  // --- Resizing Logic ---
  const handleMouseDown = (index: number, e: React.MouseEvent) => {
    e.preventDefault();
    document.body.style.cursor = 'col-resize';
    setIsDragging(true);
    setDragInfo({ index, startX: e.clientX, startWidths: [...panelWidths] });
  };

  const handleMouseUp = useCallback(() => {
    document.body.style.cursor = '';
    setIsDragging(false);
    setDragInfo(null);
  }, []);
  
  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!isDragging || !dragInfo || !appContainerRef.current) return;

    const containerWidth = appContainerRef.current.getBoundingClientRect().width;
    const panelsWidth = containerWidth - (3 * RESIZER_WIDTH);

    const startPixelWidths = dragInfo.startWidths.map(ratio => ratio * panelsWidth);
    
    const dx = e.clientX - dragInfo.startX;
    const leftPanelIndex = dragInfo.index;
    const rightPanelIndex = dragInfo.index + 1;
    
    const totalTwoPanelWidth = startPixelWidths[leftPanelIndex] + startPixelWidths[rightPanelIndex];
    
    let newLeftWidth = startPixelWidths[leftPanelIndex] + dx;
    
    // Clamp the new width to respect the minimum panel width
    if (newLeftWidth < MIN_PANEL_WIDTH) {
        newLeftWidth = MIN_PANEL_WIDTH;
    }
    if (newLeftWidth > totalTwoPanelWidth - MIN_PANEL_WIDTH) {
        newLeftWidth = totalTwoPanelWidth - MIN_PANEL_WIDTH;
    }
    
    const newRightWidth = totalTwoPanelWidth - newLeftWidth;

    const newRatios = [...dragInfo.startWidths];
    newRatios[leftPanelIndex] = newLeftWidth / panelsWidth;
    newRatios[rightPanelIndex] = newRightWidth / panelsWidth;

    setPanelWidths(newRatios);
  }, [isDragging, dragInfo]);

  useEffect(() => {
    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    }
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, handleMouseMove, handleMouseUp]);
  
  return (
    <div ref={appContainerRef} className="flex h-screen w-full bg-gray-900 text-gray-200 font-sans overflow-hidden">
      <div style={{ flexGrow: panelWidths[0], flexBasis: '0px', minWidth: 0 }} className="h-full">
        <ControlPanel
          onConnect={handleConnect}
          isConnected={isConnected}
          isLoading={isLoading}
          repoDetails={repoDetails}
          error={error}
        />
      </div>

      <Resizer onMouseDown={(e) => handleMouseDown(0, e)} />

      <div style={{ flexGrow: panelWidths[1], flexBasis: '0px', minWidth: 0 }} className="flex flex-col h-full">
        <FileExplorer
          tree={tree}
          onFileSelect={handleFileSelect}
          onDirectoryLoad={handleDirectoryLoad}
          selectedFilePath={selectedFile?.path}
          isConnected={isConnected}
        />
      </div>
      
      <Resizer onMouseDown={(e) => handleMouseDown(1, e)} />
      
      <div style={{ flexGrow: panelWidths[2], flexBasis: '0px', minWidth: 0 }} className="flex flex-col h-full">
        <EditorPanel 
          file={selectedFile}
          content={fileContent} 
          onContentChange={handleContentChange}
          onCommit={handleCommit}
          isLoading={isLoading}
        />
      </div>

      <Resizer onMouseDown={(e) => handleMouseDown(2, e)} />

      <div style={{ flexGrow: panelWidths[3], flexBasis: '0px', minWidth: 0 }} className="flex flex-col h-full bg-gray-800">
        <OrchestrationLogPanel logs={orchestrationLog} />
      </div>
    </div>
  );
};

export default App;
