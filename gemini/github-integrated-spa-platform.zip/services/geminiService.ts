
const GITHUB_API_BASE = 'https://api.github.com';

const commonHeaders = (token: string) => ({
    'Authorization': `token ${token}`,
    'Accept': 'application/vnd.github.v3+json',
});

export const getRepoTree = async (owner: string, repo: string, token: string, path: string = '') => {
    const url = `${GITHUB_API_BASE}/repos/${owner}/${repo}/contents/${path}`;
    const response = await fetch(url, { headers: commonHeaders(token) });
    if (!response.ok) {
        const error = await response.json();
        throw new Error(`Failed to fetch repository tree: ${error.message}`);
    }
    const data = await response.json();
    // Sort so directories come first
    return data.sort((a: any, b: any) => {
        if (a.type === b.type) {
            return a.name.localeCompare(b.name);
        }
        return a.type === 'dir' ? -1 : 1;
    });
};

export const getFileContent = async (owner: string, repo: string, path: string, token: string) => {
    const url = `${GITHUB_API_BASE}/repos/${owner}/${repo}/contents/${path}`;
    const response = await fetch(url, { headers: commonHeaders(token) });
    if (!response.ok) {
        const error = await response.json();
        throw new Error(`Failed to fetch file content: ${error.message}`);
    }
    const data = await response.json();
    if (data.encoding !== 'base64') {
        throw new Error(`Unsupported file encoding: ${data.encoding}`);
    }
    return atob(data.content);
};

export const commitFile = async (
    owner: string,
    repo: string,
    path: string,
    content: string,
    sha: string,
    commitMessage: string,
    token: string
) => {
    const url = `${GITHUB_API_BASE}/repos/${owner}/${repo}/contents/${path}`;
    const response = await fetch(url, {
        method: 'PUT',
        headers: {
            ...commonHeaders(token),
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            message: commitMessage,
            content: btoa(content), // base64 encode content
            sha: sha,
        }),
    });

    if (!response.ok) {
        const error = await response.json();
        throw new Error(`Failed to commit file: ${error.message}`);
    }
    
    return await response.json();
};
